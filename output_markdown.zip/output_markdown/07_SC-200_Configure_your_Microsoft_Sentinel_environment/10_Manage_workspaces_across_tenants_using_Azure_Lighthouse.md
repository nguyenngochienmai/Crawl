---
title: Manage workspaces across tenants using Azure Lighthouse
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 10
url: https://learn.microsoft.com/en-us/training/modules/create-manage-azure-sentinel-workspaces/4-manage-workspaces-across-tenants-using-azure-lighthouse/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: content
crawled_at: 2025-11-25T18:46:11.240461
---

# Manage workspaces across tenants using Azure Lighthouse

> Manage multiple Microsoft Sentinel workspaces, or workspaces not in your tenant

If you're required to manage multiple Microsoft Sentinel workspaces, or workspaces not in your tenant, you have two options:

- Microsoft Sentinel Workspace manager
- Azure Lighthouse


## Microsoft Sentinel Workspace manager

Microsoft Sentinel's Workspace manager enables users to centrally manage multiple Microsoft Sentinel workspaces within one or more Azure tenants. The Central workspace (with Workspace manager enabled) can consolidate content items to be published at scale to Member workspaces. Workspace manager is enabled in the `Configuration settings`.


![Diagram of Microsoft Sentinel Workspace manager architectures. ](https://learn.microsoft.com/training/wwl-sci/create-manage-azure-sentinel-workspaces/media/microsoft-sentinel-workspace-manager-architectures.png)


## Azure Lighthouse

Implementing  Azure Lighthouse provides the option to enable your access to the tenant.  Once Azure Lighthouse is onboarded, use the directory + subscription selector on the Azure portal to select all the subscriptions containing workspaces you manage.


![Diagram of multiple tenants managed by Azure Lighthouse. ](https://learn.microsoft.com/training/wwl-sci/create-manage-azure-sentinel-workspaces/media/azure-delegated-tenant.jpg)

Azure Lighthouse allows greater flexibility to manage resources for multiple customers without having to sign in to different accounts in different tenants. For example, a service provider may have two customers with different responsibilities and access levels. By using Azure Lighthouse, authorized users can sign in to the service provider's tenant to access these resources.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/create-manage-azure-sentinel-workspaces/4-manage-workspaces-across-tenants-using-azure-lighthouse/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/create-manage-azure-sentinel-workspaces/4-manage-workspaces-across-tenants-using-azure-lighthouse/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*