---
title: Introduction
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 29
url: https://learn.microsoft.com/en-us/training/modules/utilize-threat-intelligence-azure-sentinel/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: introduction
crawled_at: 2025-11-25T18:51:58.588314
---

# Introduction

> Introduction

Microsoft Sentinel provides a table to store indicator data accessible to Kusto Query Language (KQL) queries.  The Threat intelligence page in Microsoft Sentinel provides the management options to maintain the indicators.

You're a Security Operations Analyst working at a company that implemented Microsoft Sentinel.  You receive threat indicators from threat intelligence providers and your threat hunting team.  The Indicators include IP addresses, domains, and file hashes that can be utilized by many components within Microsoft Sentinel.

The indicators from the threat intelligence providers are automatically imported into the workspace using connectors.  You're tasked with adding the indicators from the threat hunting team.  You use the Threat Intelligence page to add the indicators for use by the detection KQL queries.

After completing this module, you'll be able to:

- Manage threat indicators in Microsoft Sentinel
- Use KQL to access threat indicators in Microsoft Sentinel


## Prerequisites

Basic knowledge of operational concepts such as monitoring, logging, and alerting.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/utilize-threat-intelligence-azure-sentinel/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/utilize-threat-intelligence-azure-sentinel/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*