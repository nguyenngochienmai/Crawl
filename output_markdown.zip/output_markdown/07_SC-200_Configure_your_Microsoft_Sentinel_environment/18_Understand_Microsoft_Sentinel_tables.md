---
title: Understand Microsoft Sentinel tables
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 18
url: https://learn.microsoft.com/en-us/training/modules/query-logs-azure-sentinel/3-understand-azure-sentinel-tables/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: content
crawled_at: 2025-11-25T18:48:22.288377
---

# Understand Microsoft Sentinel tables

> Understand Microsoft Sentinel tables

Microsoft Sentinel has Analytic Rules that generate Alerts and Incidents based on querying the tables within Log Analytics. The primary tables to manage alerts and incidents are SecurityAlert and SecurityIncident. Microsoft Sentinel provides tables to be a repository of indicators and watchlists.

Some of the Sentinel Data Connectors ingest alerts directly.

The table below is the Microsoft Sentinel feature related tables.

| Table | Description |
| --- | --- |
| SecurityAlert | Contains Alerts Generated from Sentinel Analytical Rules. Also, it could include Alerts created directly from a Sentinel Data Connector |
| SecurityIncident | Alerts can generate Incidents. Incidents are related to Alert(s). |
| ThreatIntelligenceIndicator | Contains user-created or data connector ingested Indicators such as File Hashes, IP Addresses, Domains |
| Watchlist | A Microsoft Sentinel watchlist contains imported data. |


---

*Source: [https://learn.microsoft.com/en-us/training/modules/query-logs-azure-sentinel/3-understand-azure-sentinel-tables/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/query-logs-azure-sentinel/3-understand-azure-sentinel-tables/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*