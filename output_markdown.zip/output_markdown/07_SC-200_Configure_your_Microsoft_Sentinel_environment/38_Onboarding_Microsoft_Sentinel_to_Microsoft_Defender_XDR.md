---
title: Onboarding Microsoft Sentinel to Microsoft Defender XDR
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 38
url: https://learn.microsoft.com/en-us/training/modules/integrate-microsoft-defender-xdr-with-microsoft-sentinel/4-onboarding-sentinel-to-defender-xdr/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: content
crawled_at: 2025-11-25T18:56:17.268173
---

# Onboarding Microsoft Sentinel to Microsoft Defender XDR

> Onboarding Microsoft Sentinel to Microsoft Defender XDR.

Now that you understand the benefits of integrating Microsoft Defender XDR with Microsoft Sentinel, and know the capability differences, you can onboard Microsoft Sentinel to Microsoft Defender XDR.

But, before you begin, make sure you have completed the following steps and have the resources and access required.


## Prerequisites

The Microsoft Defender portal supports a single Microsoft Entra tenant and the connection to a primary workspace and multiple secondary workspaces. In the context of this article, a workspace is a Log Analytics workspace with Microsoft Sentinel enabled.

To onboard and use Microsoft Sentinel in the Microsoft Defender portal, you must have the following resources and access:

- A Log Analytics workspace that has Microsoft Sentinel enabled
- The data connector for Microsoft Defender XDR (formerly named Microsoft 365 Defender) enabled in Microsoft Sentinel for incidents and alerts. For more information, see Connect data from Microsoft Defender XDR to Microsoft Sentinel.
- Access to Microsoft Defender XDR in the Defender portal
- Microsoft Defender XDR onboarded to the Microsoft Entra tenant
- An Azure account with the appropriate roles to onboard, use, and create support requests for Microsoft Sentinel in the Defender portal. The following table highlights some of the key roles needed.

| Task | Azure built-in role required | Scope |
| --- | --- | --- |
| Connect or disconnect a workspace with Microsoft Sentinel enabled | Owner or User Access Administrator and Microsoft Sentinel Contributor | - Subscription for Owner or User Access Administrator roles - Subscription, resource group, or workspace resource for Microsoft Sentinel Contributor |
| View Microsoft Sentinel in the Defender portal | Microsoft Sentinel Reader | Subscription, resource group, or workspace resource |
| Query Sentinel data tables or view incidents | Microsoft Sentinel Reader or a role with the following actions:- Microsoft.OperationalInsights/workspaces/read- Microsoft.OperationalInsights/workspaces/query/read- Microsoft.SecurityInsights/Incidents/read- Microsoft.SecurityInsights/incidents/comments/read- Microsoft.SecurityInsights/incidents/relations/read- Microsoft.SecurityInsights/incidents/tasks/read | Subscription, resource group, or workspace resource |
| Take investigative actions on incidents | Microsoft Sentinel Contributor or a role with the following actions:- Microsoft.OperationalInsights/workspaces/read- Microsoft.OperationalInsights/workspaces/query/read- Microsoft.SecurityInsights/incidents/read- Microsoft.SecurityInsights/incidents/write- Microsoft.SecurityInsights/incidents/comments/read- Microsoft.SecurityInsights/incidents/comments/write- Microsoft.SecurityInsights/incidents/relations/read- Microsoft.SecurityInsights/incidents/relations/write- Microsoft.SecurityInsights/incidents/tasks/read- Microsoft.SecurityInsights/incidents/tasks/write | Subscription, resource group, or workspace resource |
| Create a support request | Owner or  Contributor or  Support request contributor or  a custom role with Microsoft.Support/* | Subscription |

After you connect Microsoft Sentinel to the Defender portal, your existing Azure role-based access control (RBAC) permissions allow you to work with the Microsoft Sentinel features that you have access to. Continue to manage roles and permissions for your Microsoft Sentinel users from the Azure portal. Any Azure RBAC changes are reflected in the Defender portal. For more information about Microsoft Sentinel permissions, see [Roles and permissions in Microsoft Sentinel | Microsoft Learn](/en-us/azure/sentinel/roles" data-linktype="absolute-path) and [Manage access to Microsoft Sentinel data by resource | Microsoft Learn](/en-us/azure/sentinel/resource-context-rbac" data-linktype="absolute-path).


## Onboard Microsoft Sentinel

To connect a workspace that has Microsoft Sentinel enabled to Defender XDR, complete the following steps:

Before you connect your workspace, make sure you've installed the **Microsoft Defender XDR** solution for Microsoft Sentinel from the **Content hub**. And then, enabled the **Microsoft Defender XDR** data connector to collect incidents and alerts.


![Screen shot of the Get your SIEM and XDR in one place banner message.](https://learn.microsoft.com/training/wwl-sci/integrate-microsoft-defender-xdr-with-microsoft-sentinel/media/defender-xdr-connect-sentinel-workspace.png)

1. Go to the Microsoft Defender portal and sign in.
2. In Microsoft Defender XDR, select Home (Overview).
3. Select Connect a workspace in the Get your SIEM and XDR in one place banner.
4. Choose the workspace you want to connect and select Next.
5. Read and understand the product changes associated with connecting your workspace. These changes include:

Log tables, queries, and functions in the Microsoft Sentinel workspace are also available in advanced hunting within Defender XDR.
The Microsoft Sentinel Contributor role is assigned to the Microsoft Threat Protection and WindowsDefenderATP apps within the subscription.
Active Microsoft security incident creation rules are deactivated to avoid duplicate incidents. This change only applies to incident creation rules for Microsoft alerts and not to other analytics rules.
All alerts related to Defender XDR products are streamed directly from the main Defender XDR data connector to ensure consistency. Make sure you have incidents and alerts from this connector turned on in the workspace.
6. Log tables, queries, and functions in the Microsoft Sentinel workspace are also available in advanced hunting within Defender XDR.
7. The Microsoft Sentinel Contributor role is assigned to the Microsoft Threat Protection and WindowsDefenderATP apps within the subscription.
8. Active Microsoft security incident creation rules are deactivated to avoid duplicate incidents. This change only applies to incident creation rules for Microsoft alerts and not to other analytics rules.
9. All alerts related to Defender XDR products are streamed directly from the main Defender XDR data connector to ensure consistency. Make sure you have incidents and alerts from this connector turned on in the workspace.
10. Select Connect.

Go to the [Microsoft Defender portal](https://security.microsoft.com/" data-linktype="external) and sign in.

In Microsoft Defender XDR, select **Home** (Overview).

Select **Connect a workspace** in the *Get your SIEM and XDR in one place* banner.

Choose the workspace you want to connect and select **Next**.

Read and understand the product changes associated with connecting your workspace. These changes include:

- Log tables, queries, and functions in the Microsoft Sentinel workspace are also available in advanced hunting within Defender XDR.
- The Microsoft Sentinel Contributor role is assigned to the Microsoft Threat Protection and WindowsDefenderATP apps within the subscription.
- Active Microsoft security incident creation rules are deactivated to avoid duplicate incidents. This change only applies to incident creation rules for Microsoft alerts and not to other analytics rules.
- All alerts related to Defender XDR products are streamed directly from the main Defender XDR data connector to ensure consistency. Make sure you have incidents and alerts from this connector turned on in the workspace.

Select **Connect**.

After your workspace is connected, the banner on the **Home** (Overview) page shows that your unified security information and event management (SIEM) and extended detection and response (XDR) is ready. The **Home** page is updated with new sections that include metrics from Microsoft Sentinel like the number of data connectors and automation rules.


![Screen shot of Microsoft Sentinel onboarded to Defender XDR.](https://learn.microsoft.com/training/wwl-sci/integrate-microsoft-defender-xdr-with-microsoft-sentinel/media/onboarded-defender-portal.png)


## Offboard Microsoft Sentinel

You can only have one workspace connected to the Defender portal at a time. If you want to connect to a different workspace that has Microsoft Sentinel enabled, disconnect the current workspace and connect the other workspace.

1. Go to the Microsoft Defender portal and sign in.
2. In the Defender portal, under System, select Settings > Microsoft Sentinel.
3. On the Workspaces page, select the connected workspace and Disconnect workspace.
4. Provide a reason why you're disconnecting the workspace.
5. Confirm your selection.
When your workspace is disconnected, the Microsoft Sentinel section is removed from the left-hand side navigation of the Defender portal. Data from Microsoft Sentinel is no longer included on the Overview page.

Go to the [Microsoft Defender portal](https://security.microsoft.com/" data-linktype="external) and sign in.

In the Defender portal, under **System**, select **Settings** &gt; **Microsoft Sentinel**.

On the **Workspaces** page, select the connected workspace and **Disconnect workspace**.

Provide a reason why you're disconnecting the workspace.

Confirm your selection.

When your workspace is disconnected, the **Microsoft Sentinel** section is removed from the left-hand side navigation of the Defender portal. Data from Microsoft Sentinel is no longer included on the Overview page.

If you want to connect to a different workspace, from the **Workspaces** page, select the workspace and **Connect a workspace**.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/integrate-microsoft-defender-xdr-with-microsoft-sentinel/4-onboarding-sentinel-to-defender-xdr/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/integrate-microsoft-defender-xdr-with-microsoft-sentinel/4-onboarding-sentinel-to-defender-xdr/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*