---
title: Module assessment
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 21
url: https://learn.microsoft.com/en-us/training/modules/query-logs-azure-sentinel/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: quiz
crawled_at: 2025-11-25T18:49:11.541687
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "Which table stores Defender for Endpoint logon events?",
"options": [
"DeviceLogonEvents",
"OfficeActivity",
"SigninLogs"
],
"correct\_answers": [
"DeviceLogonEvents"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "What table contains logs from Windows hosts collected directly to Microsoft Sentinel?",
"options": [
"SecurityEvent",
"AuditLogs",
"SecurityAlert"
],
"correct\_answers": [
"SecurityEvent"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "Which table stores Alerts from Microsoft Defender for Endpoint?",
"options": [
"SecurityIncident",
"DeviceEvents",
"SecurityAlert"
],
"correct\_answers": [
"SecurityAlert"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/query-logs-azure-sentinel/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/query-logs-azure-sentinel/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*