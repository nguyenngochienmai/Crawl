---
title: Create a Microsoft Sentinel workspace
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 9
url: https://learn.microsoft.com/en-us/training/modules/create-manage-azure-sentinel-workspaces/3-create-azure-sentinel-workspace/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: content
crawled_at: 2025-11-25T18:45:55.129267
---

# Create a Microsoft Sentinel workspace

> Create a Microsoft Sentinel workspace

After designing the workspace architecture, sign-in to the Azure portal. At the search bar, search for Sentinel, then select **Microsoft Sentinel**. The Microsoft Sentinel Workspaces shows a list of the current workspaces. Select the **+ add** button to start the creation process.

If you choose to perform this exercise, be aware you might incur costs in your Azure Subscription. To estimate the cost, refer to [Microsoft Sentinel Pricing](https://azure.microsoft.com/pricing/details/azure-sentinel/" data-linktype="external). We have also included an interactive lab simulation after the exercise.


## Microsoft Sentinel installation prerequisites

To enable Microsoft Sentinel, you need contributor permissions to the subscription in which the Microsoft Sentinel workspace resides. To use Microsoft Sentinel, you need either contributor or reader permissions on the resource group that the workspace belongs.


## Create and configure a Log Analytics Workspace

1. The next page, Add Microsoft Sentinel to a workspace will display a list of available Log Analytics workspaces to add Microsoft Sentinel.  Select the + create a new workspace button to start the "Create Log Analytics workspace" process.
2. The Basics tab includes the following options:
 
		
			
		
		Expand table
	


Option
Description




Subscription
Select the Subscription


Resource Group
Select or create a Resource Group


Name
Name is the name of the Log Analytics workspace and is also the name of your Microsoft Sentinel Workspace


Region
The region is the location the log data is stored.




 Important
The Name is the name of the Microsoft Sentinel workspace. The Microsoft Sentinel name defaults to the Log Analytics Workspace Name.
The Region is the location where ingested data is stored. The data location impacts data governance requirements.  Workspaces can't move from region to region; you'll need to recreate the workspace if the region option needs to be changed.
3. Select the Review + Create button and then select the Create button.

The next page, **Add Microsoft Sentinel to a workspace** will display a list of available Log Analytics workspaces to add Microsoft Sentinel.  Select the **+ create a new workspace** button to start the "Create Log Analytics workspace" process.

The Basics tab includes the following options:

| Option | Description |
| --- | --- |
| Subscription | Select the Subscription |
| Resource Group | Select or create a Resource Group |
| Name | Name is the name of the Log Analytics workspace and is also the name of your Microsoft Sentinel Workspace |
| Region | The region is the location the log data is stored. |

The Name is the name of the Microsoft Sentinel workspace. The Microsoft Sentinel name defaults to the Log Analytics Workspace Name.
The Region is the location where ingested data is stored. The data location impacts data governance requirements.  Workspaces can't move from region to region; you'll need to recreate the workspace if the region option needs to be changed.

Select the **Review + Create** button and then select the **Create** button.


## Add Microsoft Sentinel to the workspace

The "Add Microsoft Sentinel to Workspace" screen will now appear after you've completed the previous steps.

1. Wait for the newly created "Log Analytics Workspace" to appear in the list.  This operation could take a few minutes.
2. Select the newly created Log Analytics workspace. And select the Add button.

Wait for the newly created "Log Analytics Workspace" to appear in the list.  This operation could take a few minutes.

Select the newly created Log Analytics workspace. And select the **Add** button.

The new Microsoft Sentinel workspace is now the active screen.  The Microsoft Sentinel left navigation has four areas:

- General
- Threat management
- Content management
- Configuration

The Overview tab displays a standard dashboard of information about the ingested data, alerts, and incidents.


## Interactive Lab Simulation

Select the thumbnail image to start the lab simulation. When you're done, be sure to return to this page so you can continue learning.


![Screenshot of the lab simulation page.](https://learn.microsoft.com/training/wwl-sci/create-manage-azure-sentinel-workspaces/media/sc-200-lab-simulation-configure-your-microsoft-sentinel-environment.png)


## Microsoft Sentinel sharing a Log Analytics Workspace

Considering that Microsoft Sentinel workspace uses a Log Analytics workspace, you have the option to enable the Microsoft Sentinel workspace in a Log Analytics workspace that is used by other solutions. The most common scenario is sharing the Log Analytics workspace used by Microsoft Defender for Cloud. Sharing the workspace enables one central workspace to query security data.


## Microsoft Defender for Cloud

When creating your Microsoft Sentinel workspace, you aren't allowed to use the **Default** Microsoft Defender for Cloud Log Analytics workspace. You need to manually create a Log Analytics workspace then update the Microsoft Defender for Cloud tier. Now you can select the manually created Log Analytics workspace for use with Microsoft Defender for Cloud.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/create-manage-azure-sentinel-workspaces/3-create-azure-sentinel-workspace/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/create-manage-azure-sentinel-workspaces/3-create-azure-sentinel-workspace/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*