---
title: Module assessment
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 27
url: https://learn.microsoft.com/en-us/training/modules/use-watchlists-azure-sentinel/5-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: quiz
crawled_at: 2025-11-25T18:50:45.930424
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "Which of the following operations is a typical scenario for using a Microsoft Sentinel watchlist?",
"options": [
"Creating more alerts to help identify issues.",
"Export business data as a watchlist.",
"Responding to incidents quickly with the rapid import of IP addresses."
],
"correct\_answers": [
"Responding to incidents quickly with the rapid import of IP addresses."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "How do you access a new watchlist named MyList in KQL?",
"options": [
"\_Watchlist('MyList ')",
"\_GetWatchlist('MyList')",
"\_Getlist('MyList ')"
],
"correct\_answers": [
"\_GetWatchlist('MyList')"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/use-watchlists-azure-sentinel/5-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/use-watchlists-azure-sentinel/5-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*