---
title: Manage your threat indicators
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 31
url: https://learn.microsoft.com/en-us/training/modules/utilize-threat-intelligence-azure-sentinel/3-manage-threat-indicators/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: content
crawled_at: 2025-11-25T18:52:29.580322
---

# Manage your threat indicators

> Manage your threat indicators

With the Threat Intelligence area, accessible from the Microsoft Sentinel menu, you can also view, sort, filter, and search your imported threat indicators without even writing a Logs query. This area also allows you to create threat indicators directly within the Microsoft Sentinel interface and perform everyday threat intelligence administrative tasks. These tasks include indicator tagging and creating new indicators related to security investigations. Let's look at two of the most common tasks, creating new threat indicators and tagging indicators for easy grouping and reference.

- Defender portal
- Azure portal

1. Open the Defender portal and navigate to Microsoft Sentinel.
2. From the Threat management section of the Microsoft Sentinel menu, select Threat intelligence.
3. If you see the This page has a new home message. Select the Open Intel management button.
4. You're redirected to the Intel management page under the Threat Intelligence section of the Defender portal navigation menu.





 Tip
As the Threat intelligence capabilities in Microsoft Sentinel are being consolidated into the Defender portals Threat intelligence section, you can go directly to Intel management from there.
5. On the Select the Add new button from the top menu of the page.
6. Choose the indicator type, then complete the required fields marked with a red asterisk (*) on the New indicator panel. Select Apply.

Open the [Defender portal](https://security.microsoft.com/" data-linktype="external) and navigate to Microsoft Sentinel.

From the **Threat management** section of the Microsoft Sentinel menu, select **Threat intelligence**.

If you see the *This page has a new home* message. Select the **Open Intel management** button.


![Screenshot of the this page has a new home message for Threat Intelligence in Microsoft Sentinel.](https://learn.microsoft.com/training/wwl-sci/utilize-threat-intelligence-azure-sentinel/media/threat-intelligence-new-home.png)

You're redirected to the *Intel management* page under the *Threat Intelligence* section of the Defender portal navigation menu.


![Screenshot of the Defender Intel management page.](https://learn.microsoft.com/training/wwl-sci/utilize-threat-intelligence-azure-sentinel/media/intel-management.png)

As the *Threat intelligence* capabilities in Microsoft Sentinel are being consolidated into the Defender portals *Threat intelligence* section, you can go directly to *Intel management* from there.

On the Select the **Add new** button from the top menu of the page.

Choose the indicator type, then complete the required fields marked with a red asterisk (*) on the New indicator panel. Select **Apply**.

Open the [Azure portal](https://portal.azure.com/" data-linktype="external" target="az-portal" class="has-external-link-indicator) and navigate to Microsoft Sentinel.

1. Choose the workspace to which you imported threat indicators using either threat intelligence data connector.
2. From the Threat management section of the Microsoft Sentinel menu, select Threat intelligence.
3. Select the Add new button from the top menu of the page.
4. Choose the indicator type, then complete the required fields marked with a red asterisk (*) on the New indicator panel. Select Apply.

Choose the workspace to which you imported threat indicators using either threat intelligence data connector.

From the **Threat management** section of the Microsoft Sentinel menu, select **Threat intelligence**.

Select the **Add new** button from the top menu of the page.

Choose the indicator type, then complete the required fields marked with a red asterisk (*) on the New indicator panel. Select **Apply**.

Tagging threat indicators is an easy way to group them to make them easier to find. Typically, you might apply a tag to indicators related to a particular incident or indicators representing threats from a known actor or a well-known attack campaign. You can tag threat indicators individually or multi-select indicators and tag them all at once. Since tagging is free-form, a recommended practice is to create standard naming conventions for threat indicator tags. You can apply multiple tags to each indicator.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/utilize-threat-intelligence-azure-sentinel/3-manage-threat-indicators/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/utilize-threat-intelligence-azure-sentinel/3-manage-threat-indicators/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*