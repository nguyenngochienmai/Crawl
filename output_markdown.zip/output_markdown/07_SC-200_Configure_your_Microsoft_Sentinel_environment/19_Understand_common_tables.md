---
title: Understand common tables
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 19
url: https://learn.microsoft.com/en-us/training/modules/query-logs-azure-sentinel/4-understand-common-tables/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: content
crawled_at: 2025-11-25T18:48:37.877801
---

# Understand common tables

> Understand common tables

When Sentinel ingests data from the Data Connectors, the following table lists the most commonly used tables.

| Table | Description |
| --- | --- |
| AzureActivity | Entries from the Azure Activity log that provides insight into any subscription-level or management group level events that occurred in Azure. |
| AzureDiagnostics | Stores resource logs for Azure services that use Azure Diagnostics mode. Resource logs describe the internal operation of Azure resources. |
| AuditLogs | Audit log for Microsoft Entra ID. Includes system activity information about user and group management, managed applications, and directory activities. |
| CommonSecurityLog | Syslog messages using the Common Event Format (CEF). |
| McasShadowItReporting | Microsoft Defender for Cloud Apps logs |
| OfficeActivity | Audit logs for Office 365 tenants collected by Microsoft Sentinel. Including Exchange, SharePoint and Teams logs. |
| SecurityEvent | Security events collected from windows machines by Azure Security Center or Microsoft Sentinel |
| SigninLogs | Azure Activity Directory Sign-in logs |
| Syslog | Syslog events on Linux computers using the Log Analytics agent. |
| Event | Sysmon Events collected from a Windows host. |
| WindowsFirewall | Windows Firewall Events |


---

*Source: [https://learn.microsoft.com/en-us/training/modules/query-logs-azure-sentinel/4-understand-common-tables/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/query-logs-azure-sentinel/4-understand-common-tables/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*