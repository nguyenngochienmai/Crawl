---
title: Introduction
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 1
url: https://learn.microsoft.com/en-us/training/modules/intro-to-azure-sentinel/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: introduction
crawled_at: 2025-11-25T18:42:44.367201
---

# Introduction

> Introduction

Imagine that you work as a security operations center (SOC) analyst. Your organization wants to advance its security-management capabilities. The business already started moving some workloads to the public cloud.

You've been asked to evaluate *security information and event management* (SIEM) solutions that can help in both an on-premises and a multicloud environment. You've heard about Microsoft Sentinel and want to find out whether it could be the right SIEM solution for your business.

Ideally, you'd select a service that provides the features and functionality that you need, with minimal administration and a flexible pricing model.

Microsoft Sentinel offers exactly those benefits.

In this module, you'll explore Microsoft Sentinel and discover why and when to use it. You'll investigate the key features and capabilities of Microsoft Sentinel, including how and when to deploy it.


## Learning objectives

By the end of this module, you're able to:

- Identify the various components and functionality of Microsoft Sentinel.
- Identify use cases where Microsoft Sentinel would be a good solution.


## Prerequisites

- Familiarity with security operations in an organization
- Basic experience with Azure services


---

*Source: [https://learn.microsoft.com/en-us/training/modules/intro-to-azure-sentinel/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/intro-to-azure-sentinel/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*