---
title: Module assessment
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 41
url: https://learn.microsoft.com/en-us/training/modules/integrate-microsoft-defender-xdr-with-microsoft-sentinel/knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: quiz
crawled_at: 2025-11-25T18:57:05.736035
---

# Module assessment

> Knowledge check.

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "What is one of the benefits of integrating Microsoft Sentinel and Defender XDR in the Defender portal?",
"options": [
"It increases the complexity of managing and switching between multiple tools.",
"It streamlines operations and reduces the risk of errors that can occur when switching between different systems.",
"It requires context-switching when querying across different data sets."
],
"correct\_answers": [
"It streamlines operations and reduces the risk of errors that can occur when switching between different systems."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "Which portal supports the functionality of adding entities to threat intelligence from incidents in Microsoft Sentinel?",
"options": [
"Both Azure and Defender portals",
"Azure portal",
"Defender portal"
],
"correct\_answers": [
"Azure portal"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "What is one of the product changes associated with connecting a workspace to Defender XDR?",
"options": [
"Microsoft Sentinel Reader role is assigned to the Microsoft Threat Protection and WindowsDefenderATP apps within the subscription.",
"All Microsoft security incident creation rules are activated to avoid duplicate incidents.",
"Log tables, queries, and functions in the Microsoft Sentinel workspace are also available in advanced hunting within Defender XDR."
],
"correct\_answers": [
"Log tables, queries, and functions in the Microsoft Sentinel workspace are also available in advanced hunting within Defender XDR."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 4,
"question": "What happens when a workspace is disconnected from the Defender portal in Microsoft Sentinel?",
"options": [
"The Microsoft Sentinel section is removed from the left-hand side navigation of the Defender portal",
"The workspace is deleted from Microsoft Sentinel",
"Data from Microsoft Sentinel is still included on the Overview page"
],
"correct\_answers": [
"The Microsoft Sentinel section is removed from the left-hand side navigation of the Defender portal"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/integrate-microsoft-defender-xdr-with-microsoft-sentinel/knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/integrate-microsoft-defender-xdr-with-microsoft-sentinel/knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*