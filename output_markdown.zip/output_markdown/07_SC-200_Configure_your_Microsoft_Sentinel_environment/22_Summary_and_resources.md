---
title: Summary and resources
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 22
url: https://learn.microsoft.com/en-us/training/modules/query-logs-azure-sentinel/7-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: summary
crawled_at: 2025-11-25T18:49:35.293789
---

# Summary and resources

> Summary and resources

You should have a basic understanding of the provided tables and their intended purpose in Microsoft Sentinel.

You should now be able to:

- Use the Logs page to view tables with Microsoft Sentinel
- Query the most used tables with Microsoft Sentinel


## Learn more

You can learn more by reviewing the following.

[Become a Microsoft Sentinel Ninja](https://techcommunity.microsoft.com/t5/azure-sentinel/become-an-azure-sentinel-ninja-the-complete-level-400-training/ba-p/1246310" data-linktype="external" target="az-portal" class="has-external-link-indicator)

[Microsoft Tech Community Security Webinars](https://techcommunity.microsoft.com/t5/microsoft-security-and/security-community-webinars/ba-p/927888" data-linktype="external" target="az-portal" class="has-external-link-indicator)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/query-logs-azure-sentinel/7-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/query-logs-azure-sentinel/7-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*