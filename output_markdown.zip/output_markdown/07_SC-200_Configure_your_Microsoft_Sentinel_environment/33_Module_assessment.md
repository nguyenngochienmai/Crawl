---
title: Module assessment
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 33
url: https://learn.microsoft.com/en-us/training/modules/utilize-threat-intelligence-azure-sentinel/5-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: quiz
crawled_at: 2025-11-25T18:53:00.903411
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "In Threat Intelligence, indicators are considered as which of the following?",
"options": [
"Strategic",
"Operational",
"Tactical"
],
"correct\_answers": [
"Tactical"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "Which of these items is an example of a Threat indicator?",
"options": [
"Threat Actor Name",
"Domain Name",
"Threat Campaign"
],
"correct\_answers": [
"Domain Name"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "What table do you query in KQL to view your indicators?",
"options": [
"Indicator",
"TI Indicator",
"ThreatIntelligenceIndicator"
],
"correct\_answers": [
"ThreatIntelligenceIndicator"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/utilize-threat-intelligence-azure-sentinel/5-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/utilize-threat-intelligence-azure-sentinel/5-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*