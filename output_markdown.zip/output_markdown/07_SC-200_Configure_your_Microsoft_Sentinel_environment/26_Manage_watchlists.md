---
title: Manage watchlists
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 26
url: https://learn.microsoft.com/en-us/training/modules/use-watchlists-azure-sentinel/4-manage-watchlists/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: content
crawled_at: 2025-11-25T18:50:29.660089
---

# Manage watchlists

> Manage watchlists

We recommend you edit an existing watchlist instead of deleting and recreating a watchlist. Log analytics has a five-minute SLA (Service Level Agreement) for data ingestion. If you delete and recreate a watchlist, you might see both the deleted and recreated entries in Log Analytics during this five-minute window. If you see these duplicate entries in Log Analytics for a longer period of time, submit a support ticket.


## Edit a watchlist item

Edit a watchlist to edit or add an item to the watchlist.

1. In the Azure portal, go to Microsoft Sentinel and select the appropriate workspace.
2. Under Configuration, select Watchlist.
3. Select the watchlist you want to edit.
4. On the details pane, select Update watchlist > Edit watchlist items.
5. To edit an existing watchlist item,

Select the checkbox of that watchlist item.

Edit the item.

Select Save.

Select Yes at the confirmation prompt.
6. Select the checkbox of that watchlist item.
7. Edit the item.
8. Select Save.
9. Select Yes at the confirmation prompt.
10. To add a new item to your watchlist,

Select Add new.

Fill in the fields in the Add watchlist item panel.

At the bottom of that panel, select Add.
11. Select Add new.
12. Fill in the fields in the Add watchlist item panel.
13. At the bottom of that panel, select Add.

In the Azure portal, go to Microsoft Sentinel and select the appropriate workspace.

Under Configuration, select **Watchlist**.

Select the watchlist you want to edit.

On the details pane, select **Update watchlist &gt; Edit watchlist items**.

To edit an existing watchlist item,

1. Select the checkbox of that watchlist item.
2. Edit the item.
3. Select Save.
4. Select Yes at the confirmation prompt.

Select the checkbox of that watchlist item.

Edit the item.

Select Save.

Select Yes at the confirmation prompt.

To add a new item to your watchlist,

1. Select Add new.
2. Fill in the fields in the Add watchlist item panel.
3. At the bottom of that panel, select Add.

Select Add new.

Fill in the fields in the Add watchlist item panel.

At the bottom of that panel, select Add.


## Bulk update a watchlist

When you have many items to add to a watchlist, use bulk update. A bulk update of a watchlist appends items to the existing watchlist. Then, it deduplicates the items in the watchlist where all the value in each column match.

If you deleted an item from your watchlist file and upload it, bulk update won't delete the item in the existing watchlist. Delete the watchlist item individually. Or, when you have many deletions, delete and recreate the watchlist.

The updated watchlist file you upload must contain the search key field used by the watchlist with no blank values.

To bulk update a watchlist,

1. In the Azure portal, go to Microsoft Sentinel and select the appropriate workspace.
2. Under Configuration, select Watchlist.
3. Select the watchlist you want to edit.
4. On the details pane, select Update watchlist > Bulk update.
5. Under Upload file, drag and drop or browse to the file to upload.
6. If you get an error, fix the issue in the file. Then select Reset and try the file upload again.
7. Select Next: Review and update > Update.

In the Azure portal, go to Microsoft Sentinel and select the appropriate workspace.

Under Configuration, select **Watchlist**.

Select the watchlist you want to edit.

On the details pane, select **Update watchlist &gt; Bulk update**.

Under Upload file, drag and drop or browse to the file to upload.

If you get an error, fix the issue in the file. Then select Reset and try the file upload again.

Select **Next: Review and update &gt; Update**.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/use-watchlists-azure-sentinel/4-manage-watchlists/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/use-watchlists-azure-sentinel/4-manage-watchlists/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*