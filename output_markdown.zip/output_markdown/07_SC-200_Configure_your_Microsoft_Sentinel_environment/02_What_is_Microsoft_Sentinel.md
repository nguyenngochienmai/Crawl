---
title: What is Microsoft Sentinel?
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 2
url: https://learn.microsoft.com/en-us/training/modules/intro-to-azure-sentinel/2-what-is-azure-sentinel/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: content
crawled_at: 2025-11-25T18:42:59.741937
---

# What is Microsoft Sentinel?

> What is Microsoft Sentinel?

Let's start with a few definitions and a look at *security information and event management* (SIEM) systems and Microsoft Sentinel.


## What is security information and event management (SIEM)?

A SIEM system is a tool that an organization uses to collect, analyze, and perform security operations on its computer systems. Those systems can be hardware appliances, applications, or both.

In its simplest form, a SIEM system allows you to:

- Collect and query logs.
- Do some form of correlation or anomaly detection.
- Create alerts and incidents based on your findings.

A SIEM system might offer functionality such as:

- Log management: The ability to collect, store, and query the log data from resources within your environment.
- Alerting: A proactive look inside the log data for potential security incidents and anomalies.
- Visualization: Graphs and dashboards that provide visual insights into your log data.
- Incident management: The ability to create, update, assign, and investigate incidents that have been identified.
- Querying data: A rich query language, similar to that for log management, that you can use to query and understand your data.

**Log management**: The ability to collect, store, and query the log data from resources within your environment.

**Alerting**: A proactive look inside the log data for potential security incidents and anomalies.

**Visualization**: Graphs and dashboards that provide visual insights into your log data.

**Incident management**: The ability to create, update, assign, and investigate incidents that have been identified.

**Querying data**: A rich query language, similar to that for log management, that you can use to query and understand your data.


## What is Microsoft Sentinel?

Microsoft Sentinel is a cloud-native SIEM system that a security operations team can use to:

- Get security insights across the enterprise by collecting data from virtually any source.
- Detect and investigate threats quickly by using built-in machine learning and Microsoft threat intelligence.
- Automate threat responses by using playbooks and by integrating Azure Logic Apps.

Unlike with traditional SIEM solutions, you don't need to install any servers either on-premises or in the cloud to run Microsoft Sentinel. Microsoft Sentinel is a service that you deploy in Azure. You can get up and running with Sentinel in just a few minutes in the Azure portal.

Microsoft Sentinel is tightly integrated with other cloud services. Not only can you quickly ingest logs, but you can also use other cloud services natively (for example, authorization and automation).

Microsoft Sentinel helps you enable end-to-end security operations including collection, detection, investigation, and response:


![Diagram showing the end-to-end functionality of Microsoft Sentinel.](https://learn.microsoft.com/training/wwl-sci/intro-to-azure-sentinel/media/02-end-to-end.svg)

Let's take a look at the key components in Microsoft Sentinel.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/intro-to-azure-sentinel/2-what-is-azure-sentinel/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/intro-to-azure-sentinel/2-what-is-azure-sentinel/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*