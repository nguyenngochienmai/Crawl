---
title: Explore the capability differences between Microsoft Defender XDR and Microsoft Sentinel portals
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 37
url: https://learn.microsoft.com/en-us/training/modules/integrate-microsoft-defender-xdr-with-microsoft-sentinel/3-capability-differences-between-portals/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: content
crawled_at: 2025-11-25T18:56:01.479999
---

# Explore the capability differences between Microsoft Defender XDR and Microsoft Sentinel portals

> Explore the capability differences between Microsoft Defender XDR and Microsoft Sentinel portals.

Most Microsoft Sentinel capabilities are available in both the Azure and Defender portals. In the Defender portal, some Microsoft Sentinel experiences open out to the Azure portal for you to complete a task.

This section covers the Microsoft Sentinel capabilities or integrations in Microsoft Defender that are only available in either the Azure portal or Defender portal or other significant differences between the portals. It excludes the Microsoft Sentinel experiences that open the Azure portal from the Defender portal.


### Capability differences between portals

| Capability | Availability | Description |
| --- | --- | --- |
| Advanced hunting using bookmarks | Azure portal only | Bookmarks aren't supported in the advanced hunting experience in the Microsoft Defender portal. In the Defender portal, they're supported in the Microsoft Sentinel > Threat management > Hunting. |
| Attack disruption for SAP | Defender portal only | This functionality is unavailable in the Azure portal. |
| Automation | Some automation procedures are available only in the Azure portal. And Other automation procedures are the same in the Defender and Azure portals. | The differences in the Azure portal are between workspaces that are onboarded to the Microsoft Defender portal and workspaces that aren't. |
| Data connectors: visibility of connectors used by Microsoft Defender | Azure portal only | In the Defender portal, after you onboard Microsoft Sentinel, the following data connectors that are part of Microsoft Defender aren't shown in the Data connectors page:Microsoft Defender for Cloud AppsMicrosoft Defender for EndpointMicrosoft Defender for IdentityMicrosoft Defender for Office 365 (Preview)Microsoft Defender XDRSubscription-based Microsoft Defender for Cloud (Legacy)Tenant-based Microsoft Defender for Cloud (Preview)In the Azure portal, these data connectors are still listed with the installed data connectors in Microsoft Sentinel. |
| Entities: Add entities to threat intelligence from incidents | Azure portal only | This functionality is unavailable in the Microsoft Defender portal. |
| Fusion: Advanced multistage attack detection | Azure portal only | The Fusion analytics rule, which creates incidents based on alert correlations made by the Fusion correlation engine, is disabled when you onboard Microsoft Sentinel to Microsoft Defender. Microsoft Defender uses Microsoft Defender XDR's incident-creation and correlation functionalities to replace those of the Fusion engine. |
| Incidents: Adding alerts to incidents /Removing alerts from incidents | Defender portal only | After onboarding Microsoft Sentinel to the Microsoft Defender portal, you can no longer add alerts to, or remove alerts from, incidents in the Azure portal. You can remove an alert from an incident in the Defender portal, but only by linking the alert to another incident (existing or new). |
| Incidents: editing comments | Azure portal only | After onboarding Microsoft Sentinel to the Microsoft Defender portal, you can add comments to incidents in either portal, but you can't edit existing comments. Edits made to comments in the Azure portal don't synchronize to the Microsoft Defender portal. |
| Incidents: Programmatic and manual creation of incidents | Azure portal only | Incidents created in Microsoft Sentinel through the API, by a Logic App playbook, or manually from the Azure portal, aren't synchronized to the Microsoft Defender portal. These incidents are still supported in the Azure portal and the API. |
| Incidents: Reopening closed incidents | Azure portal only | In the Microsoft Defender portal, you can't set alert grouping in Microsoft Sentinel analytics rules to reopen closed incidents if new alerts are added. Closed incidents aren't reopened in this case, and new alerts trigger new incidents. |
| Incidents: Tasks | Azure portal only | Tasks are unavailable in the Microsoft Defender portal. |
| Multiple workspace management for Microsoft Sentinel | Defender portal: Limited to one primary Microsoft Sentinel workspace Azure portal: Centrally manage multiple Microsoft Sentinel workspaces for tenants | Only one primary Microsoft Sentinel workspace can be connected in the Microsoft Defender portal. So, Microsoft Defender multitenant management supports one primary Microsoft Sentinel workspace per tenant. |

For more information, see [Capability differences between portals](/en-us/azure/sentinel/microsoft-sentinel-defender-portal?toc=%2Fdefender-xdr%2Ftoc.json&amp;bc=%2Fdefender-xdr%2Fbreadcrumb%2Ftoc.json" data-linktype="absolute-path)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/integrate-microsoft-defender-xdr-with-microsoft-sentinel/3-capability-differences-between-portals/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/integrate-microsoft-defender-xdr-with-microsoft-sentinel/3-capability-differences-between-portals/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*