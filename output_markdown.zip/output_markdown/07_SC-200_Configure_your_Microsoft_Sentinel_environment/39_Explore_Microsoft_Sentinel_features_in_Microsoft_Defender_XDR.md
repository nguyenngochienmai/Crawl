---
title: Explore Microsoft Sentinel features in Microsoft Defender XDR
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 39
url: https://learn.microsoft.com/en-us/training/modules/integrate-microsoft-defender-xdr-with-microsoft-sentinel/5-exploring-sentinel-features-in-defender-xdr/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: content
crawled_at: 2025-11-25T18:56:33.579643
---

# Explore Microsoft Sentinel features in Microsoft Defender XDR

> Explore Microsoft Sentinel features in the Microsoft Defender XDR portal.


## Explore Microsoft Sentinel features in the Defender portal

After you connect your workspace to the Defender portal, **Microsoft Sentinel** is on the left-hand side navigation pane. Pages like  **Overview**, **Incidents**, and **Advanced Hunting** have unified data from Microsoft Sentinel and Defender XDR. For more information about the unified capabilities and differences between portals, see  [Microsoft Sentinel in the Microsoft Defender portal](https://go.microsoft.com/fwlink/p/?linkid=2263690" data-linktype="external).

Many of the existing Microsoft Sentinel features are integrated into the Defender portal. For these features, notice that the experience between Microsoft Sentinel in the Azure portal and Defender portal are similar. Use the following articles to help you start working with Microsoft Sentinel in the Defender portal. When using these articles, keep in mind that your starting point in this context is the [Defender portal](https://security.microsoft.com/" data-linktype="external) instead of the Azure portal.

- Search

Search across long time spans in large datasets
Restore archived logs from search
- Search across long time spans in large datasets
- Restore archived logs from search
- Threat management

Visualize and monitor your data by using workbooks
Conduct end-to-end threat hunting with Hunts
Use hunting bookmarks for data investigations
Use hunting Livestream in Microsoft Sentinel to detect threat
Hunt for security threats with Jupyter notebooks
Add indicators in bulk to Microsoft Sentinel threat intelligence from a CSV or JSON file
Work with threat indicators in Microsoft Sentinel
Understand security coverage by the MITRE ATT&CK framework
- Visualize and monitor your data by using workbooks
- Conduct end-to-end threat hunting with Hunts
- Use hunting bookmarks for data investigations
- Use hunting Livestream in Microsoft Sentinel to detect threat
- Hunt for security threats with Jupyter notebooks
- Add indicators in bulk to Microsoft Sentinel threat intelligence from a CSV or JSON file
- Work with threat indicators in Microsoft Sentinel
- Understand security coverage by the MITRE ATT&CK framework
- Content management

Discover and manage Microsoft Sentinel out-of-the-box content
Microsoft Sentinel content hub catalog
Deploy custom content from your repository
- Discover and manage Microsoft Sentinel out-of-the-box content
- Microsoft Sentinel content hub catalog
- Deploy custom content from your repository
- Configuration

Find your Microsoft Sentinel data connector
Create custom analytics rules to detect threats
Work with near-real-time (NRT) detection analytics rules in Microsoft Sentinel
Create watchlists
Manage watchlists in Microsoft Sentinel
Create automation rules
Create and customize Microsoft Sentinel playbooks from content templates
- Find your Microsoft Sentinel data connector
- Create custom analytics rules to detect threats
- Work with near-real-time (NRT) detection analytics rules in Microsoft Sentinel
- Create watchlists
- Manage watchlists in Microsoft Sentinel
- Create automation rules
- Create and customize Microsoft Sentinel playbooks from content templates

- Search across long time spans in large datasets
- Restore archived logs from search

- Visualize and monitor your data by using workbooks
- Conduct end-to-end threat hunting with Hunts
- Use hunting bookmarks for data investigations
- Use hunting Livestream in Microsoft Sentinel to detect threat
- Hunt for security threats with Jupyter notebooks
- Add indicators in bulk to Microsoft Sentinel threat intelligence from a CSV or JSON file
- Work with threat indicators in Microsoft Sentinel
- Understand security coverage by the MITRE ATT&CK framework

- Discover and manage Microsoft Sentinel out-of-the-box content
- Microsoft Sentinel content hub catalog
- Deploy custom content from your repository

- Find your Microsoft Sentinel data connector
- Create custom analytics rules to detect threats
- Work with near-real-time (NRT) detection analytics rules in Microsoft Sentinel
- Create watchlists
- Manage watchlists in Microsoft Sentinel
- Create automation rules
- Create and customize Microsoft Sentinel playbooks from content templates

Find Microsoft Sentinel settings in the Defender portal under **System** &gt; **Settings** &gt; **Microsoft Sentinel**.


## Quick reference

Some Microsoft Sentinel capabilities, like the unified incident queue, are integrated with Microsoft Defender XDR in the Microsoft Defender portal. Many other Microsoft Sentinel capabilities are available in the **Microsoft Sentinel** section of the Defender portal.

The following image shows the **Microsoft Sentinel** menu in the Defender portal:


![Screenshot of the Defender portal left navigation menu with the Microsoft Sentinel section.](https://learn.microsoft.com/training/wwl-sci/integrate-microsoft-defender-xdr-with-microsoft-sentinel/media/navigation-defender-portal.png)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/integrate-microsoft-defender-xdr-with-microsoft-sentinel/5-exploring-sentinel-features-in-defender-xdr/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/integrate-microsoft-defender-xdr-with-microsoft-sentinel/5-exploring-sentinel-features-in-defender-xdr/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*