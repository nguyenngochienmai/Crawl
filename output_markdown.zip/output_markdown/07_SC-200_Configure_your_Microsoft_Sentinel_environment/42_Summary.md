---
title: Summary
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 42
url: https://learn.microsoft.com/en-us/training/modules/integrate-microsoft-defender-xdr-with-microsoft-sentinel/summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: summary
crawled_at: 2025-11-25T19:01:07.815298
---

# Summary

> Summary of integrating Microsoft Defender XDR and Microsoft Sentinel.

In this module, you learned about the integration of Microsoft Sentinel into the Microsoft Defender portal. This integration simplifies operations by reducing the complexity of managing multiple tools, enhancing hunting capabilities, enabling automatic attack disruption for SAP applications, and providing unified entity pages. You also learned about the differences in managing multiple Microsoft Sentinel workspaces between the Azure and Defender portals. Additionally, the module covered the prerequisites for integrating Microsoft Defender XDR with Microsoft Sentinel, including having a Log Analytics workspace with Microsoft Sentinel enabled and access to Microsoft Defender XDR in the Defender portal.

The main takeaways from this module include understanding the benefits of integrating Microsoft Sentinel into the Microsoft Defender portal, such as streamlined operations and enhanced hunting capabilities. You also learned about the unique features available in each portal and the steps to integrate Microsoft Defender XDR with Microsoft Sentinel. Furthermore, the module introduced the concept of a storage account using the example of a chocolate manufacturer, explaining how to create a storage account suitable for holding mission-critical business data.


## Additional Reading

- Microsoft Sentinel in the Microsoft Defender portal
- Frequently asked questions about the unified security operations platform


---

*Source: [https://learn.microsoft.com/en-us/training/modules/integrate-microsoft-defender-xdr-with-microsoft-sentinel/summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/integrate-microsoft-defender-xdr-with-microsoft-sentinel/summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*