---
title: Create a watchlist
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 25
url: https://learn.microsoft.com/en-us/training/modules/use-watchlists-azure-sentinel/3-create-watchlist/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: content
crawled_at: 2025-11-25T18:50:13.642825
---

# Create a watchlist

> Create a watchlist

To create a watchlist from the Azure portal perform these steps:

1. Go to Microsoft Sentinel > Configuration > Watchlist and select Add new.
2. On the General page, provide the name, description, and alias for the watchlist, then select Next.
3. On the Source page, select the dataset type, upload a file, then select Next.

 Note
File uploads are currently limited to files of up to 3.8 MB in size.
4. Review the information, and verify that it's correct. Then select Create. A notification appears once the watchlist is ready.

Go to **Microsoft Sentinel &gt; Configuration &gt; Watchlist** and select **Add new**.


![Screen shot of creating a Microsoft Sentinel Watchlist List.](https://learn.microsoft.com/training/wwl-sci/use-watchlists-azure-sentinel/media/watchlist-create.png)

On the General page, provide the name, description, and alias for the watchlist, then select **Next**.

On the Source page, select the dataset type, upload a file, then select **Next**.

File uploads are currently limited to files of up to 3.8 MB in size.

Review the information, and verify that it's correct. Then select **Create**. A notification appears once the watchlist is ready.

To use the watchlist data in KQL, use the KQL function _GetWatchlist('watchlist name').


```text
_GetWatchlist('HighValueMachines')
```


---

*Source: [https://learn.microsoft.com/en-us/training/modules/use-watchlists-azure-sentinel/3-create-watchlist/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/use-watchlists-azure-sentinel/3-create-watchlist/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*