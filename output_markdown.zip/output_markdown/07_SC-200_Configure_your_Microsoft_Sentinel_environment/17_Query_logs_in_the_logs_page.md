---
title: Query logs in the logs page
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 17
url: https://learn.microsoft.com/en-us/training/modules/query-logs-azure-sentinel/2-query-logs-page/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: content
crawled_at: 2025-11-25T18:48:06.271396
---

# Query logs in the logs page

> Query logs in the logs page

KQL is the language used to query the log data in the Log Analytics workspace. You can enter KQL queries in Microsoft Sentinel and Microsoft Defender. In Microsoft Sentinel onboarded to the Defender portal, you can access the query window from the Advanced hunting page or the Data lake exploration page. In Microsoft Sentinel, in the Azure portal, the Logs page provides access to the query window.

In the [Defender portal](https://security.microsoft.com/" data-linktype="external), select **Investigation &amp; response** &gt; **Hunting** &gt; **Advanced hunting**, or to run ad-hoc interactive KQL queries on long-term data, select **Microsoft Sentinel** &gt; **Data lake exploration** &gt; **KQL queries**. In the [Azure portal](https://portal.azure.com" data-linktype="external), the **Search** page is listed under **General**.

- Defender portal
- Azure portal

For Microsoft Sentinel in the Defender portal, you have several options for running KQL queries. In this unit we cover the two following options:

- Advanced hunting page: The query window allows you to run queries, save queries, run saved queries, create a new alert rule, and export. You can also link a result to an incident. The left side provides a list of tables and related table fields. To run a query, enter the query text and press the run button. Query results appear in the bottom section of the form.
- Data lake exploration page: To run ad-hoc interactive KQL queries on long-term data.

1. To use Advanced hunting, select Investigation & response > Hunting > Advanced hunting.
2. To use Data lake exploration, select Microsoft Sentinel > Data lake exploration > KQL queries.
3. Select the appropriate workspace from the workspace selector in the top menu.

To use *Advanced hunting*, select **Investigation &amp; response** &gt; **Hunting** &gt; **Advanced hunting**.


![Screenshot of the Advanced hunting page in the Defender portal.](https://learn.microsoft.com/training/wwl-sci/query-logs-azure-sentinel/media/advanced-hunting.png)

To use *Data lake exploration*, select **Microsoft Sentinel** &gt; **Data lake exploration** &gt; **KQL queries**.


![Screenshot of the Data lake exploration page in the Defender portal.](https://learn.microsoft.com/training/wwl-sci/query-logs-azure-sentinel/media/data-lake-kql-queries.png)

Select the appropriate workspace from the workspace selector in the top menu.


![Screenshot of the workspace selector in the Azure portal.](https://learn.microsoft.com/training/wwl-sci/query-logs-azure-sentinel/media/workspace-selector.png)

For Microsoft Sentinel in the Azure portal, you run KQL queries on the Logs page. The query window allows you to run queries, save queries, run saved queries, create a new alert rule, and export. The left side provides a list of tables and related table fields. To run a query, enter the query text and press the run button. Query results appear in the bottom section of the form.

1. In the navigation menu, expand the General section, and then select Logs to open the query window.
2. Unless you disabled it, the Queries hub page opens with a large selection of categorized sample queries.







 Note
You can prevent the Queries hub page from appearing by moving the Always show Queries Hub slider switch to the left or off.
3. Close the Queries hub by selecting the X in the upper right corner of the page.
4. The New query page opens in Simple mode. Use the dropdown menu in the upper right corner of the page to switch to KQL mode.
5. Enter your KQL query in the query editor and then select Run to execute the query.







 Note
The screenshot shows the results with a specific set of columns selected. You can customize the columns shown in the results by selecting the Columns button to the right of the results pane. You could also modify the query to specify the columns you want to see in the results.

In the navigation menu, expand the **General** section, and then select **Logs** to open the query window.

Unless you disabled it, the Queries hub page opens with a large selection of categorized sample queries.


![Screenshot of Queries hub page in the Azure portal.](https://learn.microsoft.com/training/wwl-sci/query-logs-azure-sentinel/media/queries-hub.png)

You can prevent the Queries hub page from appearing by moving the **Always show Queries Hub** slider switch to the left or off.

Close the Queries hub by selecting the **X** in the upper right corner of the page.

The New query page opens in *Simple mode*. Use the dropdown menu in the upper right corner of the page to switch to *KQL mode*.

Enter your KQL query in the query editor and then select **Run** to execute the query.


![Screenshot of the Logs page in the Azure portal.](https://learn.microsoft.com/training/wwl-sci/query-logs-azure-sentinel/media/logs-page-query.png)

The screenshot shows the results with a specific set of columns selected. You can customize the columns shown in the results by selecting the **Columns** button to the right of the results pane. You could also modify the query to specify the columns you want to see in the results.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/query-logs-azure-sentinel/2-query-logs-page/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/query-logs-azure-sentinel/2-query-logs-page/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*