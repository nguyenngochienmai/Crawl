---
title: Module assessment
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 5
url: https://learn.microsoft.com/en-us/training/modules/intro-to-azure-sentinel/5-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: quiz
crawled_at: 2025-11-25T18:43:30.555226
---

# Module assessment

> Knowledge check

Choose the best response for each question.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "What does Microsoft Sentinel provide?",
"options": [
"A solution for checking your security posture in the cloud",
"An end-to-end solution for security operations",
"A solution for securely storing keys and secrets in the cloud"
],
"correct\_answers": [
"An end-to-end solution for security operations"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "Which language is used to query data within Microsoft Sentinel?",
"options": [
"SQL",
"GraphQL",
"KQL"
],
"correct\_answers": [
"KQL"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "Which Azure service stores the log data that is ingested into Microsoft Sentinel?",
"options": [
"Azure Data Factory",
"Log Analytics",
"Azure Monitor"
],
"correct\_answers": [
"Log Analytics"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/intro-to-azure-sentinel/5-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/intro-to-azure-sentinel/5-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*