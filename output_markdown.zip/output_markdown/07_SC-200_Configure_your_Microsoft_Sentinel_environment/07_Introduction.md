---
title: Introduction
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 7
url: https://learn.microsoft.com/en-us/training/modules/create-manage-azure-sentinel-workspaces/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: introduction
crawled_at: 2025-11-25T18:45:21.231835
---

# Introduction

> Introduction

Deploying the Microsoft Sentinel environment involves designing a workspace configuration to meet your security and compliance requirements. The provisioning process includes creating a Log Analytics workspace and configuring the Microsoft Sentinel options.

You're a Security Operations Analyst working at a company that is implementing Microsoft Sentinel. You're responsible for setting up the Microsoft Sentinel environment to meet the company requirement to minimize cost, meet compliance regulations, and provide the most manageable environment for your security team to perform their daily job responsibilities.

You start by understanding the Microsoft Sentinel workspace's architecture. After you've decided on your workspace implementation options, you create your first Microsoft Sentinel workspace.

After completing this module, you'll be able to:

- Describe Microsoft Sentinel workspace architecture
- Install Microsoft Sentinel workspace
- Manage a Microsoft Sentinel workspace


## Prerequisites

Basic experience with Azure services


---

*Source: [https://learn.microsoft.com/en-us/training/modules/create-manage-azure-sentinel-workspaces/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/create-manage-azure-sentinel-workspaces/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*