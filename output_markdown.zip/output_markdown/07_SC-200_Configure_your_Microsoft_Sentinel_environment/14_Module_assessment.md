---
title: Module assessment
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 14
url: https://learn.microsoft.com/en-us/training/modules/create-manage-azure-sentinel-workspaces/8-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: quiz
crawled_at: 2025-11-25T18:47:16.959897
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/create-manage-azure-sentinel-workspaces/8-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/create-manage-azure-sentinel-workspaces/8-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*