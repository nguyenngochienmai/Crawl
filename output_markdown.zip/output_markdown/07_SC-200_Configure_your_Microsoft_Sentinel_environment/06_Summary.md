---
title: Summary
learning_path: SC-200: Configure your Microsoft Sentinel environment
module_number: 6
url: https://learn.microsoft.com/en-us/training/modules/intro-to-azure-sentinel/6-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment
type: summary
crawled_at: 2025-11-25T18:45:06.290616
---

# Summary

> Summary

You've learned how Microsoft Sentinel can meet the requirements of the SOC analyst's organization with:

- Support for data connectors for cloud and hybrid services.
- Features and functionality that you need, with minimal administration.

You explored what a SIEM solution is, and what Microsoft Sentinel and its key components have to offer. You also learned when to use Microsoft Sentinel and when other Azure products might complement Microsoft Sentinel to improve the security of your environment.

You now understand how Microsoft Sentinel helps you to perform end-to-end security operations.


## Learn more

Learn more about Microsoft Sentinel from the following articles:

- Microsoft Sentinel documentation
- Quickstart: Onboard Microsoft Sentinel
- Microsoft Sentinel pricing
- Roles and permissions in Microsoft Sentinel
- Use Azure Monitor workbooks to visualize and monitor your data
- Visualize collected data
- Extend Microsoft Sentinel across workspaces and tenants


---

*Source: [https://learn.microsoft.com/en-us/training/modules/intro-to-azure-sentinel/6-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment](https://learn.microsoft.com/en-us/training/modules/intro-to-azure-sentinel/6-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-configure-your-azure-sentinel-environment)*