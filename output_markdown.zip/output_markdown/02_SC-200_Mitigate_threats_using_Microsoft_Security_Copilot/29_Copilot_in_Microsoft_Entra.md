---
title: Copilot in Microsoft Entra
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 29
url: https://learn.microsoft.com/en-us/training/modules/security-copilot-embedded-experiences/4-copilot-for-entra/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: content
crawled_at: 2025-11-25T16:56:35.820795
---

# Copilot in Microsoft Entra

> Copilot in Microsoft Entra.

Identity risk investigation is a crucial step to defend an organization. Microsoft Entra ID Protection applies the capabilities of Microsoft Security Copilot to summarize a user's risk level, provide insights relevant to the incident at hand, and provide recommendations for rapid mitigation.

The list of Copilot capabilities embedded in Microsoft Entra is continually growing. This unit provides just a sampling of those capabilities. For more information, see documentation on Microsoft Entra.

Before you get started with Copilot in Microsoft Entra, your organization must be onboarded to Security Copilot, the Microsoft Entra plugin must be enabled in Copilot, and users must have the appropriate role permissions. Copilot assumes the permissions of the user when it tries to access the data to answer the queries, so you need to have the required permissions to access the Microsoft Entra data.

To view and investigate a user’s risky sign-ins:

1. Sign in to the Microsoft Entra admin.
2. Navigate to Protection > Identity Protection and then to the Risky users report.
3. Select a user from the risky users report.
4. Select the Summarize tab in the Risky User Details window.

Sign in to the Microsoft Entra admin.

Navigate to Protection &gt; Identity Protection and then to the Risky users report.


![Screen capture of the risky users list in Identity Protection.](https://learn.microsoft.com/training/wwl-sci/security-copilot-embedded-experiences/media/entra-risky-users-v2.png)

Select a user from the risky users report.

Select the Summarize tab in the Risky User Details window.


![Screen capture showing the Copilot generated summary.](https://learn.microsoft.com/training/wwl-sci/security-copilot-embedded-experiences/media/entra-risky-users-summarize-v2.png)

The risky user summary contains three sections:

- Summary by Copilot: summarizes in natural language why the user risk level was elevated.
- What to do: lists actionable insights tailored to the incident at hand to resolve the risk.
- Help and documentation: lists customized recommendation for how to mitigate against those types of attacks, with quick links to help and documentation.

Users can provide feedback on the generated content.


![Screen capture showing the feedback menu.](https://learn.microsoft.com/training/wwl-sci/security-copilot-embedded-experiences/media/entra-feedback.png)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/security-copilot-embedded-experiences/4-copilot-for-entra/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/security-copilot-embedded-experiences/4-copilot-for-entra/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*