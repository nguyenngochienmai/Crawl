---
title: Describe how Microsoft Security Copilot processes prompt requests
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 11
url: https://learn.microsoft.com/en-us/training/modules/security-copilot-getting-started/4-describe-how-copilot-processes-prompts/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: content
crawled_at: 2025-11-25T16:50:31.033259
---

# Describe how Microsoft Security Copilot processes prompt requests

> Describe how Microsoft Security Copilot processes prompt requests.

So now that there's a basic understanding of plugins, capabilities, and how the user interacts with Microsoft Security Copilot through prompts, it’s worth taking a look under the hood to see how these components come together to process a prompt request and help security analysts.


### Process flow

When a user submits a prompt, Copilot processes that prompt to generate the best possible response. The diagram that follows illustrates, at a high level, steps that Copilot takes to process the prompt and generate a response.


![Diagram illustrating how Microsoft Security Copilot processes a prompt request.](https://learn.microsoft.com/training/wwl-sci/security-copilot-getting-started/media/copilot-how-it-works-v2.png)

1. Submit a prompt: The process starts when a user submits a prompt in the prompt bar.
2. Orchestrator: Security Copilot sends the information to the Copilot backend referred to as the orchestrator. The orchestrator is Copilot’s system for composing capabilities together to answer a user’s prompt. It determines the initial context and builds a plan using all the available capabilities (skills).
3. Build context: Once a plan is defined and built, Copilot executes that plan to get the required data context to answer the prompt.
4. Plugins: In the course of executing the plan, Copilot analyzes all data and patterns to provide intelligent insights. This includes reasoning over all the plugins and sources of data, enabled and available to Copilot.
5. Responding: Copilot combines all the data and context and uses the power of its advanced LLM to compose a response using language that makes sense to a human being.
6. Response: Before the response can be sent back to the user, Copilot formats and reviews the response as part of Microsoft's commitment to responsible AI.
7. Receives response: The process culminates with the user receiving the response from the Copilot.

Submit a prompt: The process starts when a user submits a prompt in the prompt bar.

Orchestrator: Security Copilot sends the information to the Copilot backend referred to as the orchestrator. The orchestrator is Copilot’s system for composing capabilities together to answer a user’s prompt. It determines the initial context and builds a plan using all the available capabilities (skills).

Build context: Once a plan is defined and built, Copilot executes that plan to get the required data context to answer the prompt.

Plugins: In the course of executing the plan, Copilot analyzes all data and patterns to provide intelligent insights. This includes reasoning over all the plugins and sources of data, enabled and available to Copilot.

Responding: Copilot combines all the data and context and uses the power of its advanced LLM to compose a response using language that makes sense to a human being.

Response: Before the response can be sent back to the user, Copilot formats and reviews the response as part of Microsoft's commitment to responsible AI.

Receives response: The process culminates with the user receiving the response from the Copilot.


#### Process log

During this process, Copilot generates a process log that is visible to the user. The user can see what capability is used to generate the response. This is important because it enables the user to determine whether the response was generated from a trusted source. In the screenshot that follows, the process log shows that Copilot chose the Incident Analysis capability. The process log also shows that the final output went through safety checks, which is part of Microsoft’s commitment to responsible AI.


![Screen capture of the process log that highlights the capability selected and the text indicating that Copilot ran safety checks as part of the process to compose the response message.](https://learn.microsoft.com/training/wwl-sci/security-copilot-getting-started/media/process-log-new.png)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/security-copilot-getting-started/4-describe-how-copilot-processes-prompts/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/security-copilot-getting-started/4-describe-how-copilot-processes-prompts/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*