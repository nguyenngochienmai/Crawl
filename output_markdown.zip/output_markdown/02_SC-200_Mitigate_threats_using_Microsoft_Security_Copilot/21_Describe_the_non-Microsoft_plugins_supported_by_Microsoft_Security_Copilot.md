---
title: Describe the non-Microsoft plugins supported by Microsoft Security Copilot
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 21
url: https://learn.microsoft.com/en-us/training/modules/security-copilot-describe-core-features/4-describe-non-microsoft-plugins/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: content
crawled_at: 2025-11-25T16:52:02.347234
---

# Describe the non-Microsoft plugins supported by Microsoft Security Copilot

> Describe the non-Microsoft plugins supported by Microsoft Security Copilot.

Microsoft Security Copilot supports non-Microsoft plugins to extend Copilot's capabilities. These plugins are categorized as:

- Other
- Websites
- Custom


#### Other plugins

Other plugins give Copilot access to information and capabilities from services beyond Microsoft that your organization uses.

If a Copilot owner has restricted plugin access, then those plugins that have been set to restricted will show greyed out and restricted.


![Screen capture of the non-Microsoft plugins.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/plugins-other.png)

The list of Other plugins currently supported is long and continually growing. The list that follows is only a subset of non-Microsoft Plugins currently in preview with Copilot.

- CIRCL Hash Lookup (Preview)
- Security Copilot Plugin for ServiceNow (Preview)
- Security Copilot Plugin for Splunk (Preview)
- CrowdSec Threat Intelligence (Preview)
- GreyNoise Community (Preview)
- GreyNoise Enterprise (Preview)

Access to these plugins assumes an account and license to the specific service and a setup that includes authentication. The type of authentication required is determined by the plugin provided. For example, the CrowdSec Threat Intelligence plugin requires an access identifier for API authentication.


![Screen capture of the authentication settings for the CrowdSec Threat Intelligence plugin.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/crowd-sec-threat-intelligence-authentication.png)


#### Websites

The websites plugins give Copilot access to industry information from the public web. Currently, the public web plugin is supported. More website plugins are expected.

The website plugins are accessed using anonymous authentication.


![Screen capture of the website plugins.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/plugins-websites.png)


#### Custom

The Microsoft Security Copilot platform enables developers and users to write their own plugins that can be invoked to perform specialized tasks.


![Screen capture of the custom plugins.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/plugins-custom.png)

There are two types of custom plugins:

- Custom Copilot plugins that you develop
- Custom plugins developed with OpenAI’s API.

Regardless of the approach, every Copilot plugin requires a YAML or JSON formatted manifest file (for example: plugin.yaml or plugin.json) which describes metadata about the skill set and how to invoke the skills.

Owner settings, described in a previous unit, determines who can add and manage their own custom plugins and who can add and manage custom plugins for everyone in the organization. For Copilot users with the contributor role, availability of the option to set "Who can use this plugin" is dependent on how the owner settings for custom plugins are configured.


![Screen capture showing the two types of custom plugins.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/custom-plugin-options-v2.png)

Once a custom plugin is added, it can be turned on or off, updated, or deleted.

To Learn more about custom plugins, see [Create your own custom plugins](/en-us/copilot/security/custom-plugins" data-linktype="absolute-path).

Watch this short video for a summary on setting up non-Microsoft plugins.


📺 **Embedded Content**: [https://learn-video.azurefd.net/vod/player?id=f57f9efb-d800-4436-85cb-02f34811c608&locale=en-us&embedUrl=%2Ftraining%2Fmodules%2Fsecurity-copilot-describe-core-features%2F4-describe-non-microsoft-plugins](https://learn-video.azurefd.net/vod/player?id=f57f9efb-d800-4436-85cb-02f34811c608&locale=en-us&embedUrl=%2Ftraining%2Fmodules%2Fsecurity-copilot-describe-core-features%2F4-describe-non-microsoft-plugins)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/security-copilot-describe-core-features/4-describe-non-microsoft-plugins/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/security-copilot-describe-core-features/4-describe-non-microsoft-plugins/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*