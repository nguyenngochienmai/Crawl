---
title: Describe custom promptbooks
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 22
url: https://learn.microsoft.com/en-us/training/modules/security-copilot-describe-core-features/5-describe-custom-promptbooks/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: content
crawled_at: 2025-11-25T16:52:12.294322
---

# Describe custom promptbooks

> Learn about custom promptbooks and how you can create them.

Promptbooks in Security Copilot are collections of prompts put together to accomplish specific security-related tasks. They run one prompt after another, building on previous responses.

You can create your own promptbook with the promptbook builder to automate investigation flows and optimize repetitive steps in Copilot that are customized to your needs and requirements. You can also share the promptbooks you created with other users so they can also benefit from your work.


### Create a promptbook from an existing session

To create your own promptbook, you can start with an existing session that contains the prompts you want to work with. For this example, the session titled, "Show the last three failed login attempts," is used.


![Screen capture showing the session to use as the basis for your custom promptbook.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/select-session.png)

After selecting the desired session, select the boxes beside the prompts to include them or select the top box to include all prompts in the session. Selecting any or all of the prompts light up the Create promptbook button.


![Screen capture of the create promptbook icon.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/select-create-promptbook-v4.png)

Once you select the create promptbook icon, the Create a promptbook page opens. Here you name the promptbook, add a tag and a description, add more prompts, and remove or edit existing prompts. If any of the prompts require an input parameter, you would need to specify an easily understood parameter name within angle brackets and no spaces. For example, if one of the prompts requires an incident ID number, you can specify &lt;IncidentID&gt;. Similarly, if a prompt requires that you enter a threat actor name, you could specify the input parameter as &lt;threatactorname&gt; or &lt;ThreatActor&gt;. You can include more than one input parameter. You can also select to share the promptbook with others in your organization or have it for your own personal use.

In the screenshot that follows, the promptbook is named Failed-Login-Attempts and it includes two prompts. The first prompt was originally to show the last three failed logins. To configure the number as an input parameter, select the ellipses next to the prompt to edit it by replacing the number 3 and entering &lt;number&gt;.


![Screen capture of the parameters to create a custom promptbook.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/create-promptbook-options-v3.png)

A pop-up window appears once your promptbook is created. From this window, you can select to view the promptbook you just created and then run it or edit it, share your promptbook via link, or go to the promptbook library.


![Screen capture of pop-up window for the newly created promptbook including the copy icon next to the name.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/promptbook-created.png)

From then on, you can run your promptbook like you would any other promptbook. You can select the prompts icon from the prompt bar and start typing in the name of the promptbook in the search bar then selecting it from the list that appears.


![Screen capture of the prompt bar showing the list of promptbooks.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/create-promptbook-run-from-prompt-bar-v3.png)

Selecting the promptbook opens it. From here, you enter the required input parameter and then select run.


![Screen capture promptbook, including the input parameter.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/create-promptbook-run-v3.png)

Watch this short video for a summary on creating a promptbook.


📺 **Embedded Content**: [https://learn-video.azurefd.net/vod/player?id=e23f15a4-80a4-445e-aaac-34f1fe14a53b&locale=en-us&embedUrl=%2Ftraining%2Fmodules%2Fsecurity-copilot-describe-core-features%2F5-describe-custom-promptbooks](https://learn-video.azurefd.net/vod/player?id=e23f15a4-80a4-445e-aaac-34f1fe14a53b&locale=en-us&embedUrl=%2Ftraining%2Fmodules%2Fsecurity-copilot-describe-core-features%2F5-describe-custom-promptbooks)


### Edit a promptbook

To edit your existing promptbook, select the home menu (hamburger icon) and select Promptbook library.


![Screen capture of the home menu options including the promptbook library option.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/select-promptbook-library-v3.png)

Select the ellipses for the promptbook you want to edit then select Edit from the options. You can only edit existing promptbooks if you're the owner of the promptbook.


![Screen capture of the edit option for your custom promptbook.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/my-promptbooks-library-edit-v2.png)

In addition to editing, you can also choose to view the details of the promptbook, duplicate it, or delete it. You can also choose to run the promptbook by selecting the Get started button.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/security-copilot-describe-core-features/5-describe-custom-promptbooks/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/security-copilot-describe-core-features/5-describe-custom-promptbooks/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*