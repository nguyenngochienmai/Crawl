---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 6
url: https://learn.microsoft.com/en-us/training/modules/fundamentals-generative-ai/8-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: quiz
crawled_at: 2025-11-25T16:35:10.049239
---

# Module assessment

> Check your understanding of the concepts covered in this module.



---

## Knowledge Check


[
{
"question\_number": 1,
"question": "What is a large language model (LLM)?",
"options": [
"A type of AI model designed to generate human-like text.",
"A model that only processes images, not text.",
"A small, efficient model for mobile devices."
],
"correct\_answers": [
"A type of AI model designed to generate human-like text."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "What is the purpose of tokenization?",
"options": [
"To sort the words in a sentence alphabetically",
"To break down text into smaller units.",
"To convert text into binary code for processing by computers."
],
"correct\_answers": [
"To break down text into smaller units."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "What are embeddings?",
"options": [
"Extra words added by a transformer model to enhance text generation.",
"Small language models used for specific tasks.",
"Vector-based representations of tokens that capture their semantic meaning."
],
"correct\_answers": [
"Vector-based representations of tokens that capture their semantic meaning."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 4,
"question": "What does an attention layer do in a transformer model?",
"options": [
"Removes irrelevant words from the input text.",
"Examines the relationships between each token and the tokens around it.",
"Flags inappropriate content in the generated text."
],
"correct\_answers": [
"Examines the relationships between each token and the tokens around it."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 5,
"question": "What is the purpose of a system prompt?",
"options": [
"To provide context and instructions to the AI model.",
"To configure a generative AI model to run on a particular operating system.",
"To store user preferences for future interactions."
],
"correct\_answers": [
"To provide context and instructions to the AI model."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 6,
"question": "What is an agent in the context of AI?",
"options": [
"An AI system that can perform tasks on behalf of a user.",
"A generative AI model that operates in secret.",
"A human operator to whom generative AI models escalate requests they can't handle."
],
"correct\_answers": [
"An AI system that can perform tasks on behalf of a user."
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/fundamentals-generative-ai/8-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/fundamentals-generative-ai/8-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*