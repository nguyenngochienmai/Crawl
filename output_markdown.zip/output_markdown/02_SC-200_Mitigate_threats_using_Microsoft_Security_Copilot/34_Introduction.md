---
title: Introduction
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 34
url: https://learn.microsoft.com/en-us/training/modules/security-copilot-exercises/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: introduction
crawled_at: 2025-11-25T17:10:52.506742
---

# Introduction

> Explore Microsoft Security Copilot with lab-like exercises.

This module guides you through a series of simulation-based exercises that mimic real-world situations, helping you understand how to effectively use Microsoft Security Copilot in your own work environment.

The exercises covered in this module include:

- Setting Up and provisioning Microsoft Security Copilot.
- Exploring the standalone experience of Microsoft Security Copilot.
- Managing sources.
- Working with prompts and promptbooks.
- Exploring the features of the different embedded experiences.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/security-copilot-exercises/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/security-copilot-exercises/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*