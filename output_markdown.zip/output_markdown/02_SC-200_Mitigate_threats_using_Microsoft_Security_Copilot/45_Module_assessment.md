---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 45
url: https://learn.microsoft.com/en-us/training/modules/security-copilot-exercises/10-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: quiz
crawled_at: 2025-11-25T17:12:34.335276
---

# Module assessment

> Knowledge check for explore use cases of Microsoft Security Copilot.



---

## Knowledge Check


[
{
"question\_number": 1,
"question": "How do you provision capacity for Microsoft Security Copilot?",
"options": [
"You can provision capacity by selecting the 'Owner settings' option and then choosing 'Provision capacity.'",
"You can provision capacity by selecting the help icon and entering Provision Capacity.",
"You can provision capacity by running the wizard that is part of the first run experience Microsoft Security Copilot. Or, by selecting 'Microsoft Security Copilot compute capacities' in the Azure portal and completing the steps."
],
"correct\_answers": [
"You can provision capacity by running the wizard that is part of the first run experience Microsoft Security Copilot. Or, by selecting 'Microsoft Security Copilot compute capacities' in the Azure portal and completing the steps."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "When you add a custom plugin, what are the options that you select as part of the upload process?",
"options": [
"You can select 'Who can use this plugin' and you upload a file in the format of .docx, .pdf, .txt, or .md.",
"You can select 'Who can use this plugin' and you select whether you're uploading a Security Copilot plugin or an OpenAI plugin.",
"You start by enabling the option 'Allow Security Copilot to access data from your Microsoft 365 services' then you select whether you're uploading a Security Copilot plugin or an OpenAI plugin."
],
"correct\_answers": [
"You can select 'Who can use this plugin' and you select whether you're uploading a Security Copilot plugin or an OpenAI plugin."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "Which option best describes the steps involved in creating a custom promptbook.",
"options": [
"From the owner settings, select the custom promptbook icon, follow the steps in the Create a promptbook page, and select create.",
"Start with an existing session. Select the prompts you want to reuse. Then, select the custom promptbook icon, follow the steps in the Create a promptbook page, and select create.",
"Select the Sources icon, select files, then upload a .json formatted file that contains the details of the promptbook."
],
"correct\_answers": [
"Start with an existing session. Select the prompts you want to reuse. Then, select the custom promptbook icon, follow the steps in the Create a promptbook page, and select create."
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/security-copilot-exercises/10-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/security-copilot-exercises/10-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*