---
title: Explore the capabilities of Copilot in Microsoft Defender XDR
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 42
url: https://learn.microsoft.com/en-us/training/modules/security-copilot-exercises/8-explore-embedded-defender-xdr/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: content
crawled_at: 2025-11-25T17:12:05.313378
---

# Explore the capabilities of Copilot in Microsoft Defender XDR

> Explore the capabilities of Copilot in Microsoft Defender XDR.

In this exercise, you investigate an incident in Microsoft Defender XDR. As part of the investigation, you explore the key features of Copilot in Microsoft Defender XDR, including incident summary, device summary, script analysis, and more. You also pivot your investigation to the standalone experience and use the pin board as a way to share details of your investigation with your colleagues.

The environment for this exercise is a simulation generated from the product. As a limited simulation, links on a page may not be enabled and text-based inputs that fall outside of the specified script may not be supported. A pop-up message displays stating, "This feature is not available within the simulation." When this occurs, select OK and continue the exercise steps.


![Screenshot of pop-up screen indicating that this feature isn't available within the simulation.](https://learn.microsoft.com/training/wwl-sci/security-copilot-exercises/media/simulation-pop-up-error.png)


### Exercise

For this exercise, you're logged in as Avery Howard and have the Copilot owner role. You work in Microsoft Defender, using the new unified security operations platform, to access the embedded Copilot capabilities in Microsoft Defender XDR. Towards the end of the exercise, you pivot to the standalone experience of Microsoft Security Copilot.

This exercise should take approximately **30** minutes to complete.

When a lab instruction calls for opening a link to the simulated environment, it's recommended that you open the link in a new browser window so that you can simultaneously view the instructions and the exercise environment. To do so, select the right mouse key and select the option.


#### Task: Explore Incident summary and guided responses

1. Open the simulated environment by selecting this link: Microsoft Defender portal.
2. From the Microsoft Defender portal:

Expand Investigation & response.
Expand  Incidents & alerts.
Select Incidents.
3. Expand Investigation & response.
4. Expand  Incidents & alerts.
5. Select Incidents.
6. Select the first incident in the list, Incident Id: 185856 named Human-operated ransomware attack was launched from a compromised asset (attack disruption).
7. This incident is complex. Defender XDR provides a great deal of information, but with 50 alerts it can be a challenge to know where to focus. On the right side of the incident page, Copilot automatically generates an Incident summary that helps guide your focus and response. Select See more.

Copilot's summary describes how this incident evolved, including initial access, lateral movement, collection, credential access, and exfiltration. It identifies specific devices, indicates that the PsExec tool was used to launch executable files, and more.
This information can be used for further investigation. You explore some of them in subsequent tasks.
8. Copilot's summary describes how this incident evolved, including initial access, lateral movement, collection, credential access, and exfiltration. It identifies specific devices, indicates that the PsExec tool was used to launch executable files, and more.
9. This information can be used for further investigation. You explore some of them in subsequent tasks.
10. Scroll down on the Copilot panel and just beneath the summary are Guided responses. Guided responses recommend actions in support of triage, containment, investigation, and remediation.

The first item in the triage category it to Classify this incident. Select Classify to view the options. Review the guided responses in the other categories.
Select the Status button at the top of the guided responses section and filter on Completed. Two completed activities show labeled as Attack Disruption. Automatic attack disruption is designed to contain attacks in progress, limit the impact on an organization's assets, and provide more time for security teams to remediate the attack fully.
11. The first item in the triage category it to Classify this incident. Select Classify to view the options. Review the guided responses in the other categories.
12. Select the Status button at the top of the guided responses section and filter on Completed. Two completed activities show labeled as Attack Disruption. Automatic attack disruption is designed to contain attacks in progress, limit the impact on an organization's assets, and provide more time for security teams to remediate the attack fully.
13. Keep the incident page open, you'll use it in the next task.

Open the simulated environment by selecting this link: **[Microsoft Defender portal](https://app.highlights.guide/start/be8a91c3-3979-4048-ad38-fd38deaf7117?token=045faae1-1078-4eac-bf56-e12472eddaf9" data-linktype="external" target="az-portal" class="has-external-link-indicator)**.

From the Microsoft Defender portal:

1. Expand Investigation & response.
2. Expand  Incidents & alerts.
3. Select Incidents.

Select the first incident in the list, **Incident Id: 185856** named Human-operated ransomware attack was launched from a compromised asset (attack disruption).

This incident is complex. Defender XDR provides a great deal of information, but with 50 alerts it can be a challenge to know where to focus. On the right side of the incident page, Copilot automatically generates an **Incident summary** that helps guide your focus and response. Select **See more**.

1. Copilot's summary describes how this incident evolved, including initial access, lateral movement, collection, credential access, and exfiltration. It identifies specific devices, indicates that the PsExec tool was used to launch executable files, and more.
2. This information can be used for further investigation. You explore some of them in subsequent tasks.

Scroll down on the Copilot panel and just beneath the summary are **Guided responses**. Guided responses recommend actions in support of triage, containment, investigation, and remediation.

1. The first item in the triage category it to Classify this incident. Select Classify to view the options. Review the guided responses in the other categories.
2. Select the Status button at the top of the guided responses section and filter on Completed. Two completed activities show labeled as Attack Disruption. Automatic attack disruption is designed to contain attacks in progress, limit the impact on an organization's assets, and provide more time for security teams to remediate the attack fully.

Keep the incident page open, you'll use it in the next task.


#### Task:  Explore device and identity summary

1. From the incident page (under the Attack story tab), in the Alerts section, find and select the alert titled: Suspicious RDP session
2. Copilot  automatically generates an Alert summary, which provides a wealth of information for further analysis. For example, the summary identifies suspicious activity, it identifies data collection activities, credential access, malware, discovery activities, and more.
3. There's much information on the page, so to get a better view of this alert, select Open alert page. It's on the third panel on the alert page, next to the incident graph and below the alert title.
4. On the top of the page, is card for the device parkcity-win10v. Select the ellipses and note the options. Select Summarize. Copilot generates a Device summary. It's worth noting that there are many ways you can access device summary and this way is just one convenient method. The summary shows the device is a VM, identifies the owner of the device, it shows its compliance status against Intune policies, and more.
5. Next to the device card is a card for the owner of the device. Select parkcity\jonaw. The third panel on the page updates from showing details of the alert to providing information about the user. In this case, Jonathan Wolcott, an account executive, whose Insider risk severity is classified as High. These details aren't surprising given what you learned from the Copilot incident and alert summaries. Select Summarize to obtain an identity summary generated by Copilot.
6. Keep the alert page open, you'll use it in the next task.

From the incident page (under the Attack story tab), in the Alerts section, find and select the alert titled: **Suspicious RDP session**

Copilot  automatically generates an **Alert summary**, which provides a wealth of information for further analysis. For example, the summary identifies suspicious activity, it identifies data collection activities, credential access, malware, discovery activities, and more.

There's much information on the page, so to get a better view of this alert, select **Open alert page**. It's on the third panel on the alert page, next to the incident graph and below the alert title.

On the top of the page, is card for the device **parkcity-win10v**. Select the ellipses and note the options. Select **Summarize**. Copilot generates a **Device summary**. It's worth noting that there are many ways you can access device summary and this way is just one convenient method. The summary shows the device is a VM, identifies the owner of the device, it shows its compliance status against Intune policies, and more.

Next to the device card is a card for the owner of the device. Select **parkcity\jonaw**. The third panel on the page updates from showing details of the alert to providing information about the user. In this case, *Jonathan Wolcott*, an account executive, whose Insider risk severity is classified as *High*. These details aren't surprising given what you learned from the Copilot incident and alert summaries. Select **Summarize** to obtain an identity summary generated by Copilot.

Keep the alert page open, you'll use it in the next task.


#### Task:  Explore script analysis

1. Let's Focus on the alert story. Select Maximize , located on the main panel of the alert, just beneath the card labeled 'partycity\jonaw' to get a better view of the process tree. From maximized view, you begin to get a clearer view of how this incident came to be. Many line items indicate that powershell.exe executed a script. Since the user Jonathan Wolcott is an account executive, it's reasonable to assume that executing PowerShell scripts isn't something this user is likely to be doing regularly.
2. Expand the first instance of powershell.exe executed a script. Copilot has the capability to analyze scripts. Select Analyze.

Copilot generates an analysis of the script and suggests it could be a phishing attempt or used to deliver a web-based exploit.
Select Show code. The code shows nested PowerShell modules and versions.
3. Copilot generates an analysis of the script and suggests it could be a phishing attempt or used to deliver a web-based exploit.
4. Select Show code. The code shows nested PowerShell modules and versions.
5. There are several other items that indicate powershell.exe executed a script. Expand the one labeled powershell.exe -EncodedCommand.... The original script was base 64 encoded, but Defender decoded that for you. For the decoded version, select Analyze. The analysis highlights the sophistication of the script used in this attack.
6. In the Copilot Script analysis, you have buttons for Show code and Show MITRE techniques
7. Select the Show MITRE Techniques button and select the link labeled: T1105: Ingress Tool Transfer
8. This opens the MITRE | ATT&CK site page describing the technique in detail.
9. Close the alert story page by selecting the X (the X that is to the left of Copilot panel). Now use the breadcrumb to return to the incident. Select Human-operated ransomware attack was launched from a compromised asset (attack disruption).

Let's Focus on the alert story. Select **Maximize **, located on the main panel of the alert, just beneath the card labeled 'partycity\jonaw' to get a better view of the process tree. From maximized view, you begin to get a clearer view of how this incident came to be. Many line items indicate that powershell.exe executed a script. Since the user Jonathan Wolcott is an account executive, it's reasonable to assume that executing PowerShell scripts isn't something this user is likely to be doing regularly.


![maximize icon](https://learn.microsoft.com/training/wwl-sci/security-copilot-exercises/media/maximize-icon.png)

Expand the first instance of **powershell.exe executed a script**. Copilot has the capability to analyze scripts. Select **Analyze**.

1. Copilot generates an analysis of the script and suggests it could be a phishing attempt or used to deliver a web-based exploit.
2. Select Show code. The code shows nested PowerShell modules and versions.

There are several other items that indicate powershell.exe executed a script. Expand the one labeled **powershell.exe -EncodedCommand...**. The original script was base 64 encoded, but Defender decoded that for you. For the decoded version, select **Analyze**. The analysis highlights the sophistication of the script used in this attack.

In the Copilot Script analysis, you have buttons for Show code and Show MITRE techniques

Select the **Show MITRE Techniques** button and select the link labeled: T1105: Ingress Tool Transfer

This opens the *MITRE | ATT&amp;CK* site page describing the technique in detail.

Close the alert story page by selecting the **X** (the X that is to the left of Copilot panel). Now use the breadcrumb to return to the incident. Select **Human-operated ransomware attack was launched from a compromised asset (attack disruption)**.


#### Task:  Explore file analysis

1. You're back at the incident page. In the alert summary, Copilot identified the file mimikatz.exe, which is associated with the 'Mimikatz' malware. You can use the file analysis capability in Defender XDR to see what other insights you can get. There are several ways to access files. From the top of the page, select the Evidence and Response tab.
2. From the left side of the screen select Files.
3. Select the first item from the list with the entity named mimikatz.exe.
4. From the window that opens, select Open file page.
5. Select the Copilot icon (if File analysis doesn’t automatically open), and Copilot generates a File analysis.
6. Review the detailed file analysis that Copilot generates.
7. Close the File page and use the breadcrumb to return to the incident. Select Human-operated ransomware attack was launched from a compromised asset (attack disruption).

You're back at the incident page. In the alert summary, Copilot identified the file mimikatz.exe, which is associated with the 'Mimikatz' malware. You can use the file analysis capability in Defender XDR to see what other insights you can get. There are several ways to access files. From the top of the page, select the **Evidence and Response** tab.

From the left side of the screen select **Files**.

Select the first item from the list with the entity named **mimikatz.exe**.

From the window that opens, select **Open file page**.

Select the Copilot icon (if File analysis doesn’t automatically open), and Copilot generates a File analysis.

Review the detailed file analysis that Copilot generates.

Close the File page and use the breadcrumb to return to the incident. Select **Human-operated ransomware attack was launched from a compromised asset (attack disruption)**.


#### Task: Pivot to the standalone experience

This task is complex and requires the involvement of more senior analysts. In this task, you pivot your investigation and run the Defender incident promptbook, so the other analysts have a running start on the investigation. You pin responses to the pin board and generate a link to this investigation that you can share with more advanced members of the team to help investigate.

1. Return to the incident page by selecting the Attack story tab from the top of the page.
2. Select the ellipses next to Copilot's Incident summary and select Open in Security Copilot.
3. Copilot opens in the standalone experience and shows the incident summary. You can also run more prompts. In this case, you run the promptbook for an incident. Select the prompt icon .

Select the Microsoft 365 Defender incident investigation promptbook.
The promptbook page opens and asks for the Defender Incident ID. Enter 185856, then select the Submit button.
Review the information provided. When you pivot to the standalone experience and run the promptbook, the investigation is able to invoke capabilities from a broader set security solution, beyond just Defender XDR, based on the plugins enabled.
4. Select the Microsoft 365 Defender incident investigation promptbook.
5. The promptbook page opens and asks for the Defender Incident ID. Enter 185856, then select the Submit button.
6. Review the information provided. When you pivot to the standalone experience and run the promptbook, the investigation is able to invoke capabilities from a broader set security solution, beyond just Defender XDR, based on the plugins enabled.
7. Select the box icon  next to the pin icon to select all the prompts and the corresponding responses, then select the Pin icon  to save those responses to the pin board.
8. The pin board opens automatically. The pin board holds your saved prompts and responses, along with a summary of each one. You can open and close the pin board by selecting the pin board icon .
9. From the top of the page, select Share to view your options. When you share the incident via a link or email, people in your organization with Copilot access can view this session. Close the window by selecting the X.

Return to the incident page by selecting the **Attack story** tab from the top of the page.

Select the ellipses next to Copilot's Incident summary and select **Open in Security Copilot**.

Copilot opens in the standalone experience and shows the incident summary. You can also run more prompts. In this case, you run the promptbook for an incident. Select the **prompt icon** .


![prompt icon](https://learn.microsoft.com/training/wwl-sci/security-copilot-exercises/media/prompt-icon.png)

1. Select the Microsoft 365 Defender incident investigation promptbook.
2. The promptbook page opens and asks for the Defender Incident ID. Enter 185856, then select the Submit button.
3. Review the information provided. When you pivot to the standalone experience and run the promptbook, the investigation is able to invoke capabilities from a broader set security solution, beyond just Defender XDR, based on the plugins enabled.

Select the **box icon ** next to the pin icon to select all the prompts and the corresponding responses, then select the **Pin icon ** to save those responses to the pin board.


![box icon](https://learn.microsoft.com/training/wwl-sci/security-copilot-exercises/media/box-icon.png)


![pin icon](https://learn.microsoft.com/training/wwl-sci/security-copilot-exercises/media/pin-icon.png)

The pin board opens automatically. The pin board holds your saved prompts and responses, along with a summary of each one. You can open and close the pin board by selecting the **pin board icon **.


![pin board icon](https://learn.microsoft.com/training/wwl-sci/security-copilot-exercises/media/pinboard-icon.png)

From the top of the page, select **Share** to view your options. When you share the incident via a link or email, people in your organization with Copilot access can view this session. Close the window by selecting the **X**.


#### Task: Create and run a KQL query

Next, we'll use Copilot to help us create a KQL (Kusto Query Language) query to use with Advanced hunting in Defender XDR.

1. While still in standalone Security Copilot, enter the following prompt in the prompt form:
Based on this incident, create a query to proactively hunt for this type of malware attack. Use the woodgrove-loganalyticsworkspace.
2. Press the Submit prompt icon to run your prompt.
Copilot chooses Natural language to KQL for advanced hunting.
3. Copilot generates a KQL query and a response:

Read through the Explanation of the Kusto Query.

Review the Breakdown of the Kusto Query. This is very helpful if you’re just getting started with KQL.
4. Read through the Explanation of the Kusto Query.
5. Review the Breakdown of the Kusto Query. This is very helpful if you’re just getting started with KQL.
6. Copy the KQL query Copilot generated and return to the Defender XDR portal.
It's recommended that you copy the query into Notepad or another editor first to reduce formatting problems.
7. Defender XDR should still have the Investigations & response section open. Select Hunting and then Advanced hunting from the navigation menu.
8. In Advanced hunting, select the New query + to open a new window and paste the KQL query generated by Copilot into the form.
It's recommended that you copy the query into Notepad or another editor first to reduce formatting problems.
9. After running the KQL query, you can return to Copilot to refine the query or select the Copilot icon on the Advanced hunting query page to fine-tune hunting queries.
10. You can now close the browser tab to exit the simulation.

While still in standalone Security Copilot, enter the following prompt in the prompt form:
*Based on this incident, create a query to proactively hunt for this type of malware attack. Use the woodgrove-loganalyticsworkspace.*

Press the Submit prompt icon to run your prompt.
Copilot chooses Natural language to KQL for advanced hunting.

Copilot generates a KQL query and a response:

1. Read through the Explanation of the Kusto Query.
2. Review the Breakdown of the Kusto Query. This is very helpful if you’re just getting started with KQL.

Read through the Explanation of the Kusto Query.

Review the Breakdown of the Kusto Query. This is very helpful if you’re just getting started with KQL.

Copy the KQL query Copilot generated and return to the Defender XDR portal.
***It's recommended that you copy the query into Notepad or another editor first to reduce formatting problems***.

Defender XDR should still have the Investigations &amp; response section open. Select **Hunting** and then **Advanced hunting** from the navigation menu.

In Advanced hunting, select the **New query +** to open a new window and paste the KQL query generated by Copilot into the form.
***It's recommended that you copy the query into Notepad or another editor first to reduce formatting problems***.

After running the KQL query, you can return to Copilot to refine the query or select the Copilot icon on the Advanced hunting query page to fine-tune hunting queries.

You can now close the browser tab to exit the simulation.


#### Review

This incident is complex. There's a great deal of information to digest and Copilot helps summarize the incident, individual alerts, scripts, devices, identities, and files. Complex investigations like this one might require the involvement of several analysts. Copilot facilitates this situation by easily sharing details of an investigation.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/security-copilot-exercises/8-explore-embedded-defender-xdr/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/security-copilot-exercises/8-explore-embedded-defender-xdr/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*