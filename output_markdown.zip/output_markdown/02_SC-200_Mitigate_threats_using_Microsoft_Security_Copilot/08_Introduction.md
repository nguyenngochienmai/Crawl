---
title: Introduction
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 8
url: https://learn.microsoft.com/en-us/training/modules/security-copilot-getting-started/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: introduction
crawled_at: 2025-11-25T16:50:05.398402
---

# Introduction

> Get started with Microsoft Security Copilot, an AI-powered, cloud-based security analysis tool that enables analysts to respond to threats quickly, process signals at machine speed, and assess risk more quickly than may otherwise be possible.

Organizations face unprecedented challenges, in the rapidly evolving digital landscape, such as increasingly sophisticated cyber threats and a significant talent shortage in cybersecurity. Microsoft Security Copilot is a cloud-based, AI-powered security analysis tool that is designed to address these challenges. It enables analysts to process security signals and respond to threats at a machine speed that far surpasses human capabilities, thus revolutionizing the way organizations approach cybersecurity.

After completing this module, you'll be able to:

- Describe what Microsoft Security Copilot is.
- Describe the terminology of Microsoft Security Copilot.
- Describe how Microsoft Security Copilot processes prompt requests.
- Describe the elements of an effective prompt.
- Describe how to enable Microsoft Security Copilot.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/security-copilot-getting-started/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/security-copilot-getting-started/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*