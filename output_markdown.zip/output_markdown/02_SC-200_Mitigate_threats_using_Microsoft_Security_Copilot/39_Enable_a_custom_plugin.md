---
title: Enable a custom plugin
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 39
url: https://learn.microsoft.com/en-us/training/modules/security-copilot-exercises/5-enable-custom-plugin/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: content
crawled_at: 2025-11-25T17:11:34.827595
---

# Enable a custom plugin

> Enable a custom plugin.

In this exercise, you experiment with a custom plugin. You start by checking the owner settings for who can add and manage their own custom plugins and who can add and manage custom plugins for everyone in the organization. Once you configure the owner settings, you upload the file for your custom plugin. Uploading the files adds the plugin capability to Copilot. Once the plugin is added, you validate that is shows up as a system capability and start using it.

The creation of the YAML or JSON plugin manifest file, which describes metadata about the plugin and how to invoke it, is outside the scope of this content, but you can obtain more information by visiting [Create your own custom plugins](/en-us/copilot/security/custom-plugins" data-linktype="absolute-path).

The environment for this exercise is a simulation generated from the product. As a limited simulation, links on a page may not be enabled and text-based inputs that fall outside of the specified script may not be supported. A pop-up message displays stating, "This feature is not available within the simulation." When this occurs, select OK and continue the exercise steps.


![Screenshot of pop-up screen indicating that this feature isn't available within the simulation.](https://learn.microsoft.com/training/wwl-sci/security-copilot-exercises/media/simulation-pop-up-error.png)


### Exercise

For this exercise, you're logged in as Avery Howard and have the Copilot owner role. You'll work in Microsoft Security Copilot and will be accessing a GitHub repository to download the sample manifest file for the plugin.

This exercise should take approximately **10** minutes to complete.

When a lab instruction calls for opening a link to the simulated environment, it's recommended that you open the link in a new browser window so that you can simultaneously view the instructions and the exercise environment. To do so, select the right mouse key and select the option.


#### Before you start

For this exercise, you are using a sample .yaml file, 'KQL_DefenderExample.yaml.'

1. Select the link KQL_DefenderExample.yaml to access the sample file.
2. Select the Download raw file  icon. Save the file on your local computer, as you'll need it later.
Alternatively, because this is a simulation, you can create the file named 'KQL_DefenderExample.yaml.' Because this is a simulation, the contents of the file you create don't matter. The system capabilities and prompt responses shown in the simulation, however, are based on the actual file.

Select the link **[KQL_DefenderExample.yaml](https://github.com/MicrosoftLearning/SC-5006-Enhance-security-by-Microsoft-Security-Copilot/blob/master/Sample%20files/KQL_DefenderExample.yaml" data-linktype="external" target="az-portal" class="has-external-link-indicator)** to access the sample file.

Select the **Download raw file ** icon. Save the file on your local computer, as you'll need it later.


![download raw file icon](https://learn.microsoft.com/training/wwl-sci/security-copilot-exercises/media/raw-file-download-icon-v2.png)

Alternatively, because this is a simulation, you can create the file named 'KQL_DefenderExample.yaml.' Because this is a simulation, the contents of the file you create don't matter. The system capabilities and prompt responses shown in the simulation, however, are based on the actual file.


#### Task: Update owner settings for custom plugins

In this task, you configure Copilot so that Copilot owners and contributors can add and manage their own custom plugins and for everyone in the organization.

1. Open the simulated environment by selecting this link: Microsoft Security Copilot.
2. Select the Home menu (hamburger) icon
3. Select Plugin settings.

Set "Who can add and manage their own custom plugins?" to Contributors and owners.
Set "Who can add and manage custom plugins for users of this workspace?" to Contributors and owners.
4. Set "Who can add and manage their own custom plugins?" to Contributors and owners.
5. Set "Who can add and manage custom plugins for users of this workspace?" to Contributors and owners.
6. Return to the landing page. Select Microsoft Security Copilot next to the home menu (hamburger) icon.

Open the simulated environment by selecting this link: **[Microsoft Security Copilot](https://app.highlights.guide/start/f7107adc-8d47-43ae-a7f7-f9e9a35881c4?token=045faae1-1078-4eac-bf56-e12472eddaf9" data-linktype="external" target="az-portal" class="has-external-link-indicator)**.

Select the **Home menu** (hamburger) icon

Select **Plugin settings**.

1. Set "Who can add and manage their own custom plugins?" to Contributors and owners.
2. Set "Who can add and manage custom plugins for users of this workspace?" to Contributors and owners.

Return to the landing page. Select **Microsoft Security Copilot** next to the home menu (hamburger) icon.


#### Task: Upload the file for your custom plugin

In this task, you upload the file named, KQL_DefenderExample.yaml, that you downloaded in the 'Before you start' section of this exercise.

1. From the prompt bar on the Copilot landing page, select the sources icon.
2. On the Manage sources window, scroll down until you get to the Custom plugins. Select the Add plugin  button. This opens the Add a plugin window.
3. In the Add a plugin window, ensure the setting for Who can use this plugin is set to Just me.
4. For this exercise, select Security Copilot Plugin as this is the format for the .yaml file of your custom plugin.
5. From the upload box that appears, select Upload file, then select the file you previously downloaded to your local computer, KQL_DefenderExample.yaml then select Add.
6. On the custom plugins page, the plugin has been added and is enabled. Note the private tag.
7. Select the Settings icon. The settings icon shows basic plugin information. Note the name and brief description. This is a basic sample plugin so there are no configuration parameters to configure. If there were API keys or sign-in credentials required for the plugin, this is where they would be configured, like the exercise where you configured the Microsoft Sentinel plugin. Here you can also delete the plugin. Select Cancel to exit the page.
8. Close the manage sources window by selecting the X on the top right of the window.

From the prompt bar on the Copilot landing page, select the **sources** icon.

On the Manage sources window, scroll down until you get to the Custom plugins. Select the **Add plugin ** button. This opens the Add a plugin window.


![add plugin button](https://learn.microsoft.com/training/wwl-sci/security-copilot-exercises/media/add-plugin-button.png)

In the Add a plugin window, ensure the setting for Who can use this plugin is set to **Just me**.

For this exercise, select **Security Copilot Plugin** as this is the format for the .yaml file of your custom plugin.

From the upload box that appears, select **Upload file**, then select the file you previously downloaded to your local computer, **KQL_DefenderExample.yaml** then select **Add**.

On the custom plugins page, the plugin has been added and is enabled. Note the private tag.

Select the **Settings** icon. The settings icon shows basic plugin information. Note the name and brief description. This is a basic sample plugin so there are no configuration parameters to configure. If there were API keys or sign-in credentials required for the plugin, this is where they would be configured, like the exercise where you configured the Microsoft Sentinel plugin. Here you can also delete the plugin. Select Cancel to exit the page.

Close the manage sources window by selecting the **X** on the top right of the window.


#### Task:  Test the custom plugin

In this task, you verify the capability enabled by the plugin can be accessed from the prompts icon and you test it.

1. From the prompt bar, select the Prompts icon.
2. Select See all system capabilities.
3. Scroll all the way down until you get to My sample Defender KQL plugin. Listed below the plugin name is the capability (prompt) enabled by the plugin. Select Get Latest Emails by Recipient to run the prompt. For future reference you can search by this capability (prompt) name.
4. Enter email address of a user whose email you need to audit: nosv32@woodgrove.ms.
5. As with any prompt, you can select the response and pin it the pin board, you can share it, edit it, and more.

From the prompt bar, select the **Prompts** icon.

Select **See all system capabilities**.

Scroll all the way down until you get to **My sample Defender KQL** plugin. Listed below the plugin name is the capability (prompt) enabled by the plugin. Select **Get Latest Emails by Recipient** to run the prompt. For future reference you can search by this capability (prompt) name.

Enter email address of a user whose email you need to audit: **nosv32@woodgrove.ms**.

As with any prompt, you can select the response and pin it the pin board, you can share it, edit it, and more.


#### Review

In this exercise, you enabled a custom plugin by uploading the .yaml file for the plugin and then tested the capability supported by the plugin.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/security-copilot-exercises/5-enable-custom-plugin/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/security-copilot-exercises/5-enable-custom-plugin/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*