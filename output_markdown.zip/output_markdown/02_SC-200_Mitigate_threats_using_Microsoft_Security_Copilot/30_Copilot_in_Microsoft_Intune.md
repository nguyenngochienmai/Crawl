---
title: Copilot in Microsoft Intune
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 30
url: https://learn.microsoft.com/en-us/training/modules/security-copilot-embedded-experiences/5-copilot-for-intune/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: content
crawled_at: 2025-11-25T16:56:43.464205
---

# Copilot in Microsoft Intune

> Copilot in Microsoft Intune.

Microsoft Intune has capabilities that are powered by Microsoft Security Copilot. These capabilities access your Intune data, and can help you manage your policies &amp; settings, understand your security posture, and troubleshoot device issues.

Access to your Intune data is supported through Microsoft Security Copilot, referred to as the standalone experience, or embedded within the Intune admin center, referred to as Copilot in Intune. This unit focuses on the embedded experience.

The list of Copilot capabilities embedded in Microsoft Intune is continually growing. This unit provides just a sampling of those capabilities. For more information, see documentation on Microsoft Intune.


### Before you begin

To enable Copilot to access your Intune data, for either the embedded or standalone experience, Microsoft Security Copilot must be configured, the Microsoft Intune plugin must be enabled, and you need to have appropriate role permissions. You need a role permission that grants access to Copilot and you also need a separate Intune service-specific role like the Intune Endpoint Security Manager role. There isn't a built-in Intune role that includes access to Copilot.


![Screen capture showing the Microsoft Intune plugin enabled.](https://learn.microsoft.com/training/wwl-sci/security-copilot-embedded-experiences/media/intune-plugin.png)

For the specific setup tasks, go to [Describe how to enable Microsoft Security Copilot](/en-us/training/modules/security-copilot-getting-started/6-describe-how-to-enable-security-copilot" data-linktype="absolute-path).

You can check the status of Copilot in Intune from the Intune admin center.


![Screen capture of Intune admin portal showing that Copilot in Intune is enabled.](https://learn.microsoft.com/training/wwl-sci/security-copilot-embedded-experiences/media/copilot-in-intune-v2.png)


### Copilot in Intune

Currently, Copilot in Intune is available for:

- Policy and setting management
- Device details and troubleshooting


#### Policy and setting management

Copilot is embedded on policy settings and with your existing policies, on the following policy types in Intune:

- Compliance policies
- Device configuration policies, including the settings catalog
- Most endpoint security policies

When you create a new policy, you can use Copilot to learn more about individual settings, their impact, and recommended values by using the Copilot tooltips.

The example that follows shows the compliance settings tab for a new macOS compliance policy. Next to each setting is a Copilot icon. Selecting the Copilot icon displays detailed information about the setting.


![Screen capture of Copilot in Intune tool tip icon for a setting and the information Copilot generates for that setting.](https://learn.microsoft.com/training/wwl-sci/security-copilot-embedded-experiences/media/intune-copilot-settings-tooltip-preview-v2.png)

From an existing policy, you can use Copilot to summarize the policy. The summary describes what the policy does, the users and groups assigned to the policy, and the settings in the policy. This feature can help you understand the impact of a policy and its settings on your users and devices.


![Screen capture of Copilot in Intune showing a summary for a device policy and the available prompts.](https://learn.microsoft.com/training/wwl-sci/security-copilot-embedded-experiences/media/intune-policy-summarize.png)

Whether you're using Copilot to learn about the settings for a new policy or summarizing an existing policy, the Copilot window provides more prompts that you can use. You can also select the prompt guide icon on the bottom right and select from an existing list of prompts.


![Screen capture of Copilot in Intune prompt guide icon and the available prompts.](https://learn.microsoft.com/training/wwl-sci/security-copilot-embedded-experiences/media/intune-prompt-guide.png)


#### Device details and troubleshooting

You can use Copilot to get device-specific information, like the installed apps, group membership, and other information that can help troubleshoot a device.


![Screen capture of Copilot in Intune device summary, showing prompts that provide device specific information and can help in troubleshooting.](https://learn.microsoft.com/training/wwl-sci/security-copilot-embedded-experiences/media/intune-copilot-device-summary-troubleshooting.png)

When the Copilot window opens, select a prompt, and enter any required or optional input, if needed. You can also open the prompt guide for some follow-up questions.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/security-copilot-embedded-experiences/5-copilot-for-intune/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/security-copilot-embedded-experiences/5-copilot-for-intune/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*