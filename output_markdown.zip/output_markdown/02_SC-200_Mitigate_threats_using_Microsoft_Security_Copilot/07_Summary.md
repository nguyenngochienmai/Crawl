---
title: Summary
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 7
url: https://learn.microsoft.com/en-us/training/modules/fundamentals-generative-ai/9-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: summary
crawled_at: 2025-11-25T16:49:56.900205
---

# Summary

> Let's review what you've learned in this module.


📺 **Embedded Content**: [https://learn-video.azurefd.net/vod/player?id=d4576e9f-45bb-4e50-8e89-06d8f76cfd04&locale=en-us&embedUrl=%2Ftraining%2Fmodules%2Ffundamentals-generative-ai%2F9-summary](https://learn-video.azurefd.net/vod/player?id=d4576e9f-45bb-4e50-8e89-06d8f76cfd04&locale=en-us&embedUrl=%2Ftraining%2Fmodules%2Ffundamentals-generative-ai%2F9-summary)

See the **Text and images** tab for more details!

Generative AI is a rapidly developing field of AI that supports new language generation, code development, image creation, and more. In this module, you've explored how generative AI uses large language models to make sense of language, and how you can interact with these models using prompts. You've also learned how AI agents, built on generative AI, can act as digital assistants that collaborate with you to find information and accomplish tasks.

For more information about some of the concepts discussed in this module, take a look at the following links:

- What are large language models (LLMs)?
- What is retrieval-augmented generation (RAG)?
- Agent Factory: The new era of agentic AI—common use cases and design patterns


---

*Source: [https://learn.microsoft.com/en-us/training/modules/fundamentals-generative-ai/9-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/fundamentals-generative-ai/9-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*