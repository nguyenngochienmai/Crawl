---
title: Describe workspaces
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 19
url: https://learn.microsoft.com/en-us/training/modules/security-copilot-describe-core-features/2b-describe-workspaces/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: content
crawled_at: 2025-11-25T16:51:41.672081
---

# Describe workspaces

> Describe workspaces.

Copilot workspaces are separate work environments within the tenant in which your Copilot instance is operating.

To help you better understand the concept of workspaces, we use the analogy of house with multiple rooms. Each room is configured to be optimized for its function and the people that use that room. When someone enters the house, they might have access to some rooms but not others.

You can think of Copilot Workspaces fitting into this analogy. A Copilot workspace is analogous to a room in a house. You can also think of the house as analogous to a tenant. In the same way that a house has multiple rooms, the tenant in which Copilot is operating can have multiple workspaces.

Through the tenant-switching capability in Security Copilot, a user can select in which tenant they'll be working. In our analogy, this is a Copilot user getting access to the house. Once the tenant is selected, a Copilot user can access and work in any workspace (room in the house) to which they have access, within the context of their role permissions in that workspace.


![Illustration of a house, which is like a tenant and a room in the house is like a workspace in Security Copilot.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/workspace-overview.png)

There are many benefits to Copilot workspaces.

- Set up individual workspaces to address specific team needs.
- Manage and map costs based on team needs and budgets.
- Ensure critical workflows aren't disrupted by throttling.
- Store session data according to geo-specific regulations.
- Set up and manage specific plugins, promptbooks, and files for specific team needs.
- Experiment with custom plugins and promptbooks before organization-wide deployment.


### Create a workspace

You need to be at least a Security Administrator to create new workspaces for your organization. A workspace is powered by a capacity resource (SCUs). To attach capacity to a workspace, you also need to be an Azure subscription owner or contributor.

There are several entry points for you to create a new workspace:

- From the landing page of the Security Copilot portal
- From the Manage workspaces section of the Owner settings page

- From the breadcrumb
- Owner settings page


![A screenshot showing the new workspace option from the landing page of the Copilot Studio portal.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/workspace-create.png)


![A screenshot showing the manage workspace option from the owner settings page.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/workspace-owner-settings-v3.png)

1. From any of entry points, select New Workspace.
2. To Set up the workspace, specify a name for the workspace, create or select an existing capacity, select the data storage location, and define your data sharing preferences. These choices are all specific to this workspace and can be different from the selections made at the time Security Copilot was initially set up (the first run experience).
3. Confirm that you acknowledge and agree to the terms and conditions, then select Create.

- Create a workspace
- Create capacity


![A screenshot of the page to Create a new workspace.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/workspace-create-page.png)


![A screenshot of the page to Create a new security capacity.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/create-security-capacity.png)


### Configure workspaces

Once the workspace is created and selected, it can be configured with unique settings and permissions, allowing you to tailor the environment to meet the specific needs of your team. This includes assigning roles, managing access, and setting up plugins and promptbooks that are relevant to the workspace.

Decisions and configuration made in plugin settings and role permissions apply specifically to the workspace in which they're being configured.

Decisions and configurations within "owner settings" apply specifically to the workspace that's being configured, with one exception: Audit Logging enablement can only be changed by Security Admins and applies to all workspaces.


![Screenshot of owner settings page with logging audit data highlighted.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/workspace-audit-logging.png)


### Manage workspaces

Owners can view, navigate between, manage capacity allocations, and delete workspaces that they own from the Manage Workspaces page.

- Manage workspaces
- Assign and switch capacity


![A screenshot of the manage workspaces page that lists the available workspaces.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/workspace-manage-v2.png)


![A screenshot of the drop-down menu from which owners can view and select from availability capacity options.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/workspace-assign-capacity-v2.png)


### Use workspaces

From the main landing page, users can select the current workspace, which opens the drop-down menu where users can select available workspaces to which they have access. They can also set their preferred workspace in cases where they have access to multiple workspaces. Owners are also given the option to manage workspaces, manage capacity usage, and create a new workspace.

Once in a workspace, users can start using promptbooks, enter prompts directly in the prompt bar, and all the features of Copilot for which they have permissions.

If users have been doing work with Copilot in one of the Security product portals (for example Defender, Intune, Microsoft Entra, or Purview) and they switch their preferred workspace, they need to reload or sign out &amp; sign in to the portals to continue working with Copilot in those portals. If they don’t, they'll encounter an error.

- Workspace
- Workspace menu option


![A screenshot highlighting the current workspace, on the Copilot landing page.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/landing-page-workspace-small.png)


![A screenshot of the workspace drop-down menu options, available from the Copilot landing page.](https://learn.microsoft.com/training/wwl-sci/security-copilot-describe-core-features/media/landing-page-workspace-drop-down-small.png)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/security-copilot-describe-core-features/2b-describe-workspaces/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/security-copilot-describe-core-features/2b-describe-workspaces/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*