---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 14
url: https://learn.microsoft.com/en-us/training/modules/security-copilot-getting-started/7-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: quiz
crawled_at: 2025-11-25T16:50:57.679829
---

# Module assessment

> Microsoft Security Copilot knowledge check

Choose the best response for each of the questions below.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/security-copilot-getting-started/7-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/security-copilot-getting-started/7-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*