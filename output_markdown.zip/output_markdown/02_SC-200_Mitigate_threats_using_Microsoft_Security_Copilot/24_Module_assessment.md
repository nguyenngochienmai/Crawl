---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 24
url: https://learn.microsoft.com/en-us/training/modules/security-copilot-describe-core-features/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: quiz
crawled_at: 2025-11-25T16:52:28.377007
---

# Module assessment

> Describe the core features of Microsoft Security Copilot.

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "A security analyst is using Microsoft Security Copilot and wants to generate insights from their security data. They want to use natural language to do this. Where should they input their request?",
"options": [
"In the 'Prompt bar'",
"In the 'Prompts to try' section",
"In the 'Workspaces' section"
],
"correct\_answers": [
"In the 'Prompt bar'"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "A team member needs to set up a new workspace in Copilot for a specific project. What role must this team member have in order to create a new workspace?",
"options": [
"Security Reader",
"Security Administrator",
"Billing Administrator"
],
"correct\_answers": [
"Security Administrator"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "A security analyst needs to review past sessions created in Microsoft Security Copilot. After accessing the standalone experience, which option should they select to manage and review these sessions?",
"options": [
"Select the My sessions option from the home menu.",
"Select the Help icon.",
"Select settings."
],
"correct\_answers": [
"Select the My sessions option from the home menu."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 4,
"question": "A team member is trying to use a non-Microsoft plugin with Microsoft Security Copilot but it appears greyed out and restricted. What could be the possible reason?",
"options": [
"The plugin isn't supported by Microsoft Security Copilot.",
"The plugin requires an account and license to the specific service.",
"The Copilot owner has restricted plugin access."
],
"correct\_answers": [
"The Copilot owner has restricted plugin access."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 5,
"question": "A security analyst is tasked with automating investigation flows to streamline repetitive steps in Copilot. After selecting relevant prompts from an existing session, the analyst wants to create a promptbook. What should the analyst do next to accomplish this task?",
"options": [
"Select the 'Create promptbook' icon to open the page where they can name, tag, and further customize the promptbook.",
"Select the 'Export prompts' button to download the selected prompts for manual execution.",
"Choose the 'Save session' option to preserve the current state of the session for later use."
],
"correct\_answers": [
"Select the 'Create promptbook' icon to open the page where they can name, tag, and further customize the promptbook."
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/security-copilot-describe-core-features/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/security-copilot-describe-core-features/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*