---
title: Explore the capabilities of Copilot in Microsoft Purview
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 43
url: https://learn.microsoft.com/en-us/training/modules/security-copilot-exercises/9-explore-embedded-purview/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: content
crawled_at: 2025-11-25T17:12:14.309960
---

# Explore the capabilities of Copilot in Microsoft Purview

> Explore the capabilities of Copilot in Microsoft Purview.

Microsoft Security Copilot is accessible within Microsoft Purview data security and compliance solutions, including Data Loss Prevention (DLP), Insider Risk Management, Communication Compliance, and eDiscovery (Premium).

In this exercise, you explore the Copilot summarization capabilities available in each of these solutions. You start by verifying that the Microsoft Purview plugin is enabled.

The environment for this exercise is a simulation generated from the product. As a limited simulation, links on a page might not be enabled and text-based inputs that fall outside of the specified script might not be supported. A pop-up message displays stating, "This feature is not available within the simulation." When this message occurs, select OK and continue the exercise steps.


![Screenshot of pop-up screen indicating that this feature isn't available within the simulation.](https://learn.microsoft.com/training/wwl-sci/security-copilot-exercises/media/simulation-pop-up-error.png)


### Exercise

For this exercise, you're logged in as Avery Howard. You have the Copilot owner role and the specific role permissions required to access each of the Microsoft Purview solutions used in this exercise.

You work with specific Microsoft Purview solutions, using the new Microsoft Purview portal, and access the embedded Copilot capabilities of those solutions.

This exercise should take approximately **30** minutes to complete.

When a lab instruction calls for opening a link to the simulated environment, it's recommended that you open the link in a new browser window so that you can simultaneously view the instructions and the exercise environment. To do so, select the right mouse key and select the option.


#### Task: Enable the Microsoft Purview plugin

In this task, you enable the Microsoft Purview plugin. For this task, you work in the standalone experience.

1. Open the simulated environment by selecting this link: Microsoft Security Copilot.
2. From the Microsoft Security Copilot landing page, select the Sources icon  in the prompt bar.

From the manage sources window, under the Microsoft plugins, select Show 11 more.
Scroll down so that the Microsoft Purview plugin is visible.
Select the Information icon . Note the instructions then close the plugins page by selecting the X on the top-right corner of the manage sources window.
3. From the manage sources window, under the Microsoft plugins, select Show 11 more.
4. Scroll down so that the Microsoft Purview plugin is visible.
5. Select the Information icon . Note the instructions then close the plugins page by selecting the X on the top-right corner of the manage sources window.
6. Select the Home menu , often referred to as the hamburger icon.

Select Plugin settings.
Enable the toggle switch next to Allow Security Copilot to access data from your Microsoft 365 services.
Return to the Copilot home page, by selecting Microsoft Security Copilot on the top-left of the page next to the home menu (hamburger) icon.
7. Select Plugin settings.
8. Enable the toggle switch next to Allow Security Copilot to access data from your Microsoft 365 services.
9. Return to the Copilot home page, by selecting Microsoft Security Copilot on the top-left of the page next to the home menu (hamburger) icon.
10. Now that Copilot is enabled to access data from your Microsoft 365 services, return to the plugins page and enable the Microsoft Purview plugin.

From the prompt bar, select the Sources icon.
From the manage sources window, under the Microsoft plugins, select Show 13 more.
Enable the toggle switch next to Microsoft Purview to enable the plugin.
Close the manage sources window by selecting the X.
11. From the prompt bar, select the Sources icon.
12. From the manage sources window, under the Microsoft plugins, select Show 13 more.
13. Enable the toggle switch next to Microsoft Purview to enable the plugin.
14. Close the manage sources window by selecting the X.

Open the simulated environment by selecting this link: **[Microsoft Security Copilot](https://app.highlights.guide/start/6fca2b1c-bf14-4c26-9eda-48be3c0b5013?token=045faae1-1078-4eac-bf56-e12472eddaf9&amp;link=1" data-linktype="external" target="az-portal" class="has-external-link-indicator)**.

From the Microsoft Security Copilot landing page, select the **Sources icon**  in the prompt bar.


![sources icon](https://learn.microsoft.com/training/wwl-sci/security-copilot-exercises/media/sources-icon.png)

1. From the manage sources window, under the Microsoft plugins, select Show 11 more.
2. Scroll down so that the Microsoft Purview plugin is visible.
3. Select the Information icon . Note the instructions then close the plugins page by selecting the X on the top-right corner of the manage sources window.


![screenshot of information icon](https://learn.microsoft.com/training/wwl-sci/security-copilot-exercises/media/information-icon.png)

Select the **Home menu** , often referred to as the hamburger icon.


![screenshot of the home menu icon](https://learn.microsoft.com/training/wwl-sci/security-copilot-exercises/media/home-menu-icon.png)

1. Select Plugin settings.
2. Enable the toggle switch next to Allow Security Copilot to access data from your Microsoft 365 services.
3. Return to the Copilot home page, by selecting Microsoft Security Copilot on the top-left of the page next to the home menu (hamburger) icon.

Now that Copilot is enabled to access data from your Microsoft 365 services, return to the plugins page and enable the Microsoft Purview plugin.

1. From the prompt bar, select the Sources icon.
2. From the manage sources window, under the Microsoft plugins, select Show 13 more.
3. Enable the toggle switch next to Microsoft Purview to enable the plugin.
4. Close the manage sources window by selecting the X.


#### Task: Investigate risky activity using Security Copilot

For this and all subsequent tasks, you explore the Copilot functionality embedded in Microsoft Purview.

In this task, you investigate an alert related to potential data exfiltration. You begin by reviewing the alert manually to identify key risk indicators, then use **Security Copilot** to accelerate your investigation. In particular, you look for file activity related to **EmployeeInfo_EDM.csv**, which contains sensitive employee information and was involved in exfiltration events.

Microsoft Copilot assumes the permissions of the user when it tries to access the data to answer queries. To access data associated with the Microsoft Purview Insider Risk Management solution, the Copilot user must be assigned an appropriate role.

1. Open the environment by selecting this link: Microsoft Purview Portal.
2. In the Microsoft Purview portal, Solutions > Insider Risk Management > Alerts.
3. Select the first alert on the list with alert ID ad18a3a1.
4. Review the alert:

Check the alert name, associated policy, severity, and risk score. Review when the alert was triggered and why.
Select View all details to view the user profile, including group membership and priority status. Then close the panel.
In the All risk factors tab, look at exfiltration activity, sequence activity, priority content, and sensitive info types.
Select the Activity explorer tab and examine key events around the alert date.
Use the User activity tab to review patterns in user behavior across a broader time range.
5. Check the alert name, associated policy, severity, and risk score. Review when the alert was triggered and why.
6. Select View all details to view the user profile, including group membership and priority status. Then close the panel.
7. In the All risk factors tab, look at exfiltration activity, sequence activity, priority content, and sensitive info types.
8. Select the Activity explorer tab and examine key events around the alert date.
9. Use the User activity tab to review patterns in user behavior across a broader time range.
10. Use Security Copilot to guide deeper review:

From the alert page, select Summarize to generate a quick summary of the alert and the user's recent behavior.
In the Copilot pane, select the predefined prompt Summarize user's last 30 days of activity.
When the summary loads, review the response, then select View activity to open the full user activity view.
In the left pane, select Unusual activities.
Expand the first sequence activity listed for February 25, 2025.
Select the 2 events link to view the actions included in that sequence.
Find the entry for EmployeeInfo_EDM.csv. Expand the details and review the associated actions for this file.
11. From the alert page, select Summarize to generate a quick summary of the alert and the user's recent behavior.
12. In the Copilot pane, select the predefined prompt Summarize user's last 30 days of activity.
13. When the summary loads, review the response, then select View activity to open the full user activity view.
14. In the left pane, select Unusual activities.
15. Expand the first sequence activity listed for February 25, 2025.
16. Select the 2 events link to view the actions included in that sequence.
17. Find the entry for EmployeeInfo_EDM.csv. Expand the details and review the associated actions for this file.

Open the environment by selecting this link: **[Microsoft Purview Portal](https://app.highlights.guide/start/6fca2b1c-bf14-4c26-9eda-48be3c0b5013?token=045faae1-1078-4eac-bf56-e12472eddaf9" data-linktype="external" target="az-portal" class="has-external-link-indicator)**.

In the Microsoft Purview portal, **Solutions** &gt; **Insider Risk Management** &gt; **Alerts**.

Select the first alert on the list with alert ID **ad18a3a1**.

Review the alert:

1. Check the alert name, associated policy, severity, and risk score. Review when the alert was triggered and why.
2. Select View all details to view the user profile, including group membership and priority status. Then close the panel.
3. In the All risk factors tab, look at exfiltration activity, sequence activity, priority content, and sensitive info types.
4. Select the Activity explorer tab and examine key events around the alert date.
5. Use the User activity tab to review patterns in user behavior across a broader time range.

Use **Security Copilot** to guide deeper review:

1. From the alert page, select Summarize to generate a quick summary of the alert and the user's recent behavior.
2. In the Copilot pane, select the predefined prompt Summarize user's last 30 days of activity.
3. When the summary loads, review the response, then select View activity to open the full user activity view.
4. In the left pane, select Unusual activities.
5. Expand the first sequence activity listed for February 25, 2025.
6. Select the 2 events link to view the actions included in that sequence.
7. Find the entry for EmployeeInfo_EDM.csv. Expand the details and review the associated actions for this file.


#### Task: Review data loss prevention policy insights using Security Copilot

For this task, you explore how Security Copilot can help identify strengths and gaps in your Data Loss Prevention (DLP) policy coverage.

In large environments, it can be difficult to quickly assess whether existing policies provide the necessary coverage across locations, data types, and organizational boundaries. Security Copilot can surface insights and help you focus your attention where it matters most.

1. In the Microsoft Purview portal, go to Solutions > Data Loss Prevention > Policies.
2. Scroll through the list of DLP policies to get a sense of how many policies exist and how they're named. These might represent different locations, classifications, or business units.
3. Select Copilot > Get insights on existing policies.
4. When the Security Copilot pane opens, review the General insights shown by default.
5. Explore each insights category:

Select Insights by location, then choose Exchange. Review the insights displayed.
Repeat this process for Endpoint.
Select Insights by Administrative units and review the results.
Select Insights by Classification of data and review the results.
6. Select Insights by location, then choose Exchange. Review the insights displayed.
7. Repeat this process for Endpoint.
8. Select Insights by Administrative units and review the results.
9. Select Insights by Classification of data and review the results.
10. At the bottom of the Copilot pane, select the predefined prompt What types of sensitive information are we protecting with these DLP policies? and review the results.
11. In the Copilot pane, select the predefined prompt Does this DLP policy apply to all users in my organization? and review the results.
12. In the Copilot input field, type Are there any gaps based on the policies I currently have created? and review the answer provided.

In the Microsoft Purview portal, go to **Solutions** &gt; **Data Loss Prevention** &gt; **Policies**.

Scroll through the list of DLP policies to get a sense of how many policies exist and how they're named. These might represent different locations, classifications, or business units.

Select **Copilot** &gt; **Get insights on existing policies**.

When the Security Copilot pane opens, review the **General insights** shown by default.

Explore each insights category:

1. Select Insights by location, then choose Exchange. Review the insights displayed.
2. Repeat this process for Endpoint.
3. Select Insights by Administrative units and review the results.
4. Select Insights by Classification of data and review the results.

At the bottom of the Copilot pane, select the predefined prompt **What types of sensitive information are we protecting with these DLP policies?** and review the results.

In the Copilot pane, select the predefined prompt **Does this DLP policy apply to all users in my organization?** and review the results.

In the Copilot input field, type **Are there any gaps based on the policies I currently have created?** and review the answer provided.

Use these insights to understand how your current DLP policies are distributed and whether they align with your organization's data protection needs. Review the results to identify any opportunities to improve coverage.


#### Task: Investigate data loss prevention alerts using Security Copilot

In this task, you use Security Copilot to investigate a DLP alert and examine user activity and sensitive information involved in the alert. You explore different views available in the alert pane and use predefined Copilot prompts to guide your investigation.

1. In the Microsoft Purview portal, go to Solutions > Data Loss Prevention > Alerts.
2. Scroll through the alert list and select the alert for DLP policy match for document 'POS-Leavers_0325.xlsx' on a device.
3. When the alert opens:

Review the tabs for Details, Events, and User activity summary.
4. Review the tabs for Details, Events, and User activity summary.
5. On the Details tab:

Review the alert details.
At the bottom of the tab, select Summarize > Summarize alert.
Review the generated summary in the Copilot pane.
6. Review the alert details.
7. At the bottom of the tab, select Summarize > Summarize alert.
8. Review the generated summary in the Copilot pane.
9. In the Copilot pane, select the prompt What activity was performed on the data in this alert? and review the response.
10. Next, select the prompt Describe the sensitive info, file labels, or data triggering this alert and review the results.
11. Back on the Details tab:

Select Summarize > Summarize user activity to generate a summary of related user actions.
12. Select Summarize > Summarize user activity to generate a summary of related user actions.
13. In the Copilot pane:

Select Show key actions performed by the user in the last 10 days.
Review the user activity for broader context.
14. Select Show key actions performed by the user in the last 10 days.
15. Review the user activity for broader context.
16. Go to the Events tab and view the file that triggered the alert.
17. Go to the User activity summary tab:

Scroll through to view any related insider risk activities.
18. Scroll through to view any related insider risk activities.

In the Microsoft Purview portal, go to **Solutions** &gt; **Data Loss Prevention** &gt; **Alerts**.

Scroll through the alert list and select the alert for **DLP policy match for document 'POS-Leavers_0325.xlsx' on a device**.

When the alert opens:

1. Review the tabs for Details, Events, and User activity summary.

On the **Details** tab:

1. Review the alert details.
2. At the bottom of the tab, select Summarize > Summarize alert.
3. Review the generated summary in the Copilot pane.

In the Copilot pane, select the prompt **What activity was performed on the data in this alert?** and review the response.

Next, select the prompt **Describe the sensitive info, file labels, or data triggering this alert** and review the results.

Back on the **Details** tab:

1. Select Summarize > Summarize user activity to generate a summary of related user actions.

In the Copilot pane:

1. Select Show key actions performed by the user in the last 10 days.
2. Review the user activity for broader context.

Go to the **Events** tab and view the file that triggered the alert.

Go to the **User activity summary** tab:

1. Scroll through to view any related insider risk activities.

Use this information to build a clearer picture of what triggered the alert, how sensitive data was handled, and whether user behavior suggests further review is needed.


#### Task: Investigate eDiscovery cases and build a query using Security Copilot

In this task, you explore how Security Copilot supports case investigation and query creation in Microsoft Purview eDiscovery. You start by reviewing a case summary, then create a custom search to locate files labeled as confidential and shared externally.

In this scenario, you're assisting with a case investigating the possible exposure of confidential data. Multiple searches are already added to the case as part of an initial review. Your role is to use Security Copilot to help summarize case details, analyze activity, and build a more targeted search.

1. In the Microsoft Purview portal, go to Solutions > eDiscovery > Cases.
2. On the Cases page, select Sensitive Information Discovery.
3. At the top of the case page, select Summarize this case.
4. The Security Copilot pane opens with a summary of the case. Review the generated content.
5. In the Copilot pane, select the predefined prompts:

How many hold policies in this case have errors?
Which hold policies in this case have errors?
6. How many hold policies in this case have errors?
7. Which hold policies in this case have errors?
8. Based on the case summary and current findings, you're asked to search for confidential files that might be shared externally. To begin this part of the investigation, select the Create a search button.
9. Name the search Confidential data search, then select Create.
10. On the Search page, under the query input, select Draft a query with Copilot.
11. Explore the available options in the Copilot promptbook:

Select View prompts, then select Find all emails containing the words budget and finance and have attachments. Select Generate KeyQL to view how the query is built.
Repeat this process for prompt Search all chats in the month of January 2020 that contain the word 'financial year'.
Repeat this process for prompt Search for files of type .docx that contain the words confidential and budget.
12. Select View prompts, then select Find all emails containing the words budget and finance and have attachments. Select Generate KeyQL to view how the query is built.
13. Repeat this process for prompt Search all chats in the month of January 2020 that contain the word 'financial year'.
14. Repeat this process for prompt Search for files of type .docx that contain the words confidential and budget.
15. In the query input box, type Search for files marked as confidential that were shared with external users.
16. Select Generate KeyQL to convert the prompt into a query.

In the Microsoft Purview portal, go to **Solutions** &gt; **eDiscovery** &gt; **Cases**.

On the **Cases** page, select **Sensitive Information Discovery**.

At the top of the case page, select **Summarize this case**.

The Security Copilot pane opens with a summary of the case. Review the generated content.

In the Copilot pane, select the predefined prompts:

1. How many hold policies in this case have errors?
2. Which hold policies in this case have errors?

Based on the case summary and current findings, you're asked to search for confidential files that might be shared externally. To begin this part of the investigation, select the **Create a search** button.

Name the search **Confidential data search**, then select **Create**.

On the **Search** page, under the query input, select **Draft a query with Copilot**.

Explore the available options in the Copilot promptbook:

1. Select View prompts, then select Find all emails containing the words budget and finance and have attachments. Select Generate KeyQL to view how the query is built.
2. Repeat this process for prompt Search all chats in the month of January 2020 that contain the word 'financial year'.
3. Repeat this process for prompt Search for files of type .docx that contain the words confidential and budget.

In the query input box, type **Search for files marked as confidential that were shared with external users.**

Select **Generate KeyQL** to convert the prompt into a query.

Once your query is generated, you can continue the investigation by reviewing the search results. Identify files that match your criteria and determine whether they need to be added to a review set or exported for further examination.

This task shows how Security Copilot can support your investigative process by summarizing key details and offering relevant prompts. It also helps construct searches that reflect the scope of the case.


### Review

In this exercise, you used Security Copilot to support investigations in Microsoft Purview. You reviewed insider risk alerts, explored DLP policies and alerts, and worked with an eDiscovery case.

Each task showed how Copilot can help summarize information, identify patterns, and guide the next steps. You used built-in prompts and natural language input to focus your investigation and gather relevant context.

These actions reflect how Copilot can assist with common tasks across data security and compliance workflows.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/security-copilot-exercises/9-explore-embedded-purview/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/security-copilot-exercises/9-explore-embedded-purview/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*