---
title: Summary and resources
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 25
url: https://learn.microsoft.com/en-us/training/modules/security-copilot-describe-core-features/7-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: summary
crawled_at: 2025-11-25T16:55:59.012143
---

# Summary and resources

> Describe the core features of Microsoft Security Copilot.

In this module, learned about the core features of Microsoft Security Copilot. These features include promptbooks and creating custom promptbooks that provide security analysts a standardized set of prompts that serve as a framework for conducting investigations. You learned about the types of plugins that are available and enable integration with various sources, providing domain specific capabilities to aid your investigations.

Now that you completed this module, you can:

- Describe the features available in the standalone Copilot experience.
- Describe the plugins available in Copilot.
- Describe custom promptbooks.
- Describe knowledge base connections.


#### Learn more

- Understand authentication in Microsoft Security Copilot
- Microsoft Security Copilot experiences
- Plugins overview Microsoft Security Copilot
- Microsoft Security Copilot agents overview
- Create your own custom plugins
- Defender EASM Overview
- Microsoft Security Copilot and Defender EASM
- Microsoft Intune
- Microsoft Security Copilot and Intune
- What is Microsoft Defender XDR?
- Microsoft Copilot in Microsoft Defender XDR
- What is Microsoft Defender Threat Intelligence (Defender TI)?
- What is Microsoft Sentinel?
- Microsoft Entra
- What's Azure AI Search?


---

*Source: [https://learn.microsoft.com/en-us/training/modules/security-copilot-describe-core-features/7-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/security-copilot-describe-core-features/7-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*