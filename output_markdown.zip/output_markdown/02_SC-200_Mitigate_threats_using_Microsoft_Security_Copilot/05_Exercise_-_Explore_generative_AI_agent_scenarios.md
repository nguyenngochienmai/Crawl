---
title: Exercise - Explore generative AI agent scenarios
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 5
url: https://learn.microsoft.com/en-us/training/modules/fundamentals-generative-ai/7a-exercise/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: exercise
crawled_at: 2025-11-25T16:35:01.347810
---

# Exercise - Explore generative AI agent scenarios

> Explore generative AI agent scenarios using simulated apps.

Now it's your chance to explore generative AI!

In this exercise, you'll use a chat playground to interact with a generative AI model, and observe the effect of system prompts, model parameters, and grounding the model with data.

Launch the exercise and follow the instructions.


![Button to launch exercise.](https://learn.microsoft.com/training/wwl-data-ai/fundamentals-generative-ai/media/launch-exercise.png)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/fundamentals-generative-ai/7a-exercise/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/fundamentals-generative-ai/7a-exercise/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*