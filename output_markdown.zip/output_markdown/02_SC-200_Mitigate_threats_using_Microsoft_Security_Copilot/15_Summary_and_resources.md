---
title: Summary and resources
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 15
url: https://learn.microsoft.com/en-us/training/modules/security-copilot-getting-started/8-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: summary
crawled_at: 2025-11-25T16:51:08.892612
---

# Summary and resources

> Microsoft Security Copilot summary and resources.

Microsoft Security Copilot is an AI-powered, cloud-based security analysis tool designed to help organizations meet the growing challenges of cybersecurity, such as increasing attack sophistication and a shortage of skilled personnel. It enables security analysts to respond to threats at machine speed, process signals rapidly, and assess risk exposure more efficiently than traditional methods. Copilot is a comprehensive solution for managing security posture, responding to incidents, and generating actionable security reports.

Copilot offers a user-friendly interface, allowing interactions through natural language prompts. It integrates seamlessly with Microsoft security products like Microsoft Defender XDR and Microsoft Sentinel and also with non-Microsoft solutions, through plugins, providing a unified view for security analysis. The use of OpenAI's natural language processing models enhances its capability to understand and process user requests, making it an effective tool for both seasoned and novice security analysts.

Copilot maintains high standards of data privacy and security. The process log feature further adds transparency, allowing users to track the source and validity of the information provided by the tool.

Now that you've completed this module, you should be able to:

- Describe what Microsoft Security Copilot is.
- Describe the terminology of Microsoft Security Copilot.
- Describe how Microsoft Security Copilot processes prompt requests.
- Describe the elements of an effective prompt
- Describe how to enable Microsoft Security Copilot.


### Learn more

- What is Microsoft Security Copilot?
- Microsoft Security Copilot experiences
- Understand authentication in Microsoft Security Copilot
- Describe workspaces
- Microsoft Security Copilot agents overview
- Manage security compute unit usage in Security Copilot
- Microsoft Security Copilot pricing


---

*Source: [https://learn.microsoft.com/en-us/training/modules/security-copilot-getting-started/8-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/security-copilot-getting-started/8-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*