---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 32
url: https://learn.microsoft.com/en-us/training/modules/security-copilot-embedded-experiences/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: quiz
crawled_at: 2025-11-25T16:57:01.492097
---

# Module assessment

> Check your knowledge on the embedded experiences of Microsoft Security Copilot.



---

## Knowledge Check


[
{
"question\_number": 1,
"question": "A security analyst is using Copilot in Microsoft Defender XDR to review an incident and needs to understand the sequence of events that occurred during the attack. Which feature should they use to obtain a comprehensive overview?",
"options": [
"Script analysis",
"Summarize incidents",
"Guided responses"
],
"correct\_answers": [
"Summarize incidents"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "An organization's legal compliance team uses Microsoft Purview eDiscovery tools for internal and external investigations and is planning to use Security Copilot to help make them more productive and aid in their investigations. Which of the following statements is true regarding Copilot use with eDiscovery?",
"options": [
"Copilot functionality isn't supported with Microsoft Purview eDiscovery.",
"The organization must be licensed to use Microsoft Purview eDiscovery (Premium).",
"The organization needs to be licensed for Microsoft Purview eDiscovery (Standard), as a minimum."
],
"correct\_answers": [
"The organization must be licensed to use Microsoft Purview eDiscovery (Premium)."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "After enabling the Entra plugin in Copilot and assigning the appropriate role permissions, an admin navigates to the Risky users report to investigate a user's risky sign-ins. What should the admin do next to view the Copilot generated summary?",
"options": [
"Select the 'Export' option to download the user's risk details.",
"Check the 'User Activity' log for recent sign-in attempts.",
"Select the 'Summarize' tab in the Risky User Details window."
],
"correct\_answers": [
"Select the 'Summarize' tab in the Risky User Details window."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 4,
"question": "What information can be obtained by using Copilot in Intune, when creating a new policy?",
"options": [
"The date and time a policy was last updated.",
"The number of users who have accessed a policy.",
"Information about individual settings, their impact, and recommended values."
],
"correct\_answers": [
"Information about individual settings, their impact, and recommended values."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 5,
"question": "Copilot in Defender for Cloud is available for all users when you enable Defender for Cloud in your environment, have access to Azure Copilot, and have SCUs assigned for Security Copilot. What additional requirement must be met to remediate code with Security Copilot?",
"options": [
"You must enable all the cloud workload protection plans.",
"You must connect your Azure DevOps environment to Defender for Cloud, configure the Microsoft Security DevOps Azure DevOps extension, and meet the DevOps security support and prerequisites requirements.",
"You must enable the Defender for Cloud Security Posture Management (DCSPM) plan."
],
"correct\_answers": [
"You must connect your Azure DevOps environment to Defender for Cloud, configure the Microsoft Security DevOps Azure DevOps extension, and meet the DevOps security support and prerequisites requirements."
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/security-copilot-embedded-experiences/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/security-copilot-embedded-experiences/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*