---
title: Explore the standalone experience
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 36
url: https://learn.microsoft.com/en-us/training/modules/security-copilot-exercises/3-explore-standalone-experience/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: content
crawled_at: 2025-11-25T17:11:08.844676
---

# Explore the standalone experience

> Explore the standalone experience.

The security administrator for your organization provisioned Copilot. Since you're the senior analyst on the team, the administrator added you as a Copilot owner and asked you to familiarize yourself with the solution.

In this exercise, you explore all the key landmarks in the landing page of the standalone experience of Security Copilot. The tasks are organized by landmark and start with the landmark at the top left corner of the screen (the home menu) and then progress from left to right and top to bottom, but you can choose to go do the tasks in any order, just make sure you access the simulated environment in first step of the first task.

**As you explore, keep in mind that unless otherwise stated, the information displayed and the configuration settings are for the currently selected workspace**. For this exercise, all your exploration is done in the SecurityCopilot_Workspace, which is shown at the top of the page, next to where it says Microsoft Security Copilot.

The environment for this exercise is a simulation generated from the product. As a limited simulation, links on a page may not be enabled and text-based inputs that fall outside of the specified script may not be supported. A pop-up message displays stating, "This feature isn't available within the simulation." When this occurs, select OK and continue the exercise steps.


![Screenshot of pop-up screen indicating that this feature is not available within the simulation.](https://learn.microsoft.com/training/wwl-sci/security-copilot-exercises/media/simulation-pop-up-error.png)


### Exercise

For this exercise, you're logged in as Avery Howard and have the Copilot owner role for the active workspace, SecurityCopilot_Workspace. In this exercise, you explore the standalone experience of Microsoft Security Copilot.

This exercise should take approximately **30** minutes to complete.

When a lab instruction calls for opening a link to the simulated environment, it is generally recommended that you open the link in a new browser window so that you can simultaneously view the instructions and the exercise environment. To do so, select the right mouse key and select the option.


#### Task: Explore the menu options

In this task, you start your exploration in the home menu.

1. Open the simulated environment by selecting this link: Microsoft Security Copilot.
2. Select the Menu icon , which is sometimes referred to as the hamburger icon.
3. Select My sessions and note the available options.

Select recent to view the most recent sessions
Select filter and note the available options, then close the filer.
4. Select recent to view the most recent sessions
5. Select filter and note the available options, then close the filer.
6. Select the Home menu icon then select Promptbook library.

Select My promptbooks. A subsequent task dives deeper into promptbooks.
Select Woodgrove.
Select Microsoft.
Select the filter icon, then select Tag to view the available options. In this simulation, only the cveid tag is enabled.

Select the Tag drop-down, then scroll-down and select cveid.
Select Apply. Note: If you don't see the Apply button, use your mouse to select the space outside of the drop-down, then select Apply.
To clear that filter, select the X next to cveid.
7. Select My promptbooks. A subsequent task dives deeper into promptbooks.
8. Select Woodgrove.
9. Select Microsoft.
10. Select the filter icon, then select Tag to view the available options. In this simulation, only the cveid tag is enabled.

Select the Tag drop-down, then scroll-down and select cveid.
Select Apply. Note: If you don't see the Apply button, use your mouse to select the space outside of the drop-down, then select Apply.
To clear that filter, select the X next to cveid.
11. Select the Tag drop-down, then scroll-down and select cveid.
12. Select Apply. Note: If you don't see the Apply button, use your mouse to select the space outside of the drop-down, then select Apply.
13. To clear that filter, select the X next to cveid.
14. Select the Home menu icon then select Agents. Although some agents operate in the Copilot standalone experience and some are embedded in specific solutions, such as Microsoft Entra, general information about any Copilot Agent can be accessed through the standalone portal.

Let’s start by looking at an agent that currently operates only in the standalone Copilot experience. Look for the tile labeled, Threat Intelligence Briefing Agent, then select Go to agent.

Review the information on the agent’s page.
The left side of the page provides information on the trigger, permissions, identity, and role-based access for the agent.
The center portion of the page shows all the agent’s activity, including start time, method used to run the agent (automatic trigger or manual trigger), and the status. Select a line item that shows as Completed to view the report. The first section of the report is the Input. Expand the down arrow to view the inputs used for this run. The next section of the report shows the Results. Scroll down to view the report.
From the breadcrumb, select Agents to return to the agents page.


From the agents page, look for the tile labeled, Conditional Access Optimization Agent. This is an agent that works within Microsoft Entra.

Select Manage in Entra. A new browser tab opens to Microsoft Entra.
The Security Copilot agents page shows a tile for the currently available agent, select View details.
The Overview tab shows information about the agent, recent suggestions and recent activity.
Return to the Microsoft Security Copilot browser tab to continue your exploration of Security Copilot. You can close the browser tab for the Conditional Access Optimization Agent.


More detailed exploration of both the Threat Intelligence Briefing Agent and the Conditional Access Optimization Agent is available in the module titled, Describe Microsoft Security Copilot agents, for which there's a link in the summary unit of this module.
15. Let’s start by looking at an agent that currently operates only in the standalone Copilot experience. Look for the tile labeled, Threat Intelligence Briefing Agent, then select Go to agent.

Review the information on the agent’s page.
The left side of the page provides information on the trigger, permissions, identity, and role-based access for the agent.
The center portion of the page shows all the agent’s activity, including start time, method used to run the agent (automatic trigger or manual trigger), and the status. Select a line item that shows as Completed to view the report. The first section of the report is the Input. Expand the down arrow to view the inputs used for this run. The next section of the report shows the Results. Scroll down to view the report.
From the breadcrumb, select Agents to return to the agents page.
16. Review the information on the agent’s page.
17. The left side of the page provides information on the trigger, permissions, identity, and role-based access for the agent.
18. The center portion of the page shows all the agent’s activity, including start time, method used to run the agent (automatic trigger or manual trigger), and the status. Select a line item that shows as Completed to view the report. The first section of the report is the Input. Expand the down arrow to view the inputs used for this run. The next section of the report shows the Results. Scroll down to view the report.
19. From the breadcrumb, select Agents to return to the agents page.
20. From the agents page, look for the tile labeled, Conditional Access Optimization Agent. This is an agent that works within Microsoft Entra.

Select Manage in Entra. A new browser tab opens to Microsoft Entra.
The Security Copilot agents page shows a tile for the currently available agent, select View details.
The Overview tab shows information about the agent, recent suggestions and recent activity.
Return to the Microsoft Security Copilot browser tab to continue your exploration of Security Copilot. You can close the browser tab for the Conditional Access Optimization Agent.
21. Select Manage in Entra. A new browser tab opens to Microsoft Entra.
22. The Security Copilot agents page shows a tile for the currently available agent, select View details.
23. The Overview tab shows information about the agent, recent suggestions and recent activity.
24. Return to the Microsoft Security Copilot browser tab to continue your exploration of Security Copilot. You can close the browser tab for the Conditional Access Optimization Agent.
25. More detailed exploration of both the Threat Intelligence Briefing Agent and the Conditional Access Optimization Agent is available in the module titled, Describe Microsoft Security Copilot agents, for which there's a link in the summary unit of this module.
26. Select the Home menu icon then select Owner settings. These settings are available to you as a Copilot owner. A Copilot contributor doesn't have access to these menu options.

Azure resource links: This section includes information that shows the capacity assigned to the specific workspace.

Selecting the Switch capacity button opens a window where you as the owner could select another available capacity. For this simulation, there's no other preconfigured capacity.
Alternatively, you could create a new capacity. Select Create a new capacity to explore the parameters, then select Cancel.
Select Cancel again or the X to close the window.


Security Compute units - Copilot runs on SCUs.

Select Change, to explore the options then select Cancel or X to close the window.
Selecting See usage takes you to the Usage monitoring dashboard. You'll explore that in a subsequent step. If you selected it, return to the home menu and owner settings, there's more to explore here.


Help improve Copilot - Select the information icon next to each configurable item. Configure the toggle buttons as desired
Logging audit data in Microsoft Purview - Review the description. This setting applies to all workspaces for the tenant in which you are using Copilot. Select the information icon next to the toggle for an information tip. Configure as desired.
Files - using File uploads is one of the mechanisms by which you can integrate your organization’s knowledge base as another source of information. Select the drop-down arrow to view options for who can upload files. Configure as desired.
27. Azure resource links: This section includes information that shows the capacity assigned to the specific workspace.

Selecting the Switch capacity button opens a window where you as the owner could select another available capacity. For this simulation, there's no other preconfigured capacity.
Alternatively, you could create a new capacity. Select Create a new capacity to explore the parameters, then select Cancel.
Select Cancel again or the X to close the window.
28. Selecting the Switch capacity button opens a window where you as the owner could select another available capacity. For this simulation, there's no other preconfigured capacity.
29. Alternatively, you could create a new capacity. Select Create a new capacity to explore the parameters, then select Cancel.
30. Select Cancel again or the X to close the window.
31. Security Compute units - Copilot runs on SCUs.

Select Change, to explore the options then select Cancel or X to close the window.
Selecting See usage takes you to the Usage monitoring dashboard. You'll explore that in a subsequent step. If you selected it, return to the home menu and owner settings, there's more to explore here.
32. Select Change, to explore the options then select Cancel or X to close the window.
33. Selecting See usage takes you to the Usage monitoring dashboard. You'll explore that in a subsequent step. If you selected it, return to the home menu and owner settings, there's more to explore here.
34. Help improve Copilot - Select the information icon next to each configurable item. Configure the toggle buttons as desired
35. Logging audit data in Microsoft Purview - Review the description. This setting applies to all workspaces for the tenant in which you are using Copilot. Select the information icon next to the toggle for an information tip. Configure as desired.
36. Files - using File uploads is one of the mechanisms by which you can integrate your organization’s knowledge base as another source of information. Select the drop-down arrow to view options for who can upload files. Configure as desired.
37. Select the Home menu icon then select Plugin settings

For plugins for Security Copilot, select the drop-down for Who can add and manage their own custom plugins to view the available options. Select each available option to see how it impacts the option below.
Select drop-down for Who can add and manage custom plugins for users of this workspace to view the available options. Note, this option is grayed out if Who can add and manage their own custom plugins is set to owners only.
Manage plugin availability and restrict access:

Review the description. Selecting the toggle opens a new window, review the description and enable the toggle. All plugins are restricted to owners only. You can manually change this for each plugin.
Disable the toggle to remove the restriction.


Accessing data from Microsoft 365 services:

Select the information icon to get information that describes the impact of this setting. With this toggle disabled, the Microsoft Purview plugin is not available to use. To ensure the use of the Purview plugin, this toggle must be enabled. You'll explore this more in the Purview unit.
38. For plugins for Security Copilot, select the drop-down for Who can add and manage their own custom plugins to view the available options. Select each available option to see how it impacts the option below.
39. Select drop-down for Who can add and manage custom plugins for users of this workspace to view the available options. Note, this option is grayed out if Who can add and manage their own custom plugins is set to owners only.
40. Manage plugin availability and restrict access:

Review the description. Selecting the toggle opens a new window, review the description and enable the toggle. All plugins are restricted to owners only. You can manually change this for each plugin.
Disable the toggle to remove the restriction.
41. Review the description. Selecting the toggle opens a new window, review the description and enable the toggle. All plugins are restricted to owners only. You can manually change this for each plugin.
42. Disable the toggle to remove the restriction.
43. Accessing data from Microsoft 365 services:

Select the information icon to get information that describes the impact of this setting. With this toggle disabled, the Microsoft Purview plugin is not available to use. To ensure the use of the Purview plugin, this toggle must be enabled. You'll explore this more in the Purview unit.
44. Select the information icon to get information that describes the impact of this setting. With this toggle disabled, the Microsoft Purview plugin is not available to use. To ensure the use of the Purview plugin, this toggle must be enabled. You'll explore this more in the Purview unit.
45. Select the Home menu icon then select Role assignment.

Select Add members, then close.
Expand the Owner and Contributor roles. There are no users in the contributor role.
Select the + Add recommended roles

Review the description and expand each of the roles listed to view details.
Select Add to add the recommended security roles, then select Ok. Once added, users in any of the roles included become Copilot contributors.
46. Select Add members, then close.
47. Expand the Owner and Contributor roles. There are no users in the contributor role.
48. Select the + Add recommended roles

Review the description and expand each of the roles listed to view details.
Select Add to add the recommended security roles, then select Ok. Once added, users in any of the roles included become Copilot contributors.
49. Review the description and expand each of the roles listed to view details.
50. Select Add to add the recommended security roles, then select Ok. Once added, users in any of the roles included become Copilot contributors.
51. Select the Home menu icon then select Manage workspaces

There's only one workspace available. Select the button on the top right corner of page that says + New workspace to view the parameters required. There's a subsequent exercise in this module that explores this option in more detail. Select Cancel.
52. There's only one workspace available. Select the button on the top right corner of page that says + New workspace to view the parameters required. There's a subsequent exercise in this module that explores this option in more detail. Select Cancel.
53. Select the Home menu icon then select Usage monitoring.

Hovering over any of the blue bars in the bar graph opens a small window with information.
Note the information available for each session.
There are several options for filtering on the usage monitoring dashboard

You can filter by date. Select the drop-down next to where it says Last 24 hours to view the available options.
Other filtering options are available by selecting the filter icon next to the date filter. This opens many other filter options, including Users, Plugins used, type, and category. Expand each to view available options. For this simulation, filter options won't be applied. Select Cancel.


Select the home menu icon to open the home menu.
54. Hovering over any of the blue bars in the bar graph opens a small window with information.
55. Note the information available for each session.
56. There are several options for filtering on the usage monitoring dashboard

You can filter by date. Select the drop-down next to where it says Last 24 hours to view the available options.
Other filtering options are available by selecting the filter icon next to the date filter. This opens many other filter options, including Users, Plugins used, type, and category. Expand each to view available options. For this simulation, filter options won't be applied. Select Cancel.
57. You can filter by date. Select the drop-down next to where it says Last 24 hours to view the available options.
58. Other filtering options are available by selecting the filter icon next to the date filter. This opens many other filter options, including Users, Plugins used, type, and category. Expand each to view available options. For this simulation, filter options won't be applied. Select Cancel.
59. Select the home menu icon to open the home menu.
60. Select the Home menu icon then select Settings.

Select preferences. Scroll down to view available options.
Select data and privacy.
Select About.
Select the X to close the preferences window.
61. Select preferences. Scroll down to view available options.
62. Select data and privacy.
63. Select About.
64. Select the X to close the preferences window.
65. Select where it says Woodgrove at the bottom left of the home menu.

When you select this option, you see your tenants. This option is referred to as the tenant switcher. In this case, Woodgrove is the only available tenant.
Select the Home to return to the landing page.
66. When you select this option, you see your tenants. This option is referred to as the tenant switcher. In this case, Woodgrove is the only available tenant.
67. Select the Home to return to the landing page.
68. Keep the browser tab open for the next task.

Open the simulated environment by selecting this link: **[Microsoft Security Copilot](https://app.highlights.guide/start/89a569ee-e0be-42cc-8ca8-5e375cd9f043?token=16d48b6c-eace-4a1f-8050-098d29d23a89" data-linktype="external" target="az-portal" class="has-external-link-indicator)**.

Select the **Menu** icon , which is sometimes referred to as the hamburger icon.


![home menu icon](https://learn.microsoft.com/training/wwl-sci/security-copilot-exercises/media/home-menu-icon.png)

Select **My sessions** and note the available options.

1. Select recent to view the most recent sessions
2. Select filter and note the available options, then close the filer.

Select the **Home menu icon** then select **Promptbook library**.

1. Select My promptbooks. A subsequent task dives deeper into promptbooks.
2. Select Woodgrove.
3. Select Microsoft.
4. Select the filter icon, then select Tag to view the available options. In this simulation, only the cveid tag is enabled.

Select the Tag drop-down, then scroll-down and select cveid.
Select Apply. Note: If you don't see the Apply button, use your mouse to select the space outside of the drop-down, then select Apply.
To clear that filter, select the X next to cveid.
5. Select the Tag drop-down, then scroll-down and select cveid.
6. Select Apply. Note: If you don't see the Apply button, use your mouse to select the space outside of the drop-down, then select Apply.
7. To clear that filter, select the X next to cveid.

1. Select the Tag drop-down, then scroll-down and select cveid.
2. Select Apply. Note: If you don't see the Apply button, use your mouse to select the space outside of the drop-down, then select Apply.
3. To clear that filter, select the X next to cveid.

Select the **Home menu icon** then select **Agents**. Although some agents operate in the Copilot standalone experience and some are embedded in specific solutions, such as Microsoft Entra, general information about any Copilot Agent can be accessed through the standalone portal.

1. Let’s start by looking at an agent that currently operates only in the standalone Copilot experience. Look for the tile labeled, Threat Intelligence Briefing Agent, then select Go to agent.

Review the information on the agent’s page.
The left side of the page provides information on the trigger, permissions, identity, and role-based access for the agent.
The center portion of the page shows all the agent’s activity, including start time, method used to run the agent (automatic trigger or manual trigger), and the status. Select a line item that shows as Completed to view the report. The first section of the report is the Input. Expand the down arrow to view the inputs used for this run. The next section of the report shows the Results. Scroll down to view the report.
From the breadcrumb, select Agents to return to the agents page.
2. Review the information on the agent’s page.
3. The left side of the page provides information on the trigger, permissions, identity, and role-based access for the agent.
4. The center portion of the page shows all the agent’s activity, including start time, method used to run the agent (automatic trigger or manual trigger), and the status. Select a line item that shows as Completed to view the report. The first section of the report is the Input. Expand the down arrow to view the inputs used for this run. The next section of the report shows the Results. Scroll down to view the report.
5. From the breadcrumb, select Agents to return to the agents page.
6. From the agents page, look for the tile labeled, Conditional Access Optimization Agent. This is an agent that works within Microsoft Entra.

Select Manage in Entra. A new browser tab opens to Microsoft Entra.
The Security Copilot agents page shows a tile for the currently available agent, select View details.
The Overview tab shows information about the agent, recent suggestions and recent activity.
Return to the Microsoft Security Copilot browser tab to continue your exploration of Security Copilot. You can close the browser tab for the Conditional Access Optimization Agent.
7. Select Manage in Entra. A new browser tab opens to Microsoft Entra.
8. The Security Copilot agents page shows a tile for the currently available agent, select View details.
9. The Overview tab shows information about the agent, recent suggestions and recent activity.
10. Return to the Microsoft Security Copilot browser tab to continue your exploration of Security Copilot. You can close the browser tab for the Conditional Access Optimization Agent.
11. More detailed exploration of both the Threat Intelligence Briefing Agent and the Conditional Access Optimization Agent is available in the module titled, Describe Microsoft Security Copilot agents, for which there's a link in the summary unit of this module.

1. Review the information on the agent’s page.
2. The left side of the page provides information on the trigger, permissions, identity, and role-based access for the agent.
3. The center portion of the page shows all the agent’s activity, including start time, method used to run the agent (automatic trigger or manual trigger), and the status. Select a line item that shows as Completed to view the report. The first section of the report is the Input. Expand the down arrow to view the inputs used for this run. The next section of the report shows the Results. Scroll down to view the report.
4. From the breadcrumb, select Agents to return to the agents page.

1. Select Manage in Entra. A new browser tab opens to Microsoft Entra.
2. The Security Copilot agents page shows a tile for the currently available agent, select View details.
3. The Overview tab shows information about the agent, recent suggestions and recent activity.
4. Return to the Microsoft Security Copilot browser tab to continue your exploration of Security Copilot. You can close the browser tab for the Conditional Access Optimization Agent.

Select the **Home menu icon** then select **Owner settings**. These settings are available to you as a Copilot owner. A Copilot contributor doesn't have access to these menu options.

1. Azure resource links: This section includes information that shows the capacity assigned to the specific workspace.

Selecting the Switch capacity button opens a window where you as the owner could select another available capacity. For this simulation, there's no other preconfigured capacity.
Alternatively, you could create a new capacity. Select Create a new capacity to explore the parameters, then select Cancel.
Select Cancel again or the X to close the window.
2. Selecting the Switch capacity button opens a window where you as the owner could select another available capacity. For this simulation, there's no other preconfigured capacity.
3. Alternatively, you could create a new capacity. Select Create a new capacity to explore the parameters, then select Cancel.
4. Select Cancel again or the X to close the window.
5. Security Compute units - Copilot runs on SCUs.

Select Change, to explore the options then select Cancel or X to close the window.
Selecting See usage takes you to the Usage monitoring dashboard. You'll explore that in a subsequent step. If you selected it, return to the home menu and owner settings, there's more to explore here.
6. Select Change, to explore the options then select Cancel or X to close the window.
7. Selecting See usage takes you to the Usage monitoring dashboard. You'll explore that in a subsequent step. If you selected it, return to the home menu and owner settings, there's more to explore here.
8. Help improve Copilot - Select the information icon next to each configurable item. Configure the toggle buttons as desired
9. Logging audit data in Microsoft Purview - Review the description. This setting applies to all workspaces for the tenant in which you are using Copilot. Select the information icon next to the toggle for an information tip. Configure as desired.
10. Files - using File uploads is one of the mechanisms by which you can integrate your organization’s knowledge base as another source of information. Select the drop-down arrow to view options for who can upload files. Configure as desired.

1. Selecting the Switch capacity button opens a window where you as the owner could select another available capacity. For this simulation, there's no other preconfigured capacity.
2. Alternatively, you could create a new capacity. Select Create a new capacity to explore the parameters, then select Cancel.
3. Select Cancel again or the X to close the window.

1. Select Change, to explore the options then select Cancel or X to close the window.
2. Selecting See usage takes you to the Usage monitoring dashboard. You'll explore that in a subsequent step. If you selected it, return to the home menu and owner settings, there's more to explore here.

Select the **Home menu icon** then select **Plugin settings**

1. For plugins for Security Copilot, select the drop-down for Who can add and manage their own custom plugins to view the available options. Select each available option to see how it impacts the option below.
2. Select drop-down for Who can add and manage custom plugins for users of this workspace to view the available options. Note, this option is grayed out if Who can add and manage their own custom plugins is set to owners only.
3. Manage plugin availability and restrict access:

Review the description. Selecting the toggle opens a new window, review the description and enable the toggle. All plugins are restricted to owners only. You can manually change this for each plugin.
Disable the toggle to remove the restriction.
4. Review the description. Selecting the toggle opens a new window, review the description and enable the toggle. All plugins are restricted to owners only. You can manually change this for each plugin.
5. Disable the toggle to remove the restriction.
6. Accessing data from Microsoft 365 services:

Select the information icon to get information that describes the impact of this setting. With this toggle disabled, the Microsoft Purview plugin is not available to use. To ensure the use of the Purview plugin, this toggle must be enabled. You'll explore this more in the Purview unit.
7. Select the information icon to get information that describes the impact of this setting. With this toggle disabled, the Microsoft Purview plugin is not available to use. To ensure the use of the Purview plugin, this toggle must be enabled. You'll explore this more in the Purview unit.

1. Review the description. Selecting the toggle opens a new window, review the description and enable the toggle. All plugins are restricted to owners only. You can manually change this for each plugin.
2. Disable the toggle to remove the restriction.

1. Select the information icon to get information that describes the impact of this setting. With this toggle disabled, the Microsoft Purview plugin is not available to use. To ensure the use of the Purview plugin, this toggle must be enabled. You'll explore this more in the Purview unit.

Select the **Home menu icon** then select **Role assignment**.

1. Select Add members, then close.
2. Expand the Owner and Contributor roles. There are no users in the contributor role.
3. Select the + Add recommended roles

Review the description and expand each of the roles listed to view details.
Select Add to add the recommended security roles, then select Ok. Once added, users in any of the roles included become Copilot contributors.
4. Review the description and expand each of the roles listed to view details.
5. Select Add to add the recommended security roles, then select Ok. Once added, users in any of the roles included become Copilot contributors.

1. Review the description and expand each of the roles listed to view details.
2. Select Add to add the recommended security roles, then select Ok. Once added, users in any of the roles included become Copilot contributors.

Select the **Home menu icon** then select **Manage workspaces**

1. There's only one workspace available. Select the button on the top right corner of page that says + New workspace to view the parameters required. There's a subsequent exercise in this module that explores this option in more detail. Select Cancel.

Select the **Home menu icon** then select **Usage monitoring**.

1. Hovering over any of the blue bars in the bar graph opens a small window with information.
2. Note the information available for each session.
3. There are several options for filtering on the usage monitoring dashboard

You can filter by date. Select the drop-down next to where it says Last 24 hours to view the available options.
Other filtering options are available by selecting the filter icon next to the date filter. This opens many other filter options, including Users, Plugins used, type, and category. Expand each to view available options. For this simulation, filter options won't be applied. Select Cancel.
4. You can filter by date. Select the drop-down next to where it says Last 24 hours to view the available options.
5. Other filtering options are available by selecting the filter icon next to the date filter. This opens many other filter options, including Users, Plugins used, type, and category. Expand each to view available options. For this simulation, filter options won't be applied. Select Cancel.
6. Select the home menu icon to open the home menu.

1. You can filter by date. Select the drop-down next to where it says Last 24 hours to view the available options.
2. Other filtering options are available by selecting the filter icon next to the date filter. This opens many other filter options, including Users, Plugins used, type, and category. Expand each to view available options. For this simulation, filter options won't be applied. Select Cancel.

Select the **Home menu icon** then select **Settings**.

1. Select preferences. Scroll down to view available options.
2. Select data and privacy.
3. Select About.
4. Select the X to close the preferences window.

Select where it says **Woodgrove** at the bottom left of the home menu.

1. When you select this option, you see your tenants. This option is referred to as the tenant switcher. In this case, Woodgrove is the only available tenant.
2. Select the Home to return to the landing page.

Keep the browser tab open for the next task.


#### Task: Explore Prompts to try

In this task, you start exploration in the center portion of the landing page, where it says Prompts to try.

1. If you previously closed the browser tab, reopen the simulated environment by selecting this link: Microsoft Security Copilot.
2. Note the options available beneath where it says Prompts to try. Here you can search for prompts or promptbooks, and based on the option you select you can filter for a specific role and/or plugin. In this simulation, you can filter for role or plugin. Filtering for both role and plugin is limited to the SOC Analyst role and the Microsoft Sentinel Plugin. Also, running a prompt or promptbook is not enabled. You will run prompts and promptbooks is subsequent exercises.
3. Select Prompts to view available prompts. Selecting a prompt automatically updates the information displayed in the prompt bar. Select X to cancel.
4. Select the title or Get started button on promptbook to view the prompts included in that promptbook. To exit out of that promptbook, select Microsoft Security Copilot from the breadcrumb.
5. Keep the browser tab open for the next task.

If you previously closed the browser tab, reopen the simulated environment by selecting this link: **[Microsoft Security Copilot](https://app.highlights.guide/start/89a569ee-e0be-42cc-8ca8-5e375cd9f043?token=16d48b6c-eace-4a1f-8050-098d29d23a89" data-linktype="external" target="az-portal" class="has-external-link-indicator)**.

Note the options available beneath where it says Prompts to try. Here you can search for prompts or promptbooks, and based on the option you select you can filter for a specific role and/or plugin. In this simulation, you can filter for role or plugin. Filtering for both role and plugin is limited to the SOC Analyst role and the Microsoft Sentinel Plugin. Also, running a prompt or promptbook is not enabled. You will run prompts and promptbooks is subsequent exercises.

Select **Prompts** to view available prompts. Selecting a prompt automatically updates the information displayed in the prompt bar. Select X to cancel.

Select the title or Get started button on promptbook to view the prompts included in that promptbook. To exit out of that promptbook, select Microsoft Security Copilot from the breadcrumb.

Keep the browser tab open for the next task.


#### Task: Explore the prompts and sources icon in the prompt bar

At the bottom center of the page is the prompt bar. The prompt bar includes the prompts and sources icon, which you explore in this task. In subsequent exercises, you enter inputs directly in the prompt bar.

1. If you previously closed the browser tab, reopen the simulated environment by selecting this link: Microsoft Security Copilot.
2. From the prompt bar, you can select the prompts icon to select a built-in prompt or a promptbook. Select the prompts icon .

Select See all promptbooks

Scroll to view all the available promptbooks.
Select the back-arrow next to the search bar to go back.


Select See all system  capabilities. The list shows all available system capabilities (these capabilities are in effect prompts that you can run). Many system capabilities are associated with specific plugins and as such they're only listed if the corresponding plugin is enabled.

Scroll to view all the available promptbooks.
Select the back-arrow next to the search bar to go back.
3. Select See all promptbooks

Scroll to view all the available promptbooks.
Select the back-arrow next to the search bar to go back.
4. Scroll to view all the available promptbooks.
5. Select the back-arrow next to the search bar to go back.
6. Select See all system  capabilities. The list shows all available system capabilities (these capabilities are in effect prompts that you can run). Many system capabilities are associated with specific plugins and as such they're only listed if the corresponding plugin is enabled.

Scroll to view all the available promptbooks.
Select the back-arrow next to the search bar to go back.
7. Scroll to view all the available promptbooks.
8. Select the back-arrow next to the search bar to go back.
9. Select the sources icon .

The Manage sources window opens. From here, you can access Plugins or Files. The Plugins tab is selected by default.

Select whether you want to view all plugins, the plugins that are enabled (on), the plugins that are disabled (off), or the plugins that are not set up.
Expand/collapse list of Microsoft, non-Microsoft, and custom plugins.
Some plugins require configuring parameters. Select the Set up button for the Microsoft Sentinel plugin, to view the settings window. Select cancel to close the settings window. In a separate exercise, you configure the plugin.


You should still be in the Manage sources window. Select Files.

Review the description.
Files can be uploaded and used as a knowledge base by Copilot. In a subsequent exercise, you work with file uploads.
Select X to close the Manage sources window.
10. The Manage sources window opens. From here, you can access Plugins or Files. The Plugins tab is selected by default.

Select whether you want to view all plugins, the plugins that are enabled (on), the plugins that are disabled (off), or the plugins that are not set up.
Expand/collapse list of Microsoft, non-Microsoft, and custom plugins.
Some plugins require configuring parameters. Select the Set up button for the Microsoft Sentinel plugin, to view the settings window. Select cancel to close the settings window. In a separate exercise, you configure the plugin.
11. Select whether you want to view all plugins, the plugins that are enabled (on), the plugins that are disabled (off), or the plugins that are not set up.
12. Expand/collapse list of Microsoft, non-Microsoft, and custom plugins.
13. Some plugins require configuring parameters. Select the Set up button for the Microsoft Sentinel plugin, to view the settings window. Select cancel to close the settings window. In a separate exercise, you configure the plugin.
14. You should still be in the Manage sources window. Select Files.

Review the description.
Files can be uploaded and used as a knowledge base by Copilot. In a subsequent exercise, you work with file uploads.
Select X to close the Manage sources window.
15. Review the description.
16. Files can be uploaded and used as a knowledge base by Copilot. In a subsequent exercise, you work with file uploads.
17. Select X to close the Manage sources window.
18. Keep the browser tab open for the next task.

If you previously closed the browser tab, reopen the simulated environment by selecting this link: **[Microsoft Security Copilot](https://app.highlights.guide/start/89a569ee-e0be-42cc-8ca8-5e375cd9f043?token=16d48b6c-eace-4a1f-8050-098d29d23a89" data-linktype="external" target="az-portal" class="has-external-link-indicator)**.

From the prompt bar, you can select the prompts icon to select a built-in prompt or a promptbook. Select the **prompts icon** .


![prompts icon](https://learn.microsoft.com/training/wwl-sci/security-copilot-exercises/media/prompt-icon.png)

1. Select See all promptbooks

Scroll to view all the available promptbooks.
Select the back-arrow next to the search bar to go back.
2. Scroll to view all the available promptbooks.
3. Select the back-arrow next to the search bar to go back.
4. Select See all system  capabilities. The list shows all available system capabilities (these capabilities are in effect prompts that you can run). Many system capabilities are associated with specific plugins and as such they're only listed if the corresponding plugin is enabled.

Scroll to view all the available promptbooks.
Select the back-arrow next to the search bar to go back.
5. Scroll to view all the available promptbooks.
6. Select the back-arrow next to the search bar to go back.

1. Scroll to view all the available promptbooks.
2. Select the back-arrow next to the search bar to go back.

1. Scroll to view all the available promptbooks.
2. Select the back-arrow next to the search bar to go back.

Select the **sources icon** .


![sources icon](https://learn.microsoft.com/training/wwl-sci/security-copilot-exercises/media/sources-icon.png)

1. The Manage sources window opens. From here, you can access Plugins or Files. The Plugins tab is selected by default.

Select whether you want to view all plugins, the plugins that are enabled (on), the plugins that are disabled (off), or the plugins that are not set up.
Expand/collapse list of Microsoft, non-Microsoft, and custom plugins.
Some plugins require configuring parameters. Select the Set up button for the Microsoft Sentinel plugin, to view the settings window. Select cancel to close the settings window. In a separate exercise, you configure the plugin.
2. Select whether you want to view all plugins, the plugins that are enabled (on), the plugins that are disabled (off), or the plugins that are not set up.
3. Expand/collapse list of Microsoft, non-Microsoft, and custom plugins.
4. Some plugins require configuring parameters. Select the Set up button for the Microsoft Sentinel plugin, to view the settings window. Select cancel to close the settings window. In a separate exercise, you configure the plugin.
5. You should still be in the Manage sources window. Select Files.

Review the description.
Files can be uploaded and used as a knowledge base by Copilot. In a subsequent exercise, you work with file uploads.
Select X to close the Manage sources window.
6. Review the description.
7. Files can be uploaded and used as a knowledge base by Copilot. In a subsequent exercise, you work with file uploads.
8. Select X to close the Manage sources window.

1. Select whether you want to view all plugins, the plugins that are enabled (on), the plugins that are disabled (off), or the plugins that are not set up.
2. Expand/collapse list of Microsoft, non-Microsoft, and custom plugins.
3. Some plugins require configuring parameters. Select the Set up button for the Microsoft Sentinel plugin, to view the settings window. Select cancel to close the settings window. In a separate exercise, you configure the plugin.

1. Review the description.
2. Files can be uploaded and used as a knowledge base by Copilot. In a subsequent exercise, you work with file uploads.
3. Select X to close the Manage sources window.

Keep the browser tab open for the next task.


#### Task:  Explore the help feature

At the bottom right corner of the window is the help icon where you can easily access documentation and find solutions to common problems. From the help icon, you also submit a support case to the Microsoft support team if you have the appropriate role permissions.

1. Select the Help (?) icon.

Select Documentation. This selection opens a new browser tab to the Security Copilot documentation. Return to the Microsoft Security Copilot browser tab. Close the newly opened tab and return the Microsoft Security Copilot tab.
Select Training. This selection opens a new browser tab to the YouTube channel for Microsoft Security Copilot Instructional Demo Videos. Close the newly opened tab and return the Microsoft Security Copilot tab.
Select Help.

Anyone with access to Security Copilot can access the self help widget by selecting the help icon. The help page opens to the search option. Here you can find solutions to common problems by entering something about the problem. For this simulation, enter Describe Security Copilot then select Get Help.
Users with a minimum role of Service Support Administrator or Helpdesk Administrator role can submit a support case to the Microsoft support team. If you have this role, a headset icon is displayed. Close the contact support page.
2. Select Documentation. This selection opens a new browser tab to the Security Copilot documentation. Return to the Microsoft Security Copilot browser tab. Close the newly opened tab and return the Microsoft Security Copilot tab.
3. Select Training. This selection opens a new browser tab to the YouTube channel for Microsoft Security Copilot Instructional Demo Videos. Close the newly opened tab and return the Microsoft Security Copilot tab.
4. Select Help.

Anyone with access to Security Copilot can access the self help widget by selecting the help icon. The help page opens to the search option. Here you can find solutions to common problems by entering something about the problem. For this simulation, enter Describe Security Copilot then select Get Help.
Users with a minimum role of Service Support Administrator or Helpdesk Administrator role can submit a support case to the Microsoft support team. If you have this role, a headset icon is displayed. Close the contact support page.
5. Anyone with access to Security Copilot can access the self help widget by selecting the help icon. The help page opens to the search option. Here you can find solutions to common problems by entering something about the problem. For this simulation, enter Describe Security Copilot then select Get Help.
6. Users with a minimum role of Service Support Administrator or Helpdesk Administrator role can submit a support case to the Microsoft support team. If you have this role, a headset icon is displayed. Close the contact support page.

1. Select Documentation. This selection opens a new browser tab to the Security Copilot documentation. Return to the Microsoft Security Copilot browser tab. Close the newly opened tab and return the Microsoft Security Copilot tab.
2. Select Training. This selection opens a new browser tab to the YouTube channel for Microsoft Security Copilot Instructional Demo Videos. Close the newly opened tab and return the Microsoft Security Copilot tab.
3. Select Help.

Anyone with access to Security Copilot can access the self help widget by selecting the help icon. The help page opens to the search option. Here you can find solutions to common problems by entering something about the problem. For this simulation, enter Describe Security Copilot then select Get Help.
Users with a minimum role of Service Support Administrator or Helpdesk Administrator role can submit a support case to the Microsoft support team. If you have this role, a headset icon is displayed. Close the contact support page.
4. Anyone with access to Security Copilot can access the self help widget by selecting the help icon. The help page opens to the search option. Here you can find solutions to common problems by entering something about the problem. For this simulation, enter Describe Security Copilot then select Get Help.
5. Users with a minimum role of Service Support Administrator or Helpdesk Administrator role can submit a support case to the Microsoft support team. If you have this role, a headset icon is displayed. Close the contact support page.

1. Anyone with access to Security Copilot can access the self help widget by selecting the help icon. The help page opens to the search option. Here you can find solutions to common problems by entering something about the problem. For this simulation, enter Describe Security Copilot then select Get Help.
2. Users with a minimum role of Service Support Administrator or Helpdesk Administrator role can submit a support case to the Microsoft support team. If you have this role, a headset icon is displayed. Close the contact support page.


#### Review

In this exercise, you explored Microsoft Security Copilot standalone experience. You explored the key landmarks of Copilot landing page including the owner settings, your past sessions, prompts and promptbooks, and the help option.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/security-copilot-exercises/3-explore-standalone-experience/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/security-copilot-exercises/3-explore-standalone-experience/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*