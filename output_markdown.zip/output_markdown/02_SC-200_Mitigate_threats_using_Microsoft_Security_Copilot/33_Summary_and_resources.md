---
title: Summary and resources
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 33
url: https://learn.microsoft.com/en-us/training/modules/security-copilot-embedded-experiences/7-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: summary
crawled_at: 2025-11-25T17:10:45.097963
---

# Summary and resources

> Summary and resources on the embedded experiences of Microsoft Security Copilot.

In this module, you learned about the embedded experience for Microsoft. The embedded experience is a great place to start a security investigation, while enabling analysts the ability to pivot to the standalone experience to pursue a more detailed, cross product investigation that brings to bear all the Copilot capabilities enabled for your role.

Now that you completed this module, you can:

- Describe Copilot in Microsoft Defender XDR.
- Describe Copilot in Microsoft Purview.
- Describe Copilot in Microsoft Entra.
- Describe Copilot in Microsoft Intune.
- Describe Copilot in Microsoft Defender for Cloud.


#### Learn more

- Microsoft Security Copilot experiences
- What is Microsoft Defender XDR?
- Microsoft Security Copilot in Microsoft Defender XDR
- Investigate a file
- Learn about Microsoft Purview
- Learn about data loss prevention
- Learn about communication compliance
- Overview of Microsoft Purview eDiscovery (Premium)
- Learn about insider risk management
- Microsoft Copilot in Intune (public preview)
- Copilot for Security in Defender for Cloud (Preview)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/security-copilot-embedded-experiences/7-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/security-copilot-embedded-experiences/7-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*