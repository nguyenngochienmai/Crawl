---
title: Copilot in Microsoft Defender for Cloud (Preview)
learning_path: SC-200: Mitigate threats using Microsoft Security Copilot
module_number: 31
url: https://learn.microsoft.com/en-us/training/modules/security-copilot-embedded-experiences/5a-copilot-for-defender-cloud/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security
type: content
crawled_at: 2025-11-25T16:56:52.529132
---

# Copilot in Microsoft Defender for Cloud (Preview)

> Copilot in Microsoft Defender for Cloud.

Defender for Cloud integrates Copilot directly in to the Defender for Cloud experience. This integration allows you to analyze, summarize, remediate, and delegate your recommendations with natural language prompts

Copilot in Defender for Cloud is available for all users when you:

- Enable Defender for Cloud on your environment.
- Have access to Azure Copilot.
- Have Security Compute Units assigned for Security Copilot.

Copilot in Defender for Cloud isn't reliant on any of the available plans in Defender. However, in order to enjoy the full range of Copilot's capabilities in Defender for Cloud, we recommend enabling the Defender for Cloud Security Posture Management (DCSPM) plan on your environments. The DCSPM plan includes many extra security features such as Attack path analysis, Risk prioritization and more, all of which can be navigated and managed using Security Copilot. Without the DCSPM plan, you're still able to use Copilot in Defender for Cloud, but in a limited capacity.

The list of Copilot capabilities embedded in Microsoft Defender for Cloud is continually growing. This unit provides just a sampling of those capabilities. For more information, see documentation on Microsoft Defender for Cloud.


### Analyze recommendations with Security Copilot

Microsoft Defender for Cloud's integration with Security Copilot allows you to analyze all of the recommendations presented on the recommendations page. By narrowing the scope of the recommendations page, you can focus on specific recommendations and get a better understanding of your security posture.

Once the list of recommendations is filtered, you can investigate specific recommendations and gain a better understanding of the risks and vulnerabilities that are present in your environment.

To analyze your recommendations:

1. From the Azure portal, search for and select Microsoft Defender for Cloud.
2. Navigate to Recommendations.
3. Select Analyze with Copilot.
4. Select one of the suggested prompts or enter a prompt in natural language. Some sample prompts include:

Show risks for publicly exposed resources
Show risks for resources with sensitive data
Show risks for critical resources
5. Show risks for publicly exposed resources
6. Show risks for resources with sensitive data
7. Show risks for critical resources
8. Copilot generates an initial analysis and you can filter the list of recommendation based on that initial analysis. You can further refine the results by selecting one of the suggested follow-up prompts or entering one manually, and applying the filter.

From the Azure portal, search for and select Microsoft Defender for Cloud.

Navigate to Recommendations.

Select Analyze with Copilot.


![Screen capture of the recommendations page of Microsoft Defender for Cloud.](https://learn.microsoft.com/training/wwl-sci/security-copilot-embedded-experiences/media/defender-for-cloud-recommendations.png)

Select one of the suggested prompts or enter a prompt in natural language. Some sample prompts include:

- Show risks for publicly exposed resources
- Show risks for resources with sensitive data
- Show risks for critical resources

Copilot generates an initial analysis and you can filter the list of recommendation based on that initial analysis. You can further refine the results by selecting one of the suggested follow-up prompts or entering one manually, and applying the filter.


![Screen capture of the recommendations analysis provided by Microsoft Defender for Cloud and the option to filter the list of recommendations.](https://learn.microsoft.com/training/wwl-sci/security-copilot-embedded-experiences/media/defend-for-cloud-apply-filter.png)

The recommendations page updates with the appropriate filters applied based on the prompts you provided. Copilot remains open and you can enter other prompts as needed.


### Summarize recommendations with Security Copilot

Microsoft Defender for Cloud's integration with Security Copilot allows you to summarize a recommendation to get a better understanding of the risks and vulnerabilities that are present in your environment.

By summarizing a recommendation, you can get a quick overview of the recommendation in natural language. Summarizing the recommendation helps you understand the information presented in a recommendation and allows you to prioritize your remediation efforts.

Once a recommendation is selected, you can summarize it with Copilot. By using prompts, you can get a better understanding of the recommendation and decide how best to handle it.

To summarize a selected recommendation:

1. From the Azure portal, search for and select Microsoft Defender for Cloud.
2. Navigate to Recommendations, then select a recommendation.
3. From the recommendation page, select Summarize with Copilot.
4. Once Copilot generates a summary response, you enter more prompts as needed.

From the Azure portal, search for and select Microsoft Defender for Cloud.

Navigate to Recommendations, then select a recommendation.

From the recommendation page, select Summarize with Copilot.


![Screen capture of the recommendation summary generated by Copilot.](https://learn.microsoft.com/training/wwl-sci/security-copilot-embedded-experiences/media/defender-for-cloud-summarize-recommendation.png)

Once Copilot generates a summary response, you enter more prompts as needed.

Once you have a better understanding of the recommendation, you can decide how best to handle it. You can, for example, select to have Copilot help you remediate the recommendation, delegate the remediation to the resource owner, or you can enter other prompts as needed.


### Remediate recommendations with Security Copilot

Microsoft Defender for Cloud's integration with Security Copilot allows you to remediate recommendations that are present on the recommendations page with natural language prompts. Remediating a recommendation with Security Copilot allows you to improve your security posture by addressing the risks and vulnerabilities that are present in your environment.

Once a recommendation is summarized with Copilot in Defender for Cloud, you can decide how best to handle it. By using prompts, you can have Security Copilot assist you in the remediation process.

To use Copilot in Defender for Cloud to assist with the remediation process for recommendations:

1. Summarize a recommendation, as described in the section, 'Summarize recommendations with Security Copilot'
2. Select Help me remediate this recommendation.
3. Review the suggested remediation information and follow the instructions to remediate the recommendation. In some cases, a recommendation may include a script that can be run to apply the remediation.

Summarize a recommendation, as described in the section, 'Summarize recommendations with Security Copilot'

Select Help me remediate this recommendation.

Review the suggested remediation information and follow the instructions to remediate the recommendation. In some cases, a recommendation may include a script that can be run to apply the remediation.


![Screen capture of a recommendation summary showing the option to run a script to remediate a recommendation.](https://learn.microsoft.com/training/wwl-sci/security-copilot-embedded-experiences/media/defender-for-cloud-run-script.png)


### Delegate recommendations with Security Copilot

Microsoft Defender for Cloud's integration with Security Copilot allows you to delegate recommendations that are present on the recommendations page with natural language prompts. Recommendations can be delegated to another person or team.

Delegating recommendations can improve your security posture by having the right people address the risks and vulnerabilities presented by the recommendations that are present in your environment.

To use Copilot to delegate recommendations and ensure the right person or team is handling the risks and vulnerabilities that are present in your environment:

1. Summarize a recommendation, as described in the section, 'Summarize recommendations with Security Copilot.'
2. Select Delegate the remediation to the resource owner.
3. Copilot summarizes an email that it drafts. You can then select to view and send the email.
4. Review the email and add recipients, and select Send.

Summarize a recommendation, as described in the section, 'Summarize recommendations with Security Copilot.'

Select Delegate the remediation to the resource owner.

Copilot summarizes an email that it drafts. You can then select to view and send the email.


![Screen capture of the response copilot generates when you select to delegate a recommendation to the resource owner.](https://learn.microsoft.com/training/wwl-sci/security-copilot-embedded-experiences/media/defender-for-cloud-delegate-v2b.png)

Review the email and add recipients, and select Send.


![Screen capture of the email copilot generates when you select to delegate a recommendation to the resource owner.](https://learn.microsoft.com/training/wwl-sci/security-copilot-embedded-experiences/media/defender-for-cloud-delegate-email.png)

Once the recommendation is delegated, you can monitor the progress of the remediation on Defender for Cloud's recommendations page. Copilot remains open and you can enter other prompts as needed.


### Remediate code with Security Copilot

Microsoft Defender for Cloud's integration with Security Copilot allows you to remediate Infrastructure as Code (IaC) misconfigurations that are discovered in your code repositories. Remediating an IaC finding with Copilot allows you to address security misconfigurations and vulnerabilities early in the development cycle by automatically generating Pull Requests (PRs) that correct the identified weaknesses. Remediating these misconfigurations and vulnerabilities ensure that security issues in code are addressed accurately and promptly.

To use Copilot to help remediate Infrastructure as Code (IaC) misconfigurations that are discovered in your code repositories, you must:

- Enable Defender for Cloud on your environment.
- Have access to Azure Copilot.
- Have Security Compute Units assigned for Security Copilot.
- Connect your Azure DevOps environment to Defender for Cloud.
- Configure the Microsoft Security DevOps Azure DevOps extension.
- Review and ensure you meet the DevOps security support and prerequisites requirements.

To remediate an Infrastructure as Code scanning finding:

1. From the Azure portal, search for and select Microsoft Defender for Cloud.
2. Navigate to Recommendations.
3. Search for recommendations with the title 'Azure DevOps repositories should have infrastructure as code scanning findings resolved' recommendation then select any of the resulting recommendations.
4. Select Reduce risk with Copilot.
5. By selecting 'Select security check,' Copilot can generate pull requests to remediate supported security checks from the recommendation.
6. Select the appropriate description followed by the select button.
7. Review the summary of the code fix, then select Submit.
8. Select the provided link.
9. Review the PR.

From the Azure portal, search for and select Microsoft Defender for Cloud.

Navigate to Recommendations.

Search for recommendations with the title 'Azure DevOps repositories should have infrastructure as code scanning findings resolved' recommendation then select any of the resulting recommendations.

Select Reduce risk with Copilot.


![Screen capture of a recommendation titled, 'Azure DevOps repositories should have infrastructure as code scanning findings resolved' and the option to reduce risk with Copilot.](https://learn.microsoft.com/training/wwl-sci/security-copilot-embedded-experiences/media/defender-for-cloud-devops.png)

By selecting 'Select security check,' Copilot can generate pull requests to remediate supported security checks from the recommendation.

Select the appropriate description followed by the select button.


![Screen capture showing Copilot's response to selecting Reduce risk with Copilot.](https://learn.microsoft.com/training/wwl-sci/security-copilot-embedded-experiences/media/defender-for-cloud-security-check-v2.png)

Review the summary of the code fix, then select Submit.

Select the provided link.

Review the PR.

Once the PR is generated in your code repository, you should have a developer review and approve the PR to have it merged into the code base.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/security-copilot-embedded-experiences/5a-copilot-for-defender-cloud/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security](https://learn.microsoft.com/en-us/training/modules/security-copilot-embedded-experiences/5a-copilot-for-defender-cloud/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-copilot-for-security)*