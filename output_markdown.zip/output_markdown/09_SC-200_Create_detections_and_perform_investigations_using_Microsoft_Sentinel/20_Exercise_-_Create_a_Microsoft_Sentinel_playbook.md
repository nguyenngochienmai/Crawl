---
title: Exercise - Create a Microsoft Sentinel playbook
learning_path: SC-200: Create detections and perform investigations using Microsoft Sentinel
module_number: 20
url: https://learn.microsoft.com/en-us/training/modules/threat-response-sentinel-playbooks/6-exercise-create-playbook/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel
type: exercise
crawled_at: 2025-11-25T19:20:23.502542
---

# Exercise - Create a Microsoft Sentinel playbook

> Create a Microsoft Sentinel playbook.

As a Security Operations Analyst working for Contoso, you recently notice that a significant number of alerts are generated when someone deletes a virtual machine. You want to analyze such occurrences in the future and reduce the alerts generated for false positive occurrences.


## Exercise: Threat response using Microsoft Sentinel playbooks

You decide to implement a Microsoft Sentinel playbook to automate responses to an incident.

In this exercise, you'll explore the Microsoft Sentinel playbooks by performing the following tasks:

- Configure Microsoft Sentinel Playbook permissions.
- Create a playbook to automate an action to respond to incidents.
- Test your playbook by invoking an incident.

Configure Microsoft Sentinel Playbook permissions.

Create a playbook to automate an action to respond to incidents.

Test your playbook by invoking an incident.

You need to have completed the Exercise Setup unit, in order to be able to complete this exercise. If you have not done so, complete it now, and then continue with the exercise steps.


### Task 1: Configure Microsoft Sentinel Playbook permissions

1. In the Azure portal, search for and select Microsoft Sentinel, and select the previously created Microsoft Sentinel workspace.
2. In the Microsoft Sentinel page, on the menu bar, in the Configuration section, select Settings.
3. In the Settings page, select the Settings tab and scroll down and expand the Playbook permissions
4. In Playbook permissions, select the Configure permissions button.
5. In the Manage permissions page under the Browse tab, select the resource group that your Microsoft Sentinel workspace belongs to. Select Apply.
6. You should see the Finished adding permissions message.

In the Azure portal, search for and select Microsoft Sentinel, and select the previously created Microsoft Sentinel workspace.

In the **Microsoft Sentinel** page, on the menu bar, in the **Configuration** section, select **Settings**.

In the **Settings** page, select the **Settings** tab and scroll down and expand the **Playbook permissions**

In **Playbook permissions**, select the **Configure permissions** button.


![Screenshot of the Microsoft Sentinel Playbook permissions.](https://learn.microsoft.com/training/wwl-sci/threat-response-sentinel-playbooks/media/06-sentinel-playbook-permissions.png)

In the **Manage permissions** page under the **Browse** tab, select the resource group that your Microsoft Sentinel workspace belongs to. Select **Apply**.


![Screenshot of the Microsoft Sentinel Playbook Manage permissions page.](https://learn.microsoft.com/training/wwl-sci/threat-response-sentinel-playbooks/media/06-manage-permissions.png)

You should see the **Finished adding permissions** message.


### Task 2: Work with Microsoft Sentinel playbooks

1. In the Azure portal, search for and select Microsoft Sentinel, and select the previously created Microsoft Sentinel workspace.
2. In the Microsoft Sentinel page, on the menu bar, in the Configuration section, select Automation.
3. On the top menu, select Create and Playbook with incident trigger.
4. In the  Create Playbooks page, on the Basics tab, specify the following settings:
 
		
			
		
		Expand table
	


Settings
Value




Subscription
Select your Azure subscription.


Resource group
Select the resource group of your Microsoft Sentinel service.


Playbook name
ClosingIncident (you can choose any name)


Region
Select the same location as the location of Microsoft Sentinel.


Log Analytics workspace
Don't enable diagnostic logs
5. Select  Next:Connections >, then select Next: Review and Create >
6. Select Create and continue to designer

 Note
Wait for the deployment to complete. The deployment should take less than 1 minute. If it keeps running you may need to refresh the page.
7. In the Logic Apps Designer pane, you should see the Microsoft Sentinel incident (preview) displayed.
8. On the Microsoft Sentinel incident (preview) page, select the Change connection link.
9. On the Connections page, select Add new.
10. On the Microsoft Sentinel page, select Sign in.
11. On the Sign in to your account page, provide the credentials for your Azure subscription.
12. Back on the Microsoft Sentinel incident (preview) page, you should see you're connected to your account. Select + New step.
13. In the Choose an operation window, in the search field,  type Microsoft Sentinel.
14. Select the Microsoft Sentinel Icon.
15. On the Actions tab, locate and select Get incident (Preview).
16. In the Get Incident (Preview) window, select the Incident ARM ID field. The Add dynamic content window opens.

 Tip
When you select a field, a new window opens to help you fill these fields with dynamic content.
17. On the Dynamic content tab, in the search box, you can start entering Incident ARM, and then select the entry from the list, as the following screenshot displays.
18. Select + New step.
19. In the Choose an operation window, in the search field,  type Microsoft Sentinel.

 Tip
In the For you tab, Recent selections should display the Microsoft Sentinel Icon.
20. Select the Microsoft Sentinel Icon.
21. From the Actions tab, locate and select Update incident (Preview).
22. In the Update incident (Preview) window, provide the following inputs:
 
		
			
		
		Expand table
	


Settings
Values




Specify Incident ARM id
Incident ARM ID


Specify Owner Object Id / UPN
Incident Owner Object ID


Specify Assign/Unassign owner
From the drop-down menu, select Unassign


Severity
You can leave the default Incident severity


Specify Status
From the drop-down menu, select Closed.


Specify Classification reason
From the drop-down menu, select an entry like Undetermined, or select Enter custom value, and select IncidentClassification Dynamic content.


Close reason text
Write descriptive text.
23. Select the Incident ARM ID field. The Add dynamic content window opens, in the search box, you can start entering Incident ARM. Select Incident ARM ID and then select the Owner Object Id / UPN field.
24. The Add dynamic content window opens, in the search box, you can start entering Incident owner. Select Incident Owner Object ID and then fill in the remaining fields using the table entries.
25. When done, choose Save from the Logic Apps Designer menu bar, and then close the Logic Apps Designer.

In the Azure portal, search for and select Microsoft Sentinel, and select the previously created Microsoft Sentinel workspace.

In the **Microsoft Sentinel** page, on the menu bar, in the **Configuration** section, select **Automation**.

On the top menu, select **Create** and **Playbook with incident trigger**.

In the  **Create Playbooks** page, on the **Basics** tab, specify the following settings:

| Settings | Value |
| --- | --- |
| Subscription | Select your Azure subscription. |
| Resource group | Select the resource group of your Microsoft Sentinel service. |
| Playbook name | ClosingIncident (you can choose any name) |
| Region | Select the same location as the location of Microsoft Sentinel. |
| Log Analytics workspace | Don't enable diagnostic logs |

Select  **Next:Connections &gt;**, then select **Next: Review and Create &gt;**

Select **Create and continue to designer**

Wait for the deployment to complete. The deployment should take less than 1 minute. If it keeps running you may need to refresh the page.

In the **Logic Apps Designer** pane, you should see the **Microsoft Sentinel incident (preview)** displayed.


![Screenshot of the Microsoft Sentinel trigger.](https://learn.microsoft.com/training/wwl-sci/threat-response-sentinel-playbooks/media/06-azure-sentinel-trigger.png)

On the **Microsoft Sentinel incident (preview)** page, select the **Change connection** link.

On the **Connections** page, select **Add new**.

On the Microsoft Sentinel page, select **Sign in**.


![Screenshot of the authorizing API connection.](https://learn.microsoft.com/training/wwl-sci/threat-response-sentinel-playbooks/media/06-sign-in-aad-tenant.png)

On the **Sign in to your account** page, provide the credentials for your Azure subscription.

Back on the **Microsoft Sentinel incident (preview)** page, you should see you're connected to your account. Select **+ New step**.

In the **Choose an operation** window, in the search field,  type **Microsoft Sentinel**.

Select the **Microsoft Sentinel** Icon.

On the **Actions** tab, locate and select **Get incident (Preview)**.

In the **Get Incident (Preview)** window, select the **Incident ARM ID field**. The **Add dynamic content** window opens.

When you select a field, a new window opens to help you fill these fields with dynamic content.

On the **Dynamic content** tab, in the search box, you can start entering **Incident ARM**, and then select the entry from the list, as the following screenshot displays.


![Screenshot of Get Incident.](https://learn.microsoft.com/training/wwl-sci/threat-response-sentinel-playbooks/media/06-get-incident.png)

Select **+ New step**.

In the **Choose an operation** window, in the search field,  type **Microsoft Sentinel**.

In the For you tab, Recent selections should display the Microsoft Sentinel Icon.

Select the **Microsoft Sentinel** Icon.

From the **Actions** tab, locate and select **Update incident (Preview)**.

In the **Update incident (Preview)** window, provide the following inputs:

| Settings | Values |
| --- | --- |
| Specify Incident ARM id | Incident ARM ID |
| Specify Owner Object Id / UPN | Incident Owner Object ID |
| Specify Assign/Unassign owner | From the drop-down menu, select Unassign |
| Severity | You can leave the default Incident severity |
| Specify Status | From the drop-down menu, select Closed. |
| Specify Classification reason | From the drop-down menu, select an entry like Undetermined, or select Enter custom value, and select IncidentClassification Dynamic content. |
| Close reason text | Write descriptive text. |


![Screenshot of the Get Incident status.](https://learn.microsoft.com/training/wwl-sci/threat-response-sentinel-playbooks/media/06-change-incident-status.png)

Select the **Incident ARM ID field**. The **Add dynamic content** window opens, in the search box, you can start entering **Incident ARM**. Select **Incident ARM ID** and then select the **Owner Object Id / UPN** field.

The **Add dynamic content** window opens, in the search box, you can start entering **Incident owner**. Select **Incident Owner Object ID** and then fill in the remaining fields using the table entries.

When done, choose **Save** from the Logic Apps Designer menu bar, and then close the Logic Apps Designer.


### Task 3: Invoke an incident and review the associated actions

1. In the Azure portal, in the Search resources, services, and docs text box, type virtual machines, and then select Enter.
2. On the Virtual machines page, locate and select the simple-vm virtual machine, and then on the header bar, select Delete.
3. On the Delete simple-vm page, select Delete with VM for both the OS Disk and the Network Interface.
4. Select the box to acknowledge I have read and understand that this virtual machine as well as any selected resources will be deleted, then select Delete to delete the virtual machine.





 Note
This task creates an incident based on the analytics rule that you created earlier in the exercise setup unit. Incident creation can take up to 15 minutes. Wait for it to complete before proceeding to the next step.

In the Azure portal, in the **Search resources, services, and docs** text box, type **virtual machines**, and then select **Enter**.

On the **Virtual machines** page, locate and select the **simple-vm** virtual machine, and then on the header bar, select **Delete**.

On the **Delete simple-vm** page, select **Delete with VM** for both the **OS Disk** and the **Network Interface**.

Select the box to acknowledge **I have read and understand that this virtual machine as well as any selected resources will be deleted**, then select **Delete** to delete the virtual machine.


![Screenshot of the Delete simple-vm page.](https://learn.microsoft.com/training/wwl-sci/threat-response-sentinel-playbooks/media/06-delete-simple-vm.png)

This task creates an incident based on the analytics rule that you created earlier in the exercise setup unit. Incident creation can take up to 15 minutes. Wait for it to complete before proceeding to the next step.


### Task 4: Assign the playbook to an existing incident

1. In the Azure portal, search for and select Microsoft Sentinel, and then select the previously created Microsoft Sentinel workspace.
2. On the Microsoft Sentinel | Overview page, on the menu bar, in the Threat management section, select Incidents.

 Note
As mentioned in the previous note, Incident creation can take up to 15 minutes. Refresh the page until incident appears in the Incidents page.
3. On the Microsoft Sentinel | Incidents page, select an incident that has been created based on the deletion of the virtual machine.
4. In the details pane, select Actions and Run playbook (Preview).
5. On the Run playbook on incident page, in the Playbooks tab, you should see the ClosingIncident playbook, select Run.
6. Verify that you receive the message Playbook was triggered successfully.
7. Close the Run playbook on incident page, to return to the Microsoft Sentinel | Incidents page.
8. In the Microsoft Sentinel | Incidents page, on the header bar, select Refresh. You'll notice that the incident disappears from the pane. On the Status menu, select Closed, and then select OK.

 Note
It could take up to 5 minute for Alerts to be shown as Closed
9. Verify that the incident displays again and notice the Status column to check that it's Closed.

In the Azure portal, search for and select Microsoft Sentinel, and then select the previously created Microsoft Sentinel workspace.

On the **Microsoft Sentinel | Overview** page, on the menu bar, in the **Threat management** section, select **Incidents**.

As mentioned in the previous note, Incident creation can take up to 15 minutes. Refresh the page until incident appears in the **Incidents** page.

On the **Microsoft Sentinel | Incidents** page, select an incident that has been created based on the deletion of the virtual machine.

In the details pane, select **Actions** and **Run playbook (Preview)**.


![Screenshot of the Incident detail pane actions to run playbook.](https://learn.microsoft.com/training/wwl-sci/threat-response-sentinel-playbooks/media/06-incident-run-playbook.png)

On the **Run playbook on incident** page, in the **Playbooks tab,** you should see the **ClosingIncident** playbook, select **Run**.

Verify that you receive the message **Playbook was triggered successfully**.

Close the **Run playbook on incident** page, to return to the **Microsoft Sentinel | Incidents** page.

In the **Microsoft Sentinel | Incidents** page, on the header bar, select **Refresh**. You'll notice that the incident disappears from the pane. On the **Status** menu, select **Closed**, and then select **OK**.

It could take up to 5 minute for Alerts to be shown as **Closed**


![Screenshot of the header bar.](https://learn.microsoft.com/training/wwl-sci/threat-response-sentinel-playbooks/media/06-header-refresh.png)

Verify that the incident displays again and notice the **Status** column to check that it's **Closed**.


### Clean up the resources

1. In the Azure portal, search for Resource groups.
2. Select azure-sentinel-rg.
3. On the header bar, select Delete resource group.
4. In the TYPE THE RESOURCE GROUP NAME: field, enter the name of the resource group azure-sentinel-rg and select Delete.

In the Azure portal, search for **Resource groups**.

Select **azure-sentinel-rg**.

On the header bar, select **Delete resource group**.

In the **TYPE THE RESOURCE GROUP NAME:** field, enter the name of the resource group **azure-sentinel-rg** and select **Delete**.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/threat-response-sentinel-playbooks/6-exercise-create-playbook/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/threat-response-sentinel-playbooks/6-exercise-create-playbook/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel)*