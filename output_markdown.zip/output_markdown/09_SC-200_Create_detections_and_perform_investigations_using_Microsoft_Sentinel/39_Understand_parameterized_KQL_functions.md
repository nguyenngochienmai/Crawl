---
title: Understand parameterized KQL functions
learning_path: SC-200: Create detections and perform investigations using Microsoft Sentinel
module_number: 39
url: https://learn.microsoft.com/en-us/training/modules/data-normalization-microsoft-sentinel/4-understand-parameterized-kql-functions/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel
type: content
crawled_at: 2025-11-25T19:23:48.579453
---

# Understand parameterized KQL functions

> Understand parameterized KQL functions

When calling KQL functions, you can provide a set of parameters.  This is an important concept for building ASIM parsers as it allows you to filter the function results with dynamic values before returning results.

First, navigate to Logs in the Microsoft Sentinel workspace.

The following sample function returns all events in the Azure Activity log since a particular date and that match a particular category.

Start with the following query using hardcoded values. This verifies that the query works as expected.


```text
AzureActivity
| where CategoryValue == "Administrative"
| where TimeGenerated > todatetime("2021/04/05 5:40:01.032 PM")
```

Next, replace the hardcoded values with parameter names and then save the function by selecting Save and then Save as function.


```text
AzureActivity
| where CategoryValue == CategoryParam
| where TimeGenerated > DateParam
```

Enter Function name as AzureActivityByCategory
Then create two parameters:

| Type | Name | Default value |
| --- | --- | --- |
| string | CategoryParam | "Administrative" |
| datetime | DateParam |  |

Your screen should look like the image below:


![Screenshot of K Q L Function properties.](https://learn.microsoft.com/training/wwl-sci/data-normalization-microsoft-sentinel/media/example-function-properties.png#lightbox)

Create a new query. Then enter:


```text
AzureActivityByCategory("Administrative", todatetime("2021/04/05 5:40:01.032 PM"))
```


![Screenshot of the K Q L calling Function.](https://learn.microsoft.com/training/wwl-sci/data-normalization-microsoft-sentinel/media/example-use-function.png#lightbox)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/data-normalization-microsoft-sentinel/4-understand-parameterized-kql-functions/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/data-normalization-microsoft-sentinel/4-understand-parameterized-kql-functions/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel)*