---
title: Summary and resources
learning_path: SC-200: Create detections and perform investigations using Microsoft Sentinel
module_number: 43
url: https://learn.microsoft.com/en-us/training/modules/data-normalization-microsoft-sentinel/8-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel
type: summary
crawled_at: 2025-11-25T19:24:57.883280
---

# Summary and resources

> Summary and resources

You should have learned how to normalize and use ASIM Parsers in Microsoft Sentinel.

You should now be able to:

- Use ASIM Parsers
- Create ASIM Parser
- Create parameterized KQL functions


## Learn more

You can learn more by reviewing the following.

[Become a Microsoft Sentinel Ninja](https://techcommunity.microsoft.com/t5/azure-sentinel/become-an-azure-sentinel-ninja-the-complete-level-400-training/ba-p/1246310" data-linktype="external" target="az-portal" class="has-external-link-indicator)

[Microsoft Tech Community Security Webinars](https://techcommunity.microsoft.com/t5/microsoft-security-and/security-community-webinars/ba-p/927888" data-linktype="external" target="az-portal" class="has-external-link-indicator)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/data-normalization-microsoft-sentinel/8-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/data-normalization-microsoft-sentinel/8-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel)*