---
title: Exercise - Query and visualize data with Microsoft Sentinel Workbooks
learning_path: SC-200: Create detections and perform investigations using Microsoft Sentinel
module_number: 45
url: https://learn.microsoft.com/en-us/training/modules/query-data-sentinel/2-exercise-setup/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel
type: exercise
crawled_at: 2025-11-25T19:25:14.097027
---

# Exercise - Query and visualize data with Microsoft Sentinel Workbooks

> Query and visualize data with Microsoft Sentinel Workbooks.

This *query and visualize data* exercise is an optional unit. If you want to perform this exercise, you need access to an Azure subscription where you can create Azure resources. If you don't have an Azure subscription, create a [free account](https://azure.microsoft.com/pricing/purchase-options/azure-account?cid=msft_learn" data-linktype="external) before you begin.

If you choose to perform the exercise in this module, be aware that you might incur costs in your Azure Subscription. To estimate the cost, refer to [Microsoft Sentinel Pricing](https://azure.microsoft.com/pricing/details/azure-sentinel/" data-linktype="external).

To deploy the prerequisites for the exercise, perform the following tasks.


## Task 1: Create resources

1. Select the following link:

You're prompted to sign in to Azure.
2. On the Custom deployment page, provide the following information:
 
		
			
		
		Expand table
	


Name
Description




Subscription
Select your Azure subscription.


Resource group
Select Create new and provide a name for the resource group such as azure-sentinel-rg.


Region
From the dropdown menu, select the location where you want to deploy Microsoft Sentinel.


Workspace Name
Provide a unique name for the Microsoft Sentinel Workspace such as <yourName>-sentinel.


Location
Accept the default value of [resourceGroup().location].


Simplevm Name
Accept the default value of simple-vm.


Simplevm Windows OS Version
Accept the default value of 2022-Datacenter.
3. Select Review + create, and then select Create.





 Note
Wait for the deployment to complete. The deployment should take less than 5 minutes.

Select the following link:


![Deploy To Azure.](https://aka.ms/deploytoazurebutton)

You're prompted to sign in to Azure.

On the **Custom deployment** page, provide the following information:

| Name | Description |
| --- | --- |
| Subscription | Select your Azure subscription. |
| Resource group | Select Create new and provide a name for the resource group such as azure-sentinel-rg. |
| Region | From the dropdown menu, select the location where you want to deploy Microsoft Sentinel. |
| Workspace Name | Provide a unique name for the Microsoft Sentinel Workspace such as <yourName>-sentinel. |
| Location | Accept the default value of [resourceGroup().location]. |
| Simplevm Name | Accept the default value of simple-vm. |
| Simplevm Windows OS Version | Accept the default value of 2022-Datacenter. |

Select **Review + create**, and then select **Create**.


![Screenshot of the Custom Deployment page.](https://learn.microsoft.com/training/wwl-sci/query-data-sentinel/media/02-custom-deployment.png)

Wait for the deployment to complete. The deployment should take less than 5 minutes.


## Task 2: Check the resources created

1. In the Azure portal, search for Resource groups.
2. Select azure-sentinel-rg.
3. Sort the list of resources by Type.
4. The resource group should contain the resources listed in the following table.
 
		
			
		
		Expand table
	


Name
Type
Description




<yourName>-sentinel
Log Analytics workspace
Log Analytics workspace used by Microsoft Sentinel, with the workspace name that you chose in the previous task.


simple-vmNetworkInterface
Network Interface
Network interface for the virtual machine (VM).


SecurityInsights(<yourName>-sentinel)
Solution
Security insights for Microsoft Sentinel.


st1xxxxx
Storage account
Storage account used by the VM. The random string xxxxx creates a unique storage account name.


simple-vm
Virtual machine
Virtual machine used in the demonstration.


vnet1
Virtual network
Virtual network for the VM.

In the Azure portal, search for *Resource groups*.

Select **azure-sentinel-rg**.

Sort the list of resources by **Type**.

The resource group should contain the resources listed in the following table.

| Name | Type | Description |
| --- | --- | --- |
| <yourName>-sentinel | Log Analytics workspace | Log Analytics workspace used by Microsoft Sentinel, with the workspace name that you chose in the previous task. |
| simple-vmNetworkInterface | Network Interface | Network interface for the virtual machine (VM). |
| SecurityInsights(<yourName>-sentinel) | Solution | Security insights for Microsoft Sentinel. |
| st1xxxxx | Storage account | Storage account used by the VM. The random string xxxxx creates a unique storage account name. |
| simple-vm | Virtual machine | Virtual machine used in the demonstration. |
| vnet1 | Virtual network | Virtual network for the VM. |

The resources and configuration in this exercise are required in the next exercise. If you intend to complete the next exercise, don't delete these resources.


## Task 3: Configure Microsoft Sentinel connectors

In this task, you deploy a Microsoft Sentinel connector to Azure Activity.

1. In the Azure portal, search for and select Microsoft Sentinel. Select the Microsoft Sentinel workspace that you created in the previous task.
2. On the Microsoft Sentinel page, on the menu bar, under Configuration, select Data connectors.
3. In the Data connectors pane, search and select Azure Activity.
4. In the details pane, select Open connector page.
5. In the Azure Activity screen, under Instructions, verify your Prerequisites and then follow the Configuration steps.
6. When you receive a status of Connected, close all open panels to return to the Microsoft Sentinel | Data connector panel.

In the Azure portal, search for and select **Microsoft Sentinel**. Select the Microsoft Sentinel workspace that you created in the previous task.

On the **Microsoft Sentinel** page, on the menu bar, under **Configuration**, select **Data connectors**.

In the **Data connectors** pane, search and select **Azure Activity**.

In the details pane, select **Open connector page**.


![Screenshot of the Microsoft Sentinel Data connectors page.](https://learn.microsoft.com/training/wwl-sci/query-data-sentinel/media/02-azure-sentinel-connector.png)

In the **Azure Activity** screen, under **Instructions**, verify your **Prerequisites** and then follow the **Configuration** steps.

When you receive a status of **Connected**, close all open panels to return to the **Microsoft Sentinel | Data connector** panel.

The connector for Azure Activity could take 15 minutes to deploy. You can proceed with the rest of the steps in the exercise and with the subsequent units in this module.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/query-data-sentinel/2-exercise-setup/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/query-data-sentinel/2-exercise-setup/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel)*