---
title: Module assessment
learning_path: SC-200: Create detections and perform investigations using Microsoft Sentinel
module_number: 55
url: https://learn.microsoft.com/en-us/training/modules/manage-content-microsoft-sentinel/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel
type: quiz
crawled_at: 2025-11-25T19:26:45.091409
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "You can connect Microsoft Sentinel to which repositories?",
"options": [
"Azure DevOps only",
"GitHub only",
"GitHub and Azure DevOps"
],
"correct\_answers": [
"GitHub and Azure DevOps"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "Which content type is supported by content hub solutions?",
"options": [
"Advanced Multistage Attack Detection Fusion Rule",
"Parsers",
"Search job"
],
"correct\_answers": [
"Parsers"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "What is the maximum number of repository connections allowed for each Microsoft Sentinel workspace?",
"options": [
"Three",
"Five",
"Ten"
],
"correct\_answers": [
"Five"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/manage-content-microsoft-sentinel/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/manage-content-microsoft-sentinel/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel)*