---
title: Module assessment
learning_path: SC-200: Create detections and perform investigations using Microsoft Sentinel
module_number: 42
url: https://learn.microsoft.com/en-us/training/modules/data-normalization-microsoft-sentinel/7-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel
type: quiz
crawled_at: 2025-11-25T19:24:15.452513
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "When creating a Workspace transformation DCR. What is the name of the virtual table to query?",
"options": [
"source",
"input",
"target"
],
"correct\_answers": [
"source"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "What is an ASIM parser in KQL?",
"options": [
"Variable",
"Function",
"Aggregate"
],
"correct\_answers": [
"Function"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "Every schema that supports filtering parameters supports at least the parameter?",
"options": [
"createdon",
"ingestiontime",
"starttime"
],
"correct\_answers": [
"starttime"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/data-normalization-microsoft-sentinel/7-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/data-normalization-microsoft-sentinel/7-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel)*