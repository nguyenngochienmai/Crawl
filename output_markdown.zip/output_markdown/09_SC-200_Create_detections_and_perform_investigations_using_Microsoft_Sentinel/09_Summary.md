---
title: Summary
learning_path: SC-200: Create detections and perform investigations using Microsoft Sentinel
module_number: 9
url: https://learn.microsoft.com/en-us/training/modules/analyze-data-in-sentinel/9-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel
type: summary
crawled_at: 2025-11-25T19:18:12.557960
---

# Summary

> Provides a summary of threat detection with Microsoft Sentinel Analytics.

Contoso wanted to improve the efficiency of the investigation of the security incidents performed by their SecOps team.

The SecOps team was spending significant time investigating the high volume of alerts they were receiving from the various products and services used by Contoso.

By using Microsoft Sentinel Analytics, the SecOps team was able to detect and analyze potential threats more effectively. They could create analytics rules that would trigger alerts.  The SecOps team was then able to effectively react to the threats based on the triggered alerts.

Without the help of Microsoft Sentinel Analytics, earlier the SecOps team wasn't able to use its time effectively on its other operations because it was spending time in manually correlating the threats and analyzing them.

In this module, you learned how Microsoft Sentinel Analytics can help SecOps to identify and stop cyberattacks.


## Learn more

You can learn more by reviewing the following documents.


### Getting started

- Microsoft Sentinel documentation
- Quickstart: On-board Microsoft Sentinel
- Microsoft Sentinel pricing
- Permissions in Microsoft Sentinel
- Tutorial: Visualize and monitor your data
- Quickstart: Get started with Microsoft Sentinel
- What is Azure Lighthouse?
- Extend Microsoft Sentinel across workspaces and tenants
- What is Azure Resource Manager?
- Azure Foundation 4-Week Implementation


### Microsoft Sentinel agent

- Tutorial: Detect threats out-of-the-box
- Connect data sources


---

*Source: [https://learn.microsoft.com/en-us/training/modules/analyze-data-in-sentinel/9-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/analyze-data-in-sentinel/9-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel)*