---
title: Create an analytics rule from templates
learning_path: SC-200: Create detections and perform investigations using Microsoft Sentinel
module_number: 5
url: https://learn.microsoft.com/en-us/training/modules/analyze-data-in-sentinel/5-create-rule-from-templates/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel
type: content
crawled_at: 2025-11-25T19:17:35.692643
---

# Create an analytics rule from templates

> Describes the procedure to create an analytics rule from templates.

The Analytics section in Microsoft Sentinel contains rule templates that are preloaded from the Microsoft Sentinel GitHub repository. You can use these templates to create a rule to detect security threats.


## Exploring the existing rule templates

You can use some of the existing rule templates to create a single rule and others to create multiple rules with different customization options. Templates in use display the **IN USE** label on the template page as displayed in the following screenshot.


![Screenshot of the template in use.](https://learn.microsoft.com/training/wwl-sci/analyze-data-in-sentinel/media/04-template-in-use.png)

By selecting one of the rules on the **Rule Templates** tab, you can observe the properties of the rule. For each rule, you can review:

**Severity level.** This indicates the importance of the alert. There are four severity levels:

- High
- Medium
- Low
- Informational

**Name of the rule.** This provides a meaningful name for the alert rule.

**Rule type.** This defines the type of the rule, which can be one of the following types:

- Anomaly
- Fusion
- Microsoft Security
- ML Behavior Analytics
- Scheduled
- NRT (Near Real Time)

**Data Source.** This specifies the data source connector that generated the alert.

**Tactics.** This specifies methodologies in MITRE ATT&amp;CK model used by different kinds of malware.

MITRE ATT&amp;CK is a globally accessible knowledge base of adversary tactics and techniques based on real-world observations. The ATT&amp;CK knowledge base provides a foundation for the development of specific threat models and methodologies in the private sector, in government, and in the cybersecurity product and service community.

When you select a rule from the list on either the Active rules tab or the Rule templates tab, the details pane provides more information for the selected rule.


## Creating an analytic rule from a rule template

When you select a predefined rule template, the details pane
may display filters that can be used to define how that rule behaves. For Fusion and ML behavior analytics rules, Microsoft doesn't provide any editable information. However, for scheduled rules and Microsoft Security, you can view or edit the query, filters, and includes and excludes used in the threat detection. By selecting the **Create rule** button, you can define the   analytics rule logic using a wizard that helps you customize a rule from the selected template.

For Fusion and ML behavior analytics templates, you can only enable or disable them as active rules.

A rule that you create from a Microsoft security template consists of the following elements:


## General tab

The following table lists the inputs on the **General** tab.

| Field | Description |
| --- | --- |
| Name | This is prepopulated from the name of the rule template. |
| Description | Provide more details about the creation of the alerts. |
| Status | This indicates whether the analytics rule is enabled or disabled. |
| Microsoft security service | This indicates the source of the alert from one of the Microsoft security services. |
| Filter by severity | Use to tune alerts from a source based on the severity level; if you select custom, you can specify High, Medium, Low, or Informational. |
| Include specific alerts | Add one or more words to include results of alerts that contain specific text in their name. |
| Exclude specific alerts | Add one or more words to exclude results of alerts that contain specific text in their name. |


## Automated response

On the **Automated response** tab, you can define automation rules. If you select **Add new**, the **Create new automation rule** pane opens. The following fields are inputs:

| Field | Description |
| --- | --- |
| Automation rule name | Choose a name that uniquely describes this automation rule |
| Trigger | Predefined value that can't be changed. |
| Conditions | Typical query filter construct that can be edited and sorted. |
| Actions | Selection list of actions; select which action you want to be performed if the query filter conditions are met. |
| Rule expiration | Date and time for rule to be disabled. Default is indefinite. |
| Order | If multiple rules are created, select sequential numbers to reorder the incident automation rules in the left pane. |

When you implement filters to include or exclude specific alerts based on a text string, these alerts will not appear in Microsoft Sentinel.

The following screenshot presents an example of creating an incident from alerts generated by the Microsoft Defender for Cloud.


![Screenshot of the wizard used to create analytics rules from templates.](https://learn.microsoft.com/training/wwl-sci/analyze-data-in-sentinel/media/04-create-analytics-rule.png)

For instructions on how to create an analytics rule from a scheduled rule type template, see **Create an analytics rule from a scheduled rule template** in next unit (Unit 6).

For certain rule templates, the **Create rule** button might be disabled, which indicates that you can't create a rule from selected template because of a missing data source.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/analyze-data-in-sentinel/5-create-rule-from-templates/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/analyze-data-in-sentinel/5-create-rule-from-templates/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel)*