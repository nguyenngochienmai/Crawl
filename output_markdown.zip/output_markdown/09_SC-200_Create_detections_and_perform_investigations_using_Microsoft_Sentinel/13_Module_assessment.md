---
title: Module assessment
learning_path: SC-200: Create detections and perform investigations using Microsoft Sentinel
module_number: 13
url: https://learn.microsoft.com/en-us/training/modules/automation-microsoft-sentinel/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel
type: quiz
crawled_at: 2025-11-25T19:18:46.812891
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "Automation rules are triggered by?",
"options": [
"Incidents",
"Connectors",
"Watchlists"
],
"correct\_answers": [
"Incidents"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "You use a Logic Apps to create a\_?",
"options": [
"Automation rule",
"Playbook",
"Workbook"
],
"correct\_answers": [
"Playbook"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "An Automation rule action can?",
"options": [
"Update the incident title",
"Delete the incident",
"Change the incident status"
],
"correct\_answers": [
"Change the incident status"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/automation-microsoft-sentinel/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/automation-microsoft-sentinel/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel)*