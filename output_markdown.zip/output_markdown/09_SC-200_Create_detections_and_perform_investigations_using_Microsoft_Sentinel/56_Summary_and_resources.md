---
title: Summary and resources
learning_path: SC-200: Create detections and perform investigations using Microsoft Sentinel
module_number: 56
url: https://learn.microsoft.com/en-us/training/modules/manage-content-microsoft-sentinel/5-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel
type: summary
crawled_at: 2025-11-25T19:28:57.275062
---

# Summary and resources

> Summary and resources

By the end of this module, you're able to manage *content* in Microsoft Sentinel.

You should now be able to:

- Install a content hub solution in Microsoft Sentinel
- Connect a GitHub repository to Microsoft Sentinel


## Learn more

You can learn more by reviewing the following.

[Become a Microsoft Sentinel Ninja](https://techcommunity.microsoft.com/t5/azure-sentinel/become-an-azure-sentinel-ninja-the-complete-level-400-training/ba-p/1246310" data-linktype="external" target="az-portal" class="has-external-link-indicator)

[Microsoft Tech Community Security Webinars](https://techcommunity.microsoft.com/t5/microsoft-security-and/security-community-webinars/ba-p/927888" data-linktype="external" target="az-portal" class="has-external-link-indicator)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/manage-content-microsoft-sentinel/5-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/manage-content-microsoft-sentinel/5-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel)*