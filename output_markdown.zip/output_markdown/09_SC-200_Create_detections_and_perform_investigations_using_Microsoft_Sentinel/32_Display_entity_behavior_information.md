---
title: Display entity behavior information
learning_path: SC-200: Create detections and perform investigations using Microsoft Sentinel
module_number: 32
url: https://learn.microsoft.com/en-us/training/modules/use-entity-behavior-analytics-azure-sentinel/4-display-entity-behavior-information/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel
type: content
crawled_at: 2025-11-25T19:22:14.106318
---

# Display entity behavior information

> Display entity behavior information

The Entity behavior page allows you to search for entities or select from the list of already displayed entities.  Once selected the Entity page is displayed with information and timeline of alerts and activities

The Incident Investigation Graph includes an option for **Insights**.  Insights display information from the Entity behavior data.


### How to use entity pages

Entity pages are designed to be part of multiple usage scenarios, and can be accessed from incident management, the investigation graph, bookmarks, or directly from the entity search page under **Entity behavior analytics** in the Microsoft Sentinel main menu.


![Diagram of connections to the Entity Page.](https://learn.microsoft.com/training/wwl-sci/use-entity-behavior-analytics-azure-sentinel/media/entity-behavior-5.png)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/use-entity-behavior-analytics-azure-sentinel/4-display-entity-behavior-information/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/use-entity-behavior-analytics-azure-sentinel/4-display-entity-behavior-information/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel)*