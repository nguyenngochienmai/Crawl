---
title: Summary
learning_path: SC-200: Create detections and perform investigations using Microsoft Sentinel
module_number: 28
url: https://learn.microsoft.com/en-us/training/modules/incident-management-sentinel/7-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel
type: summary
crawled_at: 2025-11-25T19:21:37.406208
---

# Summary

> Summary for incident management in Microsoft Sentinel

In this module, you learned about using Microsoft Sentinel to detect and investigate security threats in your Microsoft Azure environment. You also practiced using rules and alerts to investigate and identify anomalies in Contoso's Azure Activity log, and how to use Kusto Query Language (KQL) to summarize and visualize data, which is essential for creating custom analytics rules and workbooks in Microsoft Sentinel. And, you learned how to investigate consolidated incidents in the Microsoft Defender portal.

You can now lead the IT team in helping Contoso protect its security environment by managing incidents with Microsoft Sentinel. Ongoing activities might include creating custom analytics rules, using playbooks for automated responses, and using workbooks to provide dashboards and visualizations.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/incident-management-sentinel/7-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/incident-management-sentinel/7-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel)*