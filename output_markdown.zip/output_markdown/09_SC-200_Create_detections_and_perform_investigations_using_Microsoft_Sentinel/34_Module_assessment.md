---
title: Module assessment
learning_path: SC-200: Create detections and perform investigations using Microsoft Sentinel
module_number: 34
url: https://learn.microsoft.com/en-us/training/modules/use-entity-behavior-analytics-azure-sentinel/5-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel
type: quiz
crawled_at: 2025-11-25T19:22:30.958266
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "What are Entities?",
"options": [
"Data elements",
"Tables",
"Alerts"
],
"correct\_answers": [
"Data elements"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "In the timeline of the Entity page, what type of items are an aggregation of notable events relating to the entity?",
"options": [
"Alerts",
"Activities",
"Bookmarks"
],
"correct\_answers": [
"Activities"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "When you're viewing the investigation graph, what option will show Entity Behavior information?",
"options": [
"Entities",
"Timeline",
"Insights"
],
"correct\_answers": [
"Insights"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/use-entity-behavior-analytics-azure-sentinel/5-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/use-entity-behavior-analytics-azure-sentinel/5-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel)*