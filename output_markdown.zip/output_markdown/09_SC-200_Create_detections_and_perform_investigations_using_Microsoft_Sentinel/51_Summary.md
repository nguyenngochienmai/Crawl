---
title: Summary
learning_path: SC-200: Create detections and perform investigations using Microsoft Sentinel
module_number: 51
url: https://learn.microsoft.com/en-us/training/modules/query-data-sentinel/8-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel
type: summary
crawled_at: 2025-11-25T19:26:13.690193
---

# Summary

> Provide a summary of the module.

The Contoso SecOps team recently encountered issues when users with compromised accounts tried to access Contoso's customer data. Microsoft Sentinel provides several monitoring and reporting features that help alert Contoso about potential security threats.

Microsoft Sentinel workbooks provide interactive reports with graphs, charts, and tables, and security administrators can use these features to visualize their security data by using advanced filtering. The SecOps team can use these techniques to gain more insights into their data during their investigations.


## Learn more

You can learn more by reviewing the following documents.


### Getting started

- Microsoft Sentinel documentation
- Quickstart: On-board Microsoft Sentinel
- Microsoft Sentinel pricing
- Permissions in Microsoft Sentinel
- Tutorial: Visualize and monitor your data
- Quickstart: Get started with Microsoft Sentinel
- What is Azure Lighthouse?
- Extend Microsoft Sentinel across workspaces and tenants
- What is Azure Resource Manager?
- Azure Foundation 4-Week Implementation


### Microsoft Sentinel agent

- Tutorial: Detect threats out-of-the-box
- Connect data sources


---

*Source: [https://learn.microsoft.com/en-us/training/modules/query-data-sentinel/8-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/query-data-sentinel/8-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel)*