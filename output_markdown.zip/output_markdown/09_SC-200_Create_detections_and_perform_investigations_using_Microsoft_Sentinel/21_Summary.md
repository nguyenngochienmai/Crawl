---
title: Summary
learning_path: SC-200: Create detections and perform investigations using Microsoft Sentinel
module_number: 21
url: https://learn.microsoft.com/en-us/training/modules/threat-response-sentinel-playbooks/7-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel
type: summary
crawled_at: 2025-11-25T19:20:34.544154
---

# Summary

> Describes how to set up automated response on threats using Microsoft Sentinel Playbooks.


## Resolution of module problem

Contoso SecOps wanted to improve their response time to security incidents and prevent future incidents. Contoso decides to use Microsoft Sentinel playbooks, which are based on Logic Apps with a Microsoft Sentinel connector to provide near real-time responses.
In this module, you learned how to create Sentinel playbooks that can respond in real time on a security thread. You also learned how to start a playbook on demand as response to investigation on a security alert.


## Learn more

You can learn more by reviewing the following documents.


### Getting started

- Microsoft Sentinel documentation
- Quickstart: On-board Microsoft Sentinel
- Microsoft Sentinel pricing
- Permissions in Microsoft Sentinel
- Tutorial: Visualize and monitor your data
- Quickstart: Get started with Microsoft Sentinel
- What is Azure Lighthouse?
- Extend Microsoft Sentinel across workspaces and tenants
- What is Azure Resource Manager?
- Azure Foundation 4-Week Implementation


### Microsoft Sentinel agent

- Tutorial: Detect threats out-of-the-box
- Connect data sources


---

*Source: [https://learn.microsoft.com/en-us/training/modules/threat-response-sentinel-playbooks/7-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/threat-response-sentinel-playbooks/7-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel)*