---
title: Exercise - Detect threats with Microsoft Sentinel analytics
learning_path: SC-200: Create detections and perform investigations using Microsoft Sentinel
module_number: 2
url: https://learn.microsoft.com/en-us/training/modules/analyze-data-in-sentinel/2-exercise-setup/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel
type: exercise
crawled_at: 2025-11-25T19:17:07.499089
---

# Exercise - Detect threats with Microsoft Sentinel analytics

> Detect threats by using Microsoft Sentinel Analytics.

The Threat detection with Microsoft Sentinel Analytics exercise in this module is an optional unit. However, if you want to perform this exercise, you need access to an Azure subscription where you can create Azure resources. If you don't have an Azure subscription, create a [free account](https://azure.microsoft.com/pricing/purchase-options/azure-account?cid=msft_learn" data-linktype="external) before you begin.

To deploy the prerequisites for the exercise, perform the following tasks.

If you choose to perform the exercise in this module, be aware you might incur costs in your Azure Subscription. To estimate the cost, refer to [Microsoft Sentinel Pricing](https://azure.microsoft.com/pricing/details/azure-sentinel/" data-linktype="external).


## Task 1: Deploy Microsoft Sentinel using ARM template

1. Select the following link:

You're prompted to sign in to Azure. The Custom deployment pane appears.
2. On the Basics tab, enter the following values for each setting.
 
		
			
		
		Expand table
	


Setting
Value




Project details



Subscription
Select your Azure subscription.


Resource group
Select Create new, and provide a name for the resource group, such as azure-sentinel-rg.


Instance details



Region
From the dropdown list, select the location where you want to deploy the Microsoft Sentinel.


Workspace Name
Provide a unique name for the Microsoft Sentinel Workspace such as <yourName>-sentinel, where <yourName> represents the workspace name that you chose in the previous task.


Location
Accept the default value of [resourceGroup().location].


Simplevm Name
Accept the default value of simple-vm.


Simplevm Windows OS Version
Accept the default value of 2022-Datacenter.
3. Select the Review + create. When validation passes, select Create.





 Note
Wait for the deployment to complete. The deployment should take less than five minutes.

Select the following link:


![Deploy To Azure.](https://aka.ms/deploytoazurebutton)

You're prompted to sign in to Azure. The **Custom deployment** pane appears.

On the **Basics** tab, enter the following values for each setting.

| Setting | Value |
| --- | --- |
| Project details |  |
| Subscription | Select your Azure subscription. |
| Resource group | Select Create new, and provide a name for the resource group, such as azure-sentinel-rg. |
| Instance details |  |
| Region | From the dropdown list, select the location where you want to deploy the Microsoft Sentinel. |
| Workspace Name | Provide a unique name for the Microsoft Sentinel Workspace such as <yourName>-sentinel, where <yourName> represents the workspace name that you chose in the previous task. |
| Location | Accept the default value of [resourceGroup().location]. |
| Simplevm Name | Accept the default value of simple-vm. |
| Simplevm Windows OS Version | Accept the default value of 2022-Datacenter. |

Select the **Review + create**. When validation passes, select **Create**.


![Screenshot of the Custom Deployment page.](https://learn.microsoft.com/training/wwl-sci/analyze-data-in-sentinel/media/02-custom-deployment.png)

Wait for the deployment to complete. The deployment should take less than five minutes.


## Task 2: Check the resources created

1. In the Azure portal, search for Resource groups.
2. Select azure-sentinel-rg.
3. Sort the list of resources by Type.
The resource group should contain the resources listed in the following table.
 
		
			
		
		Expand table
	


Name
Type
Description




<yourName>-sentinel
Log Analytics workspace
Log Analytics workspace used by Microsoft Sentinel, where <yourName> represents the workspace name that you chose in the previous task.


simple-vmNetworkInterface
Network interface
Network interface for the VM.


SecurityInsights(<yourName>-sentinel)
Solution
Security insights for Microsoft Sentinel.


simple-vm
Virtual machine
Virtual machine (VM) used in the demonstration.


st1<xxxxx>
Storage account
Storage account used by the VM, where <xxxxx> represents a random string generated to create a unique storage account name.


vnet1
Virtual network
Virtual network for the VM.

In the Azure portal, search for **Resource groups**.

Select **azure-sentinel-rg**.

Sort the list of resources by **Type**.

The resource group should contain the resources listed in the following table.

| Name | Type | Description |
| --- | --- | --- |
| <yourName>-sentinel | Log Analytics workspace | Log Analytics workspace used by Microsoft Sentinel, where <yourName> represents the workspace name that you chose in the previous task. |
| simple-vmNetworkInterface | Network interface | Network interface for the VM. |
| SecurityInsights(<yourName>-sentinel) | Solution | Security insights for Microsoft Sentinel. |
| simple-vm | Virtual machine | Virtual machine (VM) used in the demonstration. |
| st1<xxxxx> | Storage account | Storage account used by the VM, where <xxxxx> represents a random string generated to create a unique storage account name. |
| vnet1 | Virtual network | Virtual network for the VM. |

The resources deployed and configuration steps completed in this exercise are required in the next exercise. If you intended to complete the next exercise, don't delete the resources from this exercise.


## Task 3: Configure Microsoft Sentinel Data connectors

In this task, you deploy a Microsoft Sentinel Data connector to detect Azure Activity.

1. In the Azure portal, select Home, and then search for and select Microsoft Sentinel.
2. In the list of Sentinel workspace names, select the Microsoft Sentinel workspace you created in Task 2. The Overview pane for your Sentinel workspace appears.
3. In the menu pane, under Content management, select Content hub. The Content hub pane appears.
4. In the Search box, search for and select the Azure Activity Solution. On the Azure Activity details pane, select Install.
5. Wait for the install to complete and then select Manage.
6. In the Search box, search for and select the Azure Activity Data connector.
7. On the Azure Activity details pane, select Open connector page.
8. In the Instructions tab, Configuration area, scroll down and under "2. Connect your subscriptions..." select Launch Azure Policy Assignment Wizard>.
9. In the Basics tab, select the ellipsis button (...) under Scope and select your "Azure subscription" from the drop-down list and select Select.
10. Select the Parameters tab, choose your yourName-sentinel workspace from the Primary Log Analytics workspace drop-down list.
11. Select the Remediation tab and select the Create a remediation task checkbox. This action applies the subscription configuration to send the information to the Log Analytics workspace.

 Note
To apply the policy to your existing resources, you need to create a remediation task.
12. Select the Review + Create button to review the configuration.
13. Select Create to finish.
14. Once the deployment is complete, you see the Connected status (green bar) for the Azure Activity connector in the Configuration/Data connectors pane.

In the Azure portal, select **Home**, and then search for and select **Microsoft Sentinel**.

In the list of Sentinel workspace names, select the Microsoft Sentinel workspace you created in Task 2. The **Overview** pane for your Sentinel workspace appears.

In the menu pane, under **Content management**, select **Content hub**. The **Content hub** pane appears.

In the *Search* box, search for and select the **Azure Activity** Solution. On the **Azure Activity** details pane, select **Install**.

Wait for the install to complete and then select **Manage**.

In the *Search* box, search for and select the **Azure Activity** Data connector.

On the **Azure Activity** details pane, select **Open connector page**.

In the *Instructions* tab, *Configuration* area, scroll down and under "2. Connect your subscriptions..." select **Launch Azure Policy Assignment Wizard&gt;**.

In the **Basics** tab, select the ellipsis button (...) under **Scope** and select your "Azure subscription" from the drop-down list and select **Select**.

Select the **Parameters** tab, choose your *yourName-sentinel* workspace from the **Primary Log Analytics workspace** drop-down list.

Select the **Remediation** tab and select the **Create a remediation task** checkbox. This action applies the subscription configuration to send the information to the Log Analytics workspace.

To apply the policy to your existing resources, you need to create a remediation task.

Select the **Review + Create** button to review the configuration.

Select **Create** to finish.

Once the deployment is complete, you see the **Connected** status (green bar) for the Azure Activity connector in the *Configuration/Data connectors* pane.


![Screenshot of the Microsoft Sentinel connector](https://learn.microsoft.com/training/wwl-sci/analyze-data-in-sentinel/media/07-azure-sentinel-connector.png)

The connector for Azure Activity could take 15 minutes to show **Connected** in Microsoft Sentinel. You can proceed with rest of the steps and with other units of this module.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/analyze-data-in-sentinel/2-exercise-setup/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/analyze-data-in-sentinel/2-exercise-setup/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-create-detections-perform-investigations-azure-sentinel)*