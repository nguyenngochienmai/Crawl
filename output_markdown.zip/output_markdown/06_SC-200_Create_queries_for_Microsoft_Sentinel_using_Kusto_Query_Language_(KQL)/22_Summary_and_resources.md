---
title: Summary and resources
learning_path: SC-200: Create queries for Microsoft Sentinel using Kusto Query Language (KQL)
module_number: 22
url: https://learn.microsoft.com/en-us/training/modules/build-multi-table-statements-kusto-query-language/5-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel
type: summary
crawled_at: 2025-11-25T18:39:21.295338
---

# Summary and resources

> Summary and resources

You should have learned how Kusto Query Language (KQL) is the query language used to perform analysis on data to create Analytics, Workbooks, and perform Hunting in Microsoft Sentinel.  Understanding how to correlate data from different tables with a KQL statement provides the foundation to build detections in Microsoft Sentinel.

You should now be able to:

- Create queries using unions to view results across multiple tables using KQL
- Merge two tables with the join operator using KQL

Create queries using unions to view results across multiple tables using KQL

Merge two tables with the join operator using KQL


## Learn more

You can learn more by reviewing the following.

[KQL quick reference](https://learn.microsoft.com/en-us/azure/data-explorer/kql-quick-reference" data-linktype="absolute-path" target="az-portal" class="has-external-link-indicator)

[Microsoft Tech Community Security Webinars](https://techcommunity.microsoft.com/t5/microsoft-security-and/security-community-webinars/ba-p/927888" data-linktype="external" target="az-portal" class="has-external-link-indicator)

[Become a Microsoft Sentinel Ninja](https://techcommunity.microsoft.com/t5/azure-sentinel/become-an-azure-sentinel-ninja-the-complete-level-400-training/ba-p/1246310" data-linktype="external" target="az-portal" class="has-external-link-indicator)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/build-multi-table-statements-kusto-query-language/5-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/build-multi-table-statements-kusto-query-language/5-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel)*