---
title: Module assessment
learning_path: SC-200: Create queries for Microsoft Sentinel using Kusto Query Language (KQL)
module_number: 21
url: https://learn.microsoft.com/en-us/training/modules/build-multi-table-statements-kusto-query-language/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel
type: quiz
crawled_at: 2025-11-25T18:38:06.133933
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "Which join flavor contains a row in the output for every combination of matching rows from left and right?",
"options": [
"kind=leftouter",
"kind=inner",
"kind=fullouter"
],
"correct\_answers": [
"kind=inner"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "When you're using the join operator, how do you specify fields from each table?",
"options": [
"$1.columname and $2.columnname",
"$left.columname and $right.columnname",
"$inner.columname and $outer.columnname"
],
"correct\_answers": [
"$left.columname and $right.columnname"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "When you use union on two tables, do the two tables need matching columns?",
"options": [
"No.",
"Yes.",
"Only when the project operator is used."
],
"correct\_answers": [
"No."
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/build-multi-table-statements-kusto-query-language/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/build-multi-table-statements-kusto-query-language/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel)*