---
title: Create parsers with functions
learning_path: SC-200: Create queries for Microsoft Sentinel using Kusto Query Language (KQL)
module_number: 27
url: https://learn.microsoft.com/en-us/training/modules/work-with-data-kusto-query-language/5-create-parsers-functions/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel
type: content
crawled_at: 2025-11-25T18:40:02.771443
---

# Create parsers with functions

> Create parsers with functions

Parsers are functions that define a virtual table with already parsed unstructured strings fields such as Syslog data.

In the Logs window, you create a query, select the Save button, enter the Name, and select Save As Function from the drop-down. In this case, if we name the function "PrivLogins", I can then access the table using the name PrivLogins.


```text
SecurityEvent
| where EventID == 4672 and AccountType == 'User'
```


```text
PrivLogins
```


---

*Source: [https://learn.microsoft.com/en-us/training/modules/work-with-data-kusto-query-language/5-create-parsers-functions/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/work-with-data-kusto-query-language/5-create-parsers-functions/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel)*