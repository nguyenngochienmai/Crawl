---
title: Use the where operator
learning_path: SC-200: Create queries for Microsoft Sentinel using Kusto Query Language (KQL)
module_number: 4
url: https://learn.microsoft.com/en-us/training/modules/construct-kusto-query-language-statements/4-use-where-operator/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel
type: content
crawled_at: 2025-11-25T18:35:42.169127
---

# Use the where operator

> Use the where operator

The where operator filters a table to the subset of rows that satisfy a predicate.

Try each of these queries separately to see the results.


```text
SecurityEvent
| where TimeGenerated > ago(1d)

SecurityEvent
| where TimeGenerated > ago(1h) and EventID == "4624"

SecurityEvent
| where TimeGenerated > ago(1h)
| where EventID == 4624
| where AccountType =~ "user"

SecurityEvent | where EventID in (4624, 4625)
```


---

*Source: [https://learn.microsoft.com/en-us/training/modules/construct-kusto-query-language-statements/4-use-where-operator/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/construct-kusto-query-language-statements/4-use-where-operator/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel)*