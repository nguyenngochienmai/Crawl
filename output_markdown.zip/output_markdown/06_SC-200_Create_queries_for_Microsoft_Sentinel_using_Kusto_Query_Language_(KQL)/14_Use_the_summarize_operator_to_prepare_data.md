---
title: Use the summarize operator to prepare data
learning_path: SC-200: Create queries for Microsoft Sentinel using Kusto Query Language (KQL)
module_number: 14
url: https://learn.microsoft.com/en-us/training/modules/analyze-results-kusto-query-language/4-use-summarize-operator-to-prepare-data/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel
type: content
crawled_at: 2025-11-25T18:37:11.811257
---

# Use the summarize operator to prepare data

> Use the summarize operator to prepare data

The make_ functions return a dynamic (JSON) array based on the specific function's purpose.


## make_list() function

The function returns a dynamic (JSON) array of all the values of Expression in the group.

This KQL query will first filter the EventID with the where operator.  Next, for each Computer, the results are a JSON array of Accounts. The resulting JSON array will include duplicate accounts.


```text
SecurityEvent
| where EventID == "4624"
| summarize make_list(Account) by Computer
```


![Screenshot of a make_list function results.](https://learn.microsoft.com/training/wwl-sci/analyze-results-kusto-query-language/media/make-list-results.png)


## make_set() function

Returns a dynamic (JSON) array containing distinct values that Expression takes in the group.

This KQL query will first filter the EventID with the where operator.  Next, for each Computer, the results are a JSON array of unique Accounts.


```text
SecurityEvent
| where EventID == "4624"
| summarize make_set(Account) by Computer
```


![Screenshot of a Make_set function results.](https://learn.microsoft.com/training/wwl-sci/analyze-results-kusto-query-language/media/make-set-results.png)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/analyze-results-kusto-query-language/4-use-summarize-operator-to-prepare-data/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/analyze-results-kusto-query-language/4-use-summarize-operator-to-prepare-data/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel)*