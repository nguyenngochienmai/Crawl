---
title: Module assessment
learning_path: SC-200: Create queries for Microsoft Sentinel using Kusto Query Language (KQL)
module_number: 16
url: https://learn.microsoft.com/en-us/training/modules/analyze-results-kusto-query-language/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel
type: quiz
crawled_at: 2025-11-25T18:37:27.455653
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/analyze-results-kusto-query-language/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/analyze-results-kusto-query-language/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel)*