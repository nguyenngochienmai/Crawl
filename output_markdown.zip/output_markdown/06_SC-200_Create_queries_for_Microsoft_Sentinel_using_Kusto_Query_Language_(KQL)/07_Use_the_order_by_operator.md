---
title: Use the order by operator
learning_path: SC-200: Create queries for Microsoft Sentinel using Kusto Query Language (KQL)
module_number: 7
url: https://learn.microsoft.com/en-us/training/modules/construct-kusto-query-language-statements/7-use-order-by-operator/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel
type: content
crawled_at: 2025-11-25T18:36:04.588232
---

# Use the order by operator

> Use the order by operator

Sort the rows of the input table by one or more columns.

The order by operator can utilize any column or multiple columns by using a comma separator.  Each column can be ascending or descending. The default order for a column is descending.


```text
SecurityEvent
| where ProcessName != "" and Process != ""
| extend StartDir =  substring(ProcessName,0, string_size(ProcessName)-string_size(Process))
| order by StartDir desc, Process asc
```


---

*Source: [https://learn.microsoft.com/en-us/training/modules/construct-kusto-query-language-statements/7-use-order-by-operator/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/construct-kusto-query-language-statements/7-use-order-by-operator/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel)*