---
title: Module assessment
learning_path: SC-200: Create queries for Microsoft Sentinel using Kusto Query Language (KQL)
module_number: 28
url: https://learn.microsoft.com/en-us/training/modules/work-with-data-kusto-query-language/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel
type: quiz
crawled_at: 2025-11-25T18:40:09.882150
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "Which KQL statement should you use to parse external data into a virtual table?",
"options": [
"parse\_json",
"extract",
"externaldata"
],
"correct\_answers": [
"externaldata"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "A Dynamic field contains which of the following items?",
"options": [
"Calculated data.",
"Key-value pair data.",
"External data."
],
"correct\_answers": [
"Key-value pair data."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "To create a virtual table, save your KQL as a which type?",
"options": [
"Module.",
"Function.",
"Definition."
],
"correct\_answers": [
"Function."
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/work-with-data-kusto-query-language/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/work-with-data-kusto-query-language/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel)*