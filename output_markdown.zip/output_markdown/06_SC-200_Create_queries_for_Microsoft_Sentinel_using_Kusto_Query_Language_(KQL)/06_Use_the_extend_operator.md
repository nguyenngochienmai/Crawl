---
title: Use the extend operator
learning_path: SC-200: Create queries for Microsoft Sentinel using Kusto Query Language (KQL)
module_number: 6
url: https://learn.microsoft.com/en-us/training/modules/construct-kusto-query-language-statements/6-use-extend-operator/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel
type: content
crawled_at: 2025-11-25T18:35:56.306041
---

# Use the extend operator

> Use the extend operator

The extend operator will create calculated columns and append the new columns to the result set.

The KQL example below uses the extend operator to create a new column, StartDir containing the directory a process was started in. The StartDir column is a calculated column containing the results of a substring function.


```text
SecurityEvent
| where ProcessName != "" and Process != ""
| extend StartDir =  substring(ProcessName,0, string_size(ProcessName)-string_size(Process))
```


---

*Source: [https://learn.microsoft.com/en-us/training/modules/construct-kusto-query-language-statements/6-use-extend-operator/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/construct-kusto-query-language-statements/6-use-extend-operator/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel)*