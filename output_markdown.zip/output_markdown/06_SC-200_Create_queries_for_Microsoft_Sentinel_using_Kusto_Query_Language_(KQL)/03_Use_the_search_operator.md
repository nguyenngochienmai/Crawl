---
title: Use the search operator
learning_path: SC-200: Create queries for Microsoft Sentinel using Kusto Query Language (KQL)
module_number: 3
url: https://learn.microsoft.com/en-us/training/modules/construct-kusto-query-language-statements/3-use-search-operator/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel
type: content
crawled_at: 2025-11-25T18:35:35.216938
---

# Use the search operator

> Use the search operator

The search operator provides a multi-table/multi-column search experience. Although the search operator is easy to use, when  compared to the where operator it's inefficient.  Even with this inefficiency, you can use search to find data when unsure which table or column to filter.

The first statement will search for "err" across all tables. The second statement will search for "err" in tables SecurityEvent, SecurityAlert, and tables starting with A.

Try each of these queries separately to see the results.

For the first search query, you may need to adjust the Time range to "Last hour" in the query window to avoid an error.


```text
search "err"

search in (SecurityEvent,SecurityAlert,A*) "err"
```


---

*Source: [https://learn.microsoft.com/en-us/training/modules/construct-kusto-query-language-statements/3-use-search-operator/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/construct-kusto-query-language-statements/3-use-search-operator/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel)*