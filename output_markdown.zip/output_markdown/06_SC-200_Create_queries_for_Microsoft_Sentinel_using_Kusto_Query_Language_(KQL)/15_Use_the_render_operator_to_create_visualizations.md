---
title: Use the render operator to create visualizations
learning_path: SC-200: Create queries for Microsoft Sentinel using Kusto Query Language (KQL)
module_number: 15
url: https://learn.microsoft.com/en-us/training/modules/analyze-results-kusto-query-language/5-use-render-operator-to-create-visualizations/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel
type: content
crawled_at: 2025-11-25T18:37:20.199108
---

# Use the render operator to create visualizations

> Use the render operator to create visualizations

The render operator generates a visualization of the query results.

The supported visualizations are:

- areachart
- barchart
- columnchart
- piechart
- scatterchart
- timechart


```text
SecurityEvent 
| summarize count() by Account
| render barchart
```


## Use the summarize operator to create time series

The bin() function rounds values down to an integer multiple of the given bin size.  Used frequently in combination with summarize by .... If you have a scattered set of values, the values are grouped into a smaller set of specific values.  Combining the generated time series and pipe to a render operator with a type of timechart provides a time-series visualization.


```text
SecurityEvent 
| summarize count() by bin(TimeGenerated, 1d) 
| render timechart
```


---

*Source: [https://learn.microsoft.com/en-us/training/modules/analyze-results-kusto-query-language/5-use-render-operator-to-create-visualizations/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/analyze-results-kusto-query-language/5-use-render-operator-to-create-visualizations/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel)*