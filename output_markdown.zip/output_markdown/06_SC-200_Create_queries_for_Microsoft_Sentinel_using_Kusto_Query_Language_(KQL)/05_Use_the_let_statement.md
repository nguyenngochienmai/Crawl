---
title: Use the let statement
learning_path: SC-200: Create queries for Microsoft Sentinel using Kusto Query Language (KQL)
module_number: 5
url: https://learn.microsoft.com/en-us/training/modules/construct-kusto-query-language-statements/5-use-let-statement/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel
type: content
crawled_at: 2025-11-25T18:35:49.193776
---

# Use the let statement

> Use the let statement

Let statements bind names to expressions. For the rest of the scope, where the let statement appear, the name refers to its bound value. Let statements improve modularity and reuse since they allow you to break a potentially complex expression into multiple parts. Each part is bound to a name through the let statement, and together they compose the whole. Let statements allow for the creation of user-defined functions and views. The views are expressions whose results look like a new table.


## Declare and reuse variables

Let statements allow for the creation of variables to be used in later statements. In this example, timeOffSet and discardEventId are created and used as part of the SecurityEvent "where" clause.

You may need to increase the timeOffset and time ranges to see results in the [Logs Demo site](https://aka.ms/lademo" data-linktype="external) environment. We suggest using &gt; 30 days if you don't see results.


```text
let timeOffset = 7d;
let discardEventId = 4688;
SecurityEvent
| where TimeGenerated > ago(timeOffset*2) and TimeGenerated < ago(timeOffset)
| where EventID != discardEventId
```

"ago()" is a function that takes the current Date and Time and subtract the value provided.


## Declare dynamic tables or lists

Let statements allow for the creation of dynamic tables or lists.


```text
let suspiciousAccounts = datatable(account: string) [
    @"\administrator", 
    @"NT AUTHORITY\SYSTEM"
];
SecurityEvent | where Account in (suspiciousAccounts)
```


```text
let LowActivityAccounts =
    SecurityEvent 
    | summarize cnt = count() by Account 
    | where cnt < 1000;
LowActivityAccounts | where Account contains "SQL"
```


---

*Source: [https://learn.microsoft.com/en-us/training/modules/construct-kusto-query-language-statements/5-use-let-statement/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/construct-kusto-query-language-statements/5-use-let-statement/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel)*