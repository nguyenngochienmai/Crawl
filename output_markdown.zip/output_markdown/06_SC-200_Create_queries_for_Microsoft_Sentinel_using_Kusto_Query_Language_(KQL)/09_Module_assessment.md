---
title: Module assessment
learning_path: SC-200: Create queries for Microsoft Sentinel using Kusto Query Language (KQL)
module_number: 9
url: https://learn.microsoft.com/en-us/training/modules/construct-kusto-query-language-statements/9-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel
type: quiz
crawled_at: 2025-11-25T18:36:19.256777
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "What does the search operator do?",
"options": [
"Searches across tables and isn't column-specific.",
"Searches only data in the last hour.",
"Searches in columns specified."
],
"correct\_answers": [
"Searches across tables and isn't column-specific."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "What are project operators?",
"options": [
"Project operators filter a table to the subset of rows that satisfy a predicate.",
"Project operators create summarized columns and append them to the result set.",
"Project operators add, remove, or rename columns in a result set."
],
"correct\_answers": [
"Project operators add, remove, or rename columns in a result set."
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/construct-kusto-query-language-statements/9-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/construct-kusto-query-language-statements/9-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-utilize-kql-for-azure-sentinel)*