---
title: Connect Microsoft Defender for IoT
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 19
url: https://learn.microsoft.com/en-us/training/modules/connect-microsoft-defender-365-to-azure-sentinel/5-connect-microsoft-defender-iot/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: content
crawled_at: 2025-11-25T19:06:06.673276
---

# Connect Microsoft Defender for IoT

> Connect Microsoft Defender for IoT

Gain insights into your IoT security by connecting Microsoft Defender for IoT alerts to Microsoft Sentinel. You can get out-of-the-box alert metrics and data, including alert trends, top alerts, and alert breakdown by severity. You can also get information about the recommendations provided for your IoT hubs including top recommendations and recommendations by severity.

To view the connector page, do the following steps:

1. Select Data connectors page in Microsoft Sentinel.
2. Select Microsoft Defender for IoT
3. Then select the Open connector page on the preview pane.
4. Select the Connect toggle the subscription.

Select Data connectors page in Microsoft Sentinel.

Select **Microsoft Defender for IoT**

Then select the **Open connector** page on the preview pane.

Select the **Connect** toggle the subscription.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-microsoft-defender-365-to-azure-sentinel/5-connect-microsoft-defender-iot/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-microsoft-defender-365-to-azure-sentinel/5-connect-microsoft-defender-iot/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*