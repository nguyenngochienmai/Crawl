---
title: Module assessment
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 33
url: https://learn.microsoft.com/en-us/training/modules/connect-common-event-format-logs-to-azure-sentinel/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: quiz
crawled_at: 2025-11-25T19:09:39.600706
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "The CEF connector writes to which table?",
"options": [
"CommonSecurityLog",
"SecurityEvent",
"Syslog"
],
"correct\_answers": [
"CommonSecurityLog"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "The CEF connector deploys what type of forwarder?",
"options": [
"Syslog",
"Event",
"Sysmon"
],
"correct\_answers": [
"Syslog"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "The CEF connector can be deployed on which platform?",
"options": [
"Azure Windows Virtual Machine",
"On-premises Windows Host",
"Azure Linux Virtual Machine"
],
"correct\_answers": [
"Azure Linux Virtual Machine"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-common-event-format-logs-to-azure-sentinel/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-common-event-format-logs-to-azure-sentinel/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*