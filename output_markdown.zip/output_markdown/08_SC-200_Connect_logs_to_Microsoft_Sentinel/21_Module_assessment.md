---
title: Module assessment
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 21
url: https://learn.microsoft.com/en-us/training/modules/connect-microsoft-defender-365-to-azure-sentinel/7-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: quiz
crawled_at: 2025-11-25T19:06:20.871478
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "Which connector would you use to connect the raw data from Microsoft Defender for Endpoint?",
"options": [
"Microsoft Defender for Office 365",
"Microsoft Defender for Endpoint",
"Microsoft Defender XDR"
],
"correct\_answers": [
"Microsoft Defender XDR"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "Which Microsoft security product is part of the Microsoft Defender XDR suite of products?",
"options": [
"Microsoft Defender for Cloud Apps",
"Microsoft Purview Information Protection",
"Microsoft Entra ID"
],
"correct\_answers": [
"Microsoft Defender for Cloud Apps"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "Which table (Data type) does the Microsoft Defender XDR connector write to?",
"options": [
"SecurityAlert",
"CommonSecurityLog",
"SecurityEvent"
],
"correct\_answers": [
"SecurityAlert"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-microsoft-defender-365-to-azure-sentinel/7-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-microsoft-defender-365-to-azure-sentinel/7-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*