---
title: Connect the Microsoft Entra ID Protection connector
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 11
url: https://learn.microsoft.com/en-us/training/modules/connect-microsoft-services-to-azure-sentinel/5-connect-azure-active-directory-identity-protection-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: content
crawled_at: 2025-11-25T19:03:58.655659
---

# Connect the Microsoft Entra ID Protection connector

> Connect the Microsoft Entra ID Protection connector

Microsoft Entra ID Protection provides a consolidated view of at-risk users, risk events, and vulnerabilities, with the ability to remediate risk immediately and set policies to autoremediate future events.


## Install the solution

Start by installing the solution that contains the data connector.

1. For Microsoft Sentinel in the Azure portal, under Content management, select Content hub. For Microsoft Sentinel in the Defender portal, select Microsoft Sentinel > Content management > Content hub.
2. Search for and select Microsoft Entra ID Protection.
3. On the right-hand side pane, select Install.


## Configure the data connector

After the solution is installed, connect the data connector.

1. In the Microsoft Sentinel left navigation menu expand Configuration,  and select Data connectors.
2. Select Microsoft Entra ID Protection.
3. Then select the Open connector page on the preview pane.
4. Select Connect to start streaming the Microsoft Entra ID Protection alerts.
5. Select whether alerts from Microsoft Entra ID Protection automatically generate incidents by selecting Enable.

In the Microsoft Sentinel left navigation menu expand **Configuration**,  and select **Data connectors**.

Select **Microsoft Entra ID Protection**.

Then select the **Open connector** page on the preview pane.

Select **Connect** to start streaming the Microsoft Entra ID Protection alerts.

Select whether alerts from Microsoft Entra ID Protection automatically generate incidents by selecting **Enable**.


![Screen shot of the Microsoft Entra ID Protection connector page.](https://learn.microsoft.com/training/wwl-sci/connect-microsoft-services-to-azure-sentinel/media/microsoft-entra-id-protection.png)

If you enable creating incidents, the default analytics rule "Create incidents based on Microsoft Entra ID Protection alerts" is enabled with default values. You can edit this analytical rule on the Analytics page.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-microsoft-services-to-azure-sentinel/5-connect-azure-active-directory-identity-protection-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-microsoft-services-to-azure-sentinel/5-connect-azure-active-directory-identity-protection-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*