---
title: Plan for Microsoft services connectors
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 8
url: https://learn.microsoft.com/en-us/training/modules/connect-microsoft-services-to-azure-sentinel/2-plan-for-microsoft-services-connectors/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: content
crawled_at: 2025-11-25T19:03:34.640962
---

# Plan for Microsoft services connectors

> Plan for Microsoft services connectors

Once you've installed the Content Hub solutions, you can connect Microsoft 365 and Azure-related services in the Data Connector page configuration section in just a few mouse clicks.  It's easy to overlook specific considerations for each connector.  This module demonstrates the connecting of four services. Each service sends data to different Data Types (tables).

First is the Microsoft 365 connector. The Configuration option allows for the sending of Exchange, SharePoint, and Teams data.  Based on your organization's specific needs, you can decide which data to ingest. The Data types show that all the data resides in the OfficeActivity table.

The second is Microsoft Entra ID, which has two options for Sign-On logs and Audit logs.

Third is Microsoft Entra ID Protection. This connector sends data to the SecurityAlert table. The SecurityAlert table holds the alert data only without the underlying data that caused the alert. A second option is to Create Incidents, which is Recommended! This process automatically creates an Incident based on and connected to the alert ingested to the SecurityAlert table from Microsoft Entra ID Protection. You can also activate the incident creation rule on the Analytics page.

The final connector is the Azure Activity. The Azure Activity Log is a subscription log that provides insight into subscription-level events that occur in Azure. Including events from Azure Resource Manager operational data, service health events, write operations taken on the resources in your subscription, and the status of activities performed in Azure.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-microsoft-services-to-azure-sentinel/2-plan-for-microsoft-services-connectors/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-microsoft-services-to-azure-sentinel/2-plan-for-microsoft-services-connectors/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*