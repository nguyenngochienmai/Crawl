---
title: Ingest log data with data connectors
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 2
url: https://learn.microsoft.com/en-us/training/modules/connect-data-to-azure-sentinel-with-data-connectors/2-ingest-log-data-with-data-connectors/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: content
crawled_at: 2025-11-25T19:01:26.483201
---

# Ingest log data with data connectors

> Ingest log data with data connectors

To collect log data, you need to connect your data sources with Microsoft Sentinel Data Connectors. The Data Connectors are included with Content Hub Solutions provided by Microsoft Sentinel.


![Screen shot of Microsoft Sentinel Content Hub page.](https://learn.microsoft.com/training/wwl-sci/connect-data-to-azure-sentinel-with-data-connectors/media/02-azure-activity-content-hub-solution.png)

After you install a Content Hub Solution, installed Data Connectors are displayed in Microsoft Sentinel under the `Configuration | Data connectors` menu section. When you select the Open connector page, the detailed connector page is split and has a left half and a right half.


![Screen shot of Microsoft Sentinel Detailed Connector Page.](https://learn.microsoft.com/training/wwl-sci/connect-data-to-azure-sentinel-with-data-connectors/media/02-azure-activity-data-connector-page.png)

The left half provides information about the connector, the connector's status, and the last time a log was received if connected.  On the bottom section of the left side is the Data Types. The `Data Types` lists the table(s) that the connector writes to.

The right half has an Instructions tab. The Instructions tab can vary based on the connector. In general, there are Prerequisites and Configuration. Follow the Configuration to connect to the data source. The Next steps tab provides a quick reference to workbooks, query samples, and analytical templates. Data Connectors can only be disconnected/deactivated, not deleted.

Content Hub solutions may also install Workbooks, Analytics rules and Hunting queries. Workbooks and Analytic rule templates for out of the box connectors are already available in the Sentinel environment.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-data-to-azure-sentinel-with-data-connectors/2-ingest-log-data-with-data-connectors/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-data-to-azure-sentinel-with-data-connectors/2-ingest-log-data-with-data-connectors/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*