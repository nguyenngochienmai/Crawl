---
title: Module assessment
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 40
url: https://learn.microsoft.com/en-us/training/modules/connect-syslog-data-sources-to-azure-sentinel/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: quiz
crawled_at: 2025-11-25T19:10:47.562136
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "What field contains the unstructured event data?",
"options": [
"SyslogData",
"SyslogEvent",
"SyslogMessage"
],
"correct\_answers": [
"SyslogMessage"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "To create a parser in the Log query window, save the query as which of the following?",
"options": [
"Module",
"Function",
"Table"
],
"correct\_answers": [
"Function"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "The Syslog connector can be deployed on which platform?",
"options": [
"Azure Windows Virtual Machine",
"On-premise Windows Host",
"Azure Linux Virtual Machine"
],
"correct\_answers": [
"Azure Linux Virtual Machine"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-syslog-data-sources-to-azure-sentinel/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-syslog-data-sources-to-azure-sentinel/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*