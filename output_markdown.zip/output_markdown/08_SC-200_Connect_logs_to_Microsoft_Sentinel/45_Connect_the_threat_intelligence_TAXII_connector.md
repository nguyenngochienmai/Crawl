---
title: Connect the threat intelligence TAXII connector
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 45
url: https://learn.microsoft.com/en-us/training/modules/connect-threat-indicators-to-azure-sentinel/4-connect-threat-intelligence-taxii-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: content
crawled_at: 2025-11-25T19:13:45.606973
---

# Connect the threat intelligence TAXII connector

> Connect the threat intelligence TAXII connector

Microsoft Sentinel integrates with TAXII 2.0 and 2.1 data sources to enable monitoring, alerting, and hunting using your threat intelligence. Use this connector to send threat indicators from TAXII servers to Microsoft Sentinel. Threat indicators can include IP addresses, domains, URLs, and file hashes.

In the Azure portal, navigate to Microsoft Sentinel &gt; Data connectors and then select the Threat Intelligence - TAXII connector.

To view the connector page:

1. Select Data connectors page.
2. Select Threat intelligence - TAXII.
3. select the Open connector page on the preview pane.
4. Specify the required and optional information in the text boxes.

Friendly name (for server)

API root URL

Collection ID

Username

Password
5. Friendly name (for server)
6. API root URL
7. Collection ID
8. Username
9. Password
10. Select Add to enable the connection.

Select Data connectors page.

Select **Threat intelligence - TAXII**.

select the **Open connector** page on the preview pane.

Specify the required and optional information in the text boxes.

- Friendly name (for server)
- API root URL
- Collection ID
- Username
- Password

Friendly name (for server)

API root URL

Collection ID

Select **Add** to enable the connection.

The list of configure TAXII servers shows the currently connected TAXII servers and the last indicator received time. The ellipse at the end of the configured server provides the option to remove the server configuration.


![Screenshot of the Sentinel T A X I I Connector page.](https://learn.microsoft.com/training/wwl-sci/connect-threat-indicators-to-azure-sentinel/media/taxii-connectors.png)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-threat-indicators-to-azure-sentinel/4-connect-threat-intelligence-taxii-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-threat-indicators-to-azure-sentinel/4-connect-threat-intelligence-taxii-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*