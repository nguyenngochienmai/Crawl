---
title: Collect Sysmon event logs
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 27
url: https://learn.microsoft.com/en-us/training/modules/connect-windows-hosts-to-azure-sentinel/3-collect-sysmon-event-logs/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: content
crawled_at: 2025-11-25T19:08:47.690343
---

# Collect Sysmon event logs

> Collect Sysmon event logs

System Monitor (Sysmon) is a Windows system service, and device driver that remains resident across system reboots to monitor and log system activity to the Windows event log once installed on a system. It provides detailed information about process creations, network connections, and changes to file creation time. By collecting the events it generates using Windows Event Collection or SIEM agents and then analyzing them, you can identify malicious or anomalous activity and understand how intruders and malware operate on your network.

Installing and configuring Sysmon is out of the scope of this training. For more information on Sysmon, see [Sysinternals Sysmon](/en-us/sysinternals/downloads/sysmon" data-linktype="absolute-path).

After connecting the Sysmon agent to the windows machine, you install the *Windows Forwarded Events* Content hub solution which includes the *Windows Forwarded Events* data connector. The data connector allows you to stream all Windows Event Forwarding (WEF) logs from the Windows Servers connected to your Microsoft Sentinel workspace using Azure Monitor Agent (AMA). In the data connector configuration, you create *Data collection rules* (DCRs) to collect metrics and logs from the client operating system. Perform the following steps to create a DCR and enable Microsoft Sentinel to query the logs:


## Install the solution

Start by installing the solution that contains the data connector.

1. For Microsoft Sentinel in the Azure portal, under Content management, select Content hub. For Microsoft Sentinel in the Defender portal, select Microsoft Sentinel > Content management > Content hub.
2. Search for and select Windows Forwarded Events.
3. On the details pane, select Install.

For Microsoft Sentinel in the Azure portal, under **Content management**, select **Content hub**. For Microsoft Sentinel in the Defender portal, select **Microsoft Sentinel** &gt; **Content management** &gt; **Content hub**.

Search for and select **Windows Forwarded Events**.

On the details pane, select **Install**.


## Configure the data connector

After the solution is installed, connect the data connector.

1. In the Microsoft Sentinel navigation menu expand Configuration,  and select Data connectors.
2. Select the Windows Forwarded Events Data connector.
3. Select +Create data collections rule.
4. Fill in the following fields of the Basic tab:
 
		
			
		
		Expand table
	


Setting
Description




Rule Name
A name for the DCR. The name should be something descriptive that helps you identify the rule.


Subscription
The subscription to store the DCR. The subscription doesn't need to be the same subscription as the virtual machines.


Resource group
A resource group to store the DCR. The resource group doesn't need to be the same resource group as the virtual machines.
5. Select Next:Resources >.
6. In the Resources tab, expand the Scope column, and expand the Microsoft Azure subscription.
7. Expand the resource group or groups, and select the virtual machines you want to connect to Microsoft Sentinel.
8. Select the Next: Collect > button, and select Custom radio button.
9. As an example, you can enter the following events log location (XPath format) to collect Sysmon events:

		XML
		
		
			
				
				
			
			Copy
		
	
		
	Microsoft-Windows-Sysmon/Operational!*
10. Select the Add button to add the Sysmon events log location.
11. Select the Next: Review + create > button, after validation passes, select Create.







 Note
At the end of this process, the Azure Monitor Agent is installed on any selected machines that don't already have the agent.
12. After the DCR is created, select the Refresh button to see the rule. You can also edit or delete existing rules from the Configuration section of the connector page.

In the Microsoft Sentinel navigation menu expand **Configuration**,  and select **Data connectors**.

Select the **Windows Forwarded Events** Data connector.

Select **+Create data collections rule**.


![Screenshot that shows the Basics tab for a new data collection rule.](https://learn.microsoft.com/training/wwl-sci/connect-windows-hosts-to-azure-sentinel/media/windows-forwarded-events.png)

Fill in the following fields of the *Basic* tab:

| Setting | Description |
| --- | --- |
| Rule Name | A name for the DCR. The name should be something descriptive that helps you identify the rule. |
| Subscription | The subscription to store the DCR. The subscription doesn't need to be the same subscription as the virtual machines. |
| Resource group | A resource group to store the DCR. The resource group doesn't need to be the same resource group as the virtual machines. |

Select **Next:Resources &gt;**.

In the *Resources* tab, expand the **Scope** column, and expand the Microsoft Azure subscription.

Expand the resource group or groups, and select the virtual machines you want to connect to Microsoft Sentinel.

Select the **Next: Collect &gt;** button, and select **Custom** radio button.

As an example, you can enter the following events log location (XPath format) to collect Sysmon events:


```text
Microsoft-Windows-Sysmon/Operational!*
```

Select the **Add** button to add the Sysmon events log location.

Select the **Next: Review + create &gt;** button, after validation passes, select **Create**.


![Screenshot of Log Analytics Sysmon configuration.](https://learn.microsoft.com/training/wwl-sci/connect-windows-hosts-to-azure-sentinel/media/sysmon-log-location.png)

At the end of this process, the Azure Monitor Agent is installed on any selected machines that don't already have the agent.

After the DCR is created, select the **Refresh** button to see the rule. You can also edit or delete existing rules from the **Configuration** section of the connector page.

This connector can use the Advanced Security Information Model (ASIM). Microsoft recommends that you use the ASIM normalization. For more information on ASIM, see [Advanced Security Information Model (ASIM)](/en-us/azure/sentinel/normalization" data-linktype="absolute-path).

1. On the Windows Forwarded Events connector page, Configuration section, select the Deploy button.
2. Fill-in the required fields of the Custom deployment ARM template, and select Review + create.
3. When validation passes, select Create.

On the **Windows Forwarded Events** connector page, **Configuration** section, select the **Deploy** button.

Fill-in the required fields of the **Custom deployment** ARM template, and select **Review + create**.

When validation passes, select **Create**.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-windows-hosts-to-azure-sentinel/3-collect-sysmon-event-logs/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-windows-hosts-to-azure-sentinel/3-collect-sysmon-event-logs/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*