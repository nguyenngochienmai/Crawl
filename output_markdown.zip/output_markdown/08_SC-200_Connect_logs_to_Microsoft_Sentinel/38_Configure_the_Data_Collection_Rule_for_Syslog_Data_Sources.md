---
title: Configure the Data Collection Rule for Syslog Data Sources
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 38
url: https://learn.microsoft.com/en-us/training/modules/connect-syslog-data-sources-to-azure-sentinel/4-configure-log-analytics-agent/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: content
crawled_at: 2025-11-25T19:10:33.311265
---

# Configure the Data Collection Rule for Syslog Data Sources

> Configure the Data Collection Rule for Syslog Data Sources

The Data Collection Rule (DCR) only collects events with the facilities and severities that are specified in its Data sources configurations. For Syslog, you can modify the `Facility Minimum log level` and `Destination` in the **Add data source** page.

To configure the Syslog `Facility log level`and `Destination`:

1. Access the Data collection rule Data sources Add data source page:

Select Configuration, Data sources

Select Linux Syslog.
2. Select Configuration, Data sources
3. Select Linux Syslog.
4. Select the Minimum log level drop-down menu to make changes for each Facility.
5. When completed select Save

 Note
The default is "LOG_DEBUG" for each Facility, and changes are automatically pushed to all configured resources.

Access the Data collection rule Data sources **Add data source** page:

- Select Configuration, Data sources
- Select Linux Syslog.

Select **Configuration**, **Data sources**

Select **Linux Syslog**.

Select the **Minimum log level** drop-down menu to make changes for each `Facility`.


![Screenshot of Linux Syslog facilities selections and minimum log levels.](https://learn.microsoft.com/training/wwl-sci/connect-syslog-data-sources-to-azure-sentinel/media/04-linux-syslog-facilities-log-level.png)

When completed select **Save**

The default is "LOG_DEBUG" for each Facility, and changes are automatically pushed to all configured resources.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-syslog-data-sources-to-azure-sentinel/4-configure-log-analytics-agent/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-syslog-data-sources-to-azure-sentinel/4-configure-log-analytics-agent/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*