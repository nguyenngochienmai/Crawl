---
title: Plan for Microsoft Defender XDR connectors
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 16
url: https://learn.microsoft.com/en-us/training/modules/connect-microsoft-defender-365-to-azure-sentinel/2-plan-for-microsoft-365-defender-connectors/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: content
crawled_at: 2025-11-25T19:05:42.329759
---

# Plan for Microsoft Defender XDR connectors

> Plan for Microsoft Defender XDR connectors

The Microsoft Defender portal​ is a unified, natively integrated, pre-, and post-breaches enterprise defense suite. It protects endpoint, identity, email, and cloud app threats. You can detect, prevent, investigate, and automatically respond to sophisticated threats in a central place. It includes the following services:

- Microsoft Defender for Office 365
- Microsoft Defender for Endpoint
- Microsoft Defender for Identity
- Microsoft Defender for Cloud Apps

Microsoft Defender for Office 365

Microsoft Defender for Endpoint

Microsoft Defender for Identity

Microsoft Defender for Cloud Apps

The Microsoft Defender XDR integration with Microsoft Sentinel currently provides these data connectors for those services:

- Microsoft Defender XDR
- Microsoft Defender for Cloud Apps
- Microsoft Defender for Endpoint
- Microsoft Defender for Identity
- Microsoft Defender for Office 365

Microsoft Defender XDR

Microsoft Defender for Cloud Apps

Microsoft Defender for Endpoint

Microsoft Defender for Identity

Microsoft Defender for Office 365

Other relevant Microsoft Defender data connectors include:

- Microsoft Defender for IoT
- Microsoft Purview Insider Risk Management

Microsoft Defender for IoT

Microsoft Purview Insider Risk Management

It's important to understand how data is ingested by each connector. Does the connector support bi-directional syncing of Incidents?  Should you ingest the raw log data for hunting and entity analysis? Once you've decided the required data from each log source, then enable the connectors.

These connectors are now considered *Legacy* connectors:

Microsoft Defender for Cloud Apps, Microsoft Defender for Endpoint, Microsoft Defender for Identity and Microsoft Defender for Office 365.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-microsoft-defender-365-to-azure-sentinel/2-plan-for-microsoft-365-defender-connectors/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-microsoft-defender-365-to-azure-sentinel/2-plan-for-microsoft-365-defender-connectors/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*