---
title: Summary and resources
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 34
url: https://learn.microsoft.com/en-us/training/modules/connect-common-event-format-logs-to-azure-sentinel/5-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: summary
crawled_at: 2025-11-25T19:10:03.210032
---

# Summary and resources

> Summary and resources

You should have learned how to send Common Event Format (CEF) log data to the Microsoft Sentinel workspace using the provided data connector.

You should now be able to:

- Explain the CEF Connector deployment options in Microsoft Sentinel
- Run the deployment script for the CEF connector


## Learn more

You can learn more by reviewing the following.

[Become a Microsoft Sentinel Ninja](https://techcommunity.microsoft.com/t5/azure-sentinel/become-an-azure-sentinel-ninja-the-complete-level-400-training/ba-p/1246310" data-linktype="external" target="az-portal" class="has-external-link-indicator)

[Microsoft Tech Community Security Webinars](https://techcommunity.microsoft.com/t5/microsoft-security-and/security-community-webinars/ba-p/927888" data-linktype="external" target="az-portal" class="has-external-link-indicator)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-common-event-format-logs-to-azure-sentinel/5-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-common-event-format-logs-to-azure-sentinel/5-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*