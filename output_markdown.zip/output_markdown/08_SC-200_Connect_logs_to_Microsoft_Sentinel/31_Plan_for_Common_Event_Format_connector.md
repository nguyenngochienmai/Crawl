---
title: Plan for Common Event Format connector
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 31
url: https://learn.microsoft.com/en-us/training/modules/connect-common-event-format-logs-to-azure-sentinel/2-plan-for-common-event-format-cef-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: content
crawled_at: 2025-11-25T19:09:24.013992
---

# Plan for Common Event Format connector

> Plan for Common Event Format connector

The CEF Connector deploys a Syslog Forwarder server to support the communication between the appliance and Microsoft Sentinel. The server consists of a dedicated Linux machine with the Log Analytics agent for Linux installed. Many of the Microsoft Sentinel Data Connectors that are vendor-specific utilize CEF Connector.

The following diagram displays the setup for a Linux VM in Azure. The on-premises Syslog sources securely send events to an Azure Linux VM. The Linux VM with the Log Analytics agent installed then forwards the logs to the Microsoft Sentinel workspace.


![Diagram of the Azure VM hosting Syslog connector architecture.](https://learn.microsoft.com/training/wwl-sci/connect-common-event-format-logs-to-azure-sentinel/media/learn-path5-01.png)

Alternatively, the following diagram displays the setup if you use a VM in another cloud or an on-premises machine. The on-premises Syslog sources securely send events to a Linux VM. The Linux VM with the Log Analytics agent installed then securely forwards the logs to the Microsoft Sentinel workspace.


![Diagram of the on-premises Syslog connector architecture.](https://learn.microsoft.com/training/wwl-sci/connect-common-event-format-logs-to-azure-sentinel/media/learn-path5-02.png)


## Security considerations

Make sure to configure the machine's security according to your organization's security policy. For example, you can configure your network to align with your corporate network security policy and change the daemon's ports and protocols to align with your requirements.

To use TLS communication between the Syslog source and the Syslog Forwarder, you'll need to configure the Syslog daemon (rsyslog or syslog-ng) to communicate in TLS.


## Prerequisites

Make sure the Linux machine you use as a log forwarder is running one of the following operating systems:

- 64-bit

Amazon Linux 2017.09

Oracle Linux 7

Red Hat Enterprise Linux (RHEL) Server 7 and 8, including minor versions (not 6)

Debian GNU/Linux 8 and 9

Ubuntu Linux 14.04 LTS, 16.04 LTS, and 18.04 LTS

SUSE Linux Enterprise Server 12, 15
- Amazon Linux 2017.09
- Oracle Linux 7
- Red Hat Enterprise Linux (RHEL) Server 7 and 8, including minor versions (not 6)
- Debian GNU/Linux 8 and 9
- Ubuntu Linux 14.04 LTS, 16.04 LTS, and 18.04 LTS
- SUSE Linux Enterprise Server 12, 15
- 32-bit

Oracle Linux 7

Red Hat Enterprise Linux (RHEL) Server 7 and 8, including minor versions (not 6)

Debian GNU/Linux 8 and 9

Ubuntu Linux 14.04 LTS and 16.04 LTS
- Oracle Linux 7
- Red Hat Enterprise Linux (RHEL) Server 7 and 8, including minor versions (not 6)
- Debian GNU/Linux 8 and 9
- Ubuntu Linux 14.04 LTS and 16.04 LTS
- Daemon versions

Syslog-ng: 2.1 - 3.22.1

Rsyslog: v8
- Syslog-ng: 2.1 - 3.22.1
- Rsyslog: v8
- Syslog RFCs supported

Syslog RFC 3164

Syslog RFC 5424
- Syslog RFC 3164
- Syslog RFC 5424

- Amazon Linux 2017.09
- Oracle Linux 7
- Red Hat Enterprise Linux (RHEL) Server 7 and 8, including minor versions (not 6)
- Debian GNU/Linux 8 and 9
- Ubuntu Linux 14.04 LTS, 16.04 LTS, and 18.04 LTS
- SUSE Linux Enterprise Server 12, 15

Amazon Linux 2017.09

Oracle Linux 7

Red Hat Enterprise Linux (RHEL) Server 7 and 8, including minor versions (not 6)

Debian GNU/Linux 8 and 9

Ubuntu Linux 14.04 LTS, 16.04 LTS, and 18.04 LTS

SUSE Linux Enterprise Server 12, 15

- Oracle Linux 7
- Red Hat Enterprise Linux (RHEL) Server 7 and 8, including minor versions (not 6)
- Debian GNU/Linux 8 and 9
- Ubuntu Linux 14.04 LTS and 16.04 LTS

Oracle Linux 7

Red Hat Enterprise Linux (RHEL) Server 7 and 8, including minor versions (not 6)

Debian GNU/Linux 8 and 9

Ubuntu Linux 14.04 LTS and 16.04 LTS

Daemon versions

- Syslog-ng: 2.1 - 3.22.1
- Rsyslog: v8

Syslog-ng: 2.1 - 3.22.1

Rsyslog: v8

Syslog RFCs supported

- Syslog RFC 3164
- Syslog RFC 5424

Syslog RFC 3164

Syslog RFC 5424

Make sure your machine also meets the following requirements:

Permissions

- You must have elevated permissions (sudo) on your machine.

Software requirements

- Make sure you have python 2.7 or 3 running on your machine.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-common-event-format-logs-to-azure-sentinel/2-plan-for-common-event-format-cef-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-common-event-format-logs-to-azure-sentinel/2-plan-for-common-event-format-cef-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*