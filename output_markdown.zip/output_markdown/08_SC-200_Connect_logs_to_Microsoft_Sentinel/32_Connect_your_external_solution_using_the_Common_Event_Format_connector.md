---
title: Connect your external solution using the Common Event Format connector
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 32
url: https://learn.microsoft.com/en-us/training/modules/connect-common-event-format-logs-to-azure-sentinel/3-connect-your-external-solution-use-common-event-format-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: content
crawled_at: 2025-11-25T19:09:32.144350
---

# Connect your external solution using the Common Event Format connector

> Connect your external solution using the Common Event Format connector

You need to designate and configure a Linux machine to forward the logs from your security solution to your Microsoft Sentinel workspace. This machine can be physical or virtual in your on-premises environment, an Azure VM, or a VM in another cloud. Using the link provided, you'll run a script on the designated machine that performs the following tasks:

Installs the Log Analytics agent for Linux (also known as the OMS agent) and configures it for the following purposes:

- Listening for CEF messages from the built-in Linux Syslog daemon on TCP port 25226
- Sending the messages securely over TLS to your Microsoft Sentinel workspace, where they're parsed and enriched

Listening for CEF messages from the built-in Linux Syslog daemon on TCP port 25226

Sending the messages securely over TLS to your Microsoft Sentinel workspace, where they're parsed and enriched

Configures the built-in Linux Syslog daemon (rsyslog.d/syslog-ng) for the following purposes:

- Listening for Syslog messages from your security solutions on TCP port 514
- Forwarding only the messages it identifies as CEF to the Log Analytics agent on localhost using TCP port 25226

Listening for Syslog messages from your security solutions on TCP port 514

Forwarding only the messages it identifies as CEF to the Log Analytics agent on localhost using TCP port 25226


## Run the deployment script

To view the connector page:

1. Select Data connectors page.
2. Select Common Event Format (CEF).
3. select the Open connector page on the preview pane.
4. Verify that you have the appropriate permissions as described under Prerequisites.
5. Copy the "sudo wget …"  command and run with elevated permissions on the dedicated Linux VM.

Select Data connectors page.

Select Common Event Format (CEF).

select the Open connector page on the preview pane.

Verify that you have the appropriate permissions as described under Prerequisites.

Copy the "sudo wget …"  command and run with elevated permissions on the dedicated Linux VM.


![Screenshot of the C E F Connector Page.](https://learn.microsoft.com/training/wwl-sci/connect-common-event-format-logs-to-azure-sentinel/media/common-event-format-connector.png)


### Using the same machine to forward both plain Syslog and common event format messages

If you plan to use this log forwarder machine to forward Syslog messages as CEF, then to avoid the duplication of events to the Syslog and CommonSecurityLog tables:

On each source machine that sends logs to the forwarder in CEF format, you must edit the Syslog configuration file to remove the facilities used to send CEF messages.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-common-event-format-logs-to-azure-sentinel/3-connect-your-external-solution-use-common-event-format-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-common-event-format-logs-to-azure-sentinel/3-connect-your-external-solution-use-common-event-format-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*