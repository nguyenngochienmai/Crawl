---
title: Summary and resources
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 29
url: https://learn.microsoft.com/en-us/training/modules/connect-windows-hosts-to-azure-sentinel/5-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: summary
crawled_at: 2025-11-25T19:09:09.905158
---

# Summary and resources

> Summary and resources

You should have learned how to connect Windows devices to the Microsoft Sentinel workspace using the provided data connectors.  The connector offers options to control which events to collect.

You should now be able to:

- Connect Azure Windows Virtual Machines to Microsoft Sentinel
- Connect non-Azure Windows hosts to Microsoft Sentinel
- Configure Log Analytics agent to collect Sysmon events


## Learn more

You can learn more by reviewing the following.

[Become a Microsoft Sentinel Ninja](https://techcommunity.microsoft.com/t5/azure-sentinel/become-an-azure-sentinel-ninja-the-complete-level-400-training/ba-p/1246310" data-linktype="external" target="az-portal" class="has-external-link-indicator)

[Microsoft Tech Community Security Webinars](https://techcommunity.microsoft.com/t5/microsoft-security-and/security-community-webinars/ba-p/927888" data-linktype="external" target="az-portal" class="has-external-link-indicator)

[Microsoft Defender for Cloud data collection with the Azure Monitor Agent (AMA)](/en-us/azure/defender-for-cloud/monitoring-components" data-linktype="absolute-path)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-windows-hosts-to-azure-sentinel/5-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-windows-hosts-to-azure-sentinel/5-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*