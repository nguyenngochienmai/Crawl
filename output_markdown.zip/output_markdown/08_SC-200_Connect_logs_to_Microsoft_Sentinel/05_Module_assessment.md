---
title: Module assessment
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 5
url: https://learn.microsoft.com/en-us/training/modules/connect-data-to-azure-sentinel-with-data-connectors/5-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: quiz
crawled_at: 2025-11-25T19:01:49.184888
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "Where can you see the number of connected Windows hosts?",
"options": [
"On the CEF Connector page",
"On the Agents page in Log Analytics",
"On the Data connectors page"
],
"correct\_answers": [
"On the Agents page in Log Analytics"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "Which connector provides the log data in an unparsed field?",
"options": [
"Microsoft Entra ID",
"Syslog",
"CEF"
],
"correct\_answers": [
"Syslog"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "The vendor-provided connectors primarily use which of the following?",
"options": [
"Azure Activity Connector",
"Security Events Connector",
"CEF Connector"
],
"correct\_answers": [
"CEF Connector"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-data-to-azure-sentinel-with-data-connectors/5-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-data-to-azure-sentinel-with-data-connectors/5-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*