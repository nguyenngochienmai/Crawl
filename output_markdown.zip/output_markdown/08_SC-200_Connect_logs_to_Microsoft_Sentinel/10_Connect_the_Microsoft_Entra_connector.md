---
title: Connect the Microsoft Entra connector
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 10
url: https://learn.microsoft.com/en-us/training/modules/connect-microsoft-services-to-azure-sentinel/4-connect-azure-active-directory-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: content
crawled_at: 2025-11-25T19:03:49.150878
---

# Connect the Microsoft Entra connector

> Connect the Microsoft Entra connector

Gain insights into Microsoft Entra ID by connecting Audit and Sign in logs to Microsoft Sentinel to gather insights around Microsoft Entra scenarios. You can learn about app usage, conditional access policies, and legacy auth relate details using our Sign-in logs. You can get information on your Self-Service Password Reset (SSPR) usage, Microsoft Entra Management activities like user, group, role, and app management in the Audit logs table.


## Install the solution

Start by installing the solution that contains the data connector.

1. For Microsoft Sentinel in the Azure portal, under Content management, select Content hub. For Microsoft Sentinel in the Defender portal, select Microsoft Sentinel > Content management > Content hub.
2. Search for and select Microsoft Entra ID.
3. On the right-hand side pane, select Install.


## Configure the data connector

After the solution is installed, connect the data connector.

1. In the Microsoft Sentinel left navigation menu expand Configuration,  and select Data connectors.
2. Select Microsoft Entra ID.
3. Then select the Open connector page on the preview pane.
4. Mark the checkboxes next to the logs you want to stream into Microsoft Sentinel, and select Connect.

In the Microsoft Sentinel left navigation menu expand **Configuration**,  and select **Data connectors**.

Select **Microsoft Entra ID**.

Then select the **Open connector** page on the preview pane.

Mark the checkboxes next to the logs you want to stream into Microsoft Sentinel, and select **Connect**.


![Screen shot of the Microsoft Entra connector page.](https://learn.microsoft.com/training/wwl-sci/connect-microsoft-services-to-azure-sentinel/media/microsoft-entra-id.png)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-microsoft-services-to-azure-sentinel/4-connect-azure-active-directory-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-microsoft-services-to-azure-sentinel/4-connect-azure-active-directory-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*