---
title: Connect Microsoft Defender for Cloud connector
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 18
url: https://learn.microsoft.com/en-us/training/modules/connect-microsoft-defender-365-to-azure-sentinel/4-connect-microsoft-defender-cloud-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: content
crawled_at: 2025-11-25T19:05:57.418653
---

# Connect Microsoft Defender for Cloud connector

> Connect Microsoft Defender for Cloud connector

Microsoft Defender for Cloud is a security management tool that allows you to detect and quickly respond to threats across Azure, hybrid, and multicloud workloads. This connector allows you to stream your security alerts from Microsoft Defender for Cloud into Microsoft Sentinel. Then you can view Defender data in workbooks, query it to produce alerts, and investigate and respond to incidents.

To view the connector page, do the following steps:

1. Select Data connectors page in Microsoft Sentinel.
2. Select Microsoft Defender for Cloud
3. Then select the Open connector page on the preview pane.
4. Select the Connect toggle for the subscription.
5. Select the Bi-directional sync option.

Select Data connectors page in Microsoft Sentinel.

Select **Microsoft Defender for Cloud**

Then select the **Open connector** page on the preview pane.

Select the **Connect** toggle for the subscription.

Select the **Bi-directional** sync option.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-microsoft-defender-365-to-azure-sentinel/4-connect-microsoft-defender-cloud-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-microsoft-defender-365-to-azure-sentinel/4-connect-microsoft-defender-cloud-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*