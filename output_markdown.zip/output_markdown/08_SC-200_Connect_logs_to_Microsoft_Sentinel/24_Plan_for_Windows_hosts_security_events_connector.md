---
title: Plan for Windows hosts security events connector
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 24
url: https://learn.microsoft.com/en-us/training/modules/connect-windows-hosts-to-azure-sentinel/2-plan-for-windows-hosts-security-events-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: content
crawled_at: 2025-11-25T19:08:23.535814
---

# Plan for Windows hosts security events connector

> Plan for Windows hosts security events connector

You have two Windows security events Content Hub solution options to stream events from Windows devices to Microsoft Sentinel.

The first option is to install the *Windows Security Events* Content Hub solution. You can choose either of the two agent data connectors available:

- Windows Security Events via AMA Connector
- Security Events via Legacy Agent Connector

The second option is to install the *Windows Forwarded Events* Content Hub solution and configure a Windows Event Collector device to receive events from the Windows devices. The Windows Event Collector device would then forward events to Microsoft Sentinel with the *Windows Forwarded Events* data connector.

Microsoft recommends installation of Windows Security Events via AMA Connector. The Legacy connector uses the Log Analytics agent which was deprecated Aug 31, 2024, and thus should only be installed where AMA isn't supported.


## Windows Security Events via AMA Connector vs. Security Events via Legacy Agent Connector

The Windows Security Events via AMA Connector has the following differences from the Security Events via Legacy Agent Connector:

- Manage collection settings at scale
- Azure Monitoring Agent shared with other solutions
- Performance improvements
- Security improvements

Limitations:

- None.

Requirements:

- non-Azure VM's/devices require Azure Arc.


### Azure Arc

Azure Arc uses the *Azure Connected Machine* agent (azcmagent) installed on the device or VM that allows the device to be managed the same as an Azure VM. Azure Arc provides other functionality including running Azure based services in a hybrid environment.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-windows-hosts-to-azure-sentinel/2-plan-for-windows-hosts-security-events-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-windows-hosts-to-azure-sentinel/2-plan-for-windows-hosts-security-events-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*