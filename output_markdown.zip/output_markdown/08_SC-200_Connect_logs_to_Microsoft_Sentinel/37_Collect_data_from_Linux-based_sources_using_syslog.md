---
title: Collect data from Linux-based sources using syslog
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 37
url: https://learn.microsoft.com/en-us/training/modules/connect-syslog-data-sources-to-azure-sentinel/3-collect-data-from-linux-based-sources-using-syslog/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: content
crawled_at: 2025-11-25T19:10:24.271056
---

# Collect data from Linux-based sources using syslog

> Collect data from Linux-based sources using syslog

Configuring the Azure Monitor Agent for Syslog on Linux machines:

- Azure Linux VM
- Non-Azure Linux machine

To install the agent on an Azure Linux virtual machine:

1. In the Azure portal, enter Monitor in the Search resources, services, and docs search bar.
2. In Monitor, scroll down the left menu to the Settings section and select Data Collection Rules.
3. In Monitor | Data Collection Rules, select + Create.
4. On the Data Collection Rule Basics tab, enter a Rule name and specify a Subscription, Resource Group, Region, and Platform Type. For this exercise, select Linux for Platform Type.
5. Select Next:Resources
6. On the Data Collection Rule Resources tab, select + Add resources.
7. In the Select a scope page, expand the Scope column for Subscription and Resource group types until your target VM is displayed.
8. Select the target VM and select Apply. You should see your Linux VM displayed as a Resource.
9. Select Next: Collect and deliver.
10. On the Data Collection Rule Collect and deliver tab, select + Add data source.
11. In the Add data source page, select Linux Syslog from the Data source type* drop-down menu, and select Add data source. You should see your Linux Syslog Data source and a Destinations(s) of Azure Monitor Logsdisplayed.
12. Select Review + create, and Create after Validation passed is displayed.

 Note
This process initiates the Azure Monitor Linux Agent extension install.
13. After the process completes, locate Virtual Machines in the Azure portal and select the Linux VM you configured as a Data Collection Rule resource.
14. On the Virtual machine Overview, scroll down the left menu to the Settings section and select Extensions + applications.
15. Under the Extensions tab, you should see the AzureMonitorLinuxAgent displayed.







 Note
If Microsoft Defender for Cloud Auto-provisioning is enabled, the Azure Monitor Linux Agent is installed by default as an extension using Azure Policy assignment.

In the Azure portal, enter **Monitor** in the `Search resources, services, and docs` search bar.

In **Monitor**, scroll down the left menu to the **Settings** section and select `Data Collection Rules`.

In **Monitor | Data Collection Rules**, select **+ Create**.


![Screenshot of the Monitor Data Collection Rule create page.](https://learn.microsoft.com/training/wwl-sci/connect-syslog-data-sources-to-azure-sentinel/media/03-data-collection-rules-updated.png)

On the `Data Collection Rule` **Basics** tab, enter a Rule name and specify a Subscription, Resource Group, Region, and Platform Type. For this exercise, select `Linux` for Platform Type.

Select **Next:Resources**

On the `Data Collection Rule` **Resources** tab, select **+ Add resources**.

In the **Select a scope** page, expand the **Scope** column for `Subscription` and `Resource group` types until your target VM is displayed.

Select the target VM and select **Apply**. You should see your Linux VM displayed as a Resource.


![Screenshot of the Monitor Data Collection Rule Add resources and Sect a scope pages](https://learn.microsoft.com/training/wwl-sci/connect-syslog-data-sources-to-azure-sentinel/media/03-data-collection-rule-add-resource.png)

Select **Next: Collect and deliver**.

On the `Data Collection Rule` **Collect and deliver** tab, select **+ Add data source**.

In the **Add data source** page, select **Linux Syslog** from the `Data source type*` drop-down menu, and select **Add data source**. You should see your `Linux Syslog` Data source and a `Destinations(s)` of `Azure Monitor Logs`displayed.

Select **Review + create**, and **Create** after **Validation passed** is displayed.

This process initiates the Azure Monitor Linux Agent extension install.

After the process completes, locate **Virtual Machines** in the Azure portal and select the Linux VM you configured as a `Data Collection Rule` resource.

On the `Virtual machine` Overview, scroll down the left menu to the **Settings** section and select **Extensions + applications**.

Under the **Extensions** tab, you should see the **AzureMonitorLinuxAgent** displayed.


![Screenshot of the Azure Monitor Linux Agent on an Azure VM.](https://learn.microsoft.com/training/wwl-sci/connect-syslog-data-sources-to-azure-sentinel/media/03-azure-monitor-linux-agent-azure-vm.png)

If Microsoft Defender for Cloud Auto-provisioning is enabled, the Azure Monitor Linux Agent is installed by default as an extension using Azure Policy assignment.

To install the agent on non-Azure Linux physical or virtual machines:

1. In the Azure portal, enter Arc in the Search resources, services, and docs search bar.
2. In Azure Arc, scroll down the left navigation menu to the Azure Arc resources section and select Machines.
3. On the Machines page, select + Add/Create and Add a machine.
4. On the Add servers with Azure Arc page, locate the Add a single server box, and select Generate script.
5. On the Add servers with Azure Arc page, Basics tab, select your Subscription and Resource group from the drop-down menus under Project details.

 Tip
Select an Azure region in Server details before creating a new Resource groups.
6. In the Server details section, select your Region and then select Linux from the Operating system drop-down menu under.
7. Select the appropriate Connectivity method from the radio buttons under Connectivity method, and then select Next.
8. On the Add servers with Azure Arc page, Tags tab, enter Physical locations tags as needed and select Next.
9. On the Add servers with Azure Arc page, Download and run script tab, either download or copy the script to the clipboard.

 Tip
If you're using a Microsoft Windows system with Microsoft Azure, it's easy to copy and paste the script into notepad, then ssh into your Linux machine with PowerShell to run the script in a Bash console.
10. Open a Bash console as an administrative (root) user on your non-Azure Linux machine and run the script.
This script does the following:

Download an installation script from the Microsoft Download Center.
Configure the package manager to use and trust the packages.microsoft.com repository.
Download the agent from Microsoft's Linux Software Repository.
Install the agent on the server.
Create the Azure Arc-enabled server resource and associate it with the agent.
11. Download an installation script from the Microsoft Download Center.
12. Configure the package manager to use and trust the packages.microsoft.com repository.
13. Download the agent from Microsoft's Linux Software Repository.
14. Install the agent on the server.
15. Create the Azure Arc-enabled server resource and associate it with the agent.
16. When the script successfully completes, you should see a message stating Latest version of azcmagent is installed.
17. On the Add servers with Azure Arc page, Download and run script tab, select Close.
18. The next step is to connect your non-Azure Linux server azcmagent to Azure Arc.
19. Copy and edit the following Bash script to include the required parameters in double quotes:

		Bash
		
		
			
				
				
			
			Copy
		
	
		
	sudo azcmagent connect --resource-group "$resourceGroup" --tenant-id "$tenantID" --location "$location" --subscription-id "$subscriptionID" --cloud "$cloud" --correlation-id "$correlationId";


 Tip
You can use the export (variables) entries from the agent install script you downloaded or copied to fill in the parameters required in the agent connect script.
20. When the script editing is complete, open a Bash console as an administrative (root) user on your non-Azure Linux machine and run the script.
21. The script tests connectivity to Azure endpoints and then requests you to sign in to https://microsoft.com/devicelogin and enter the supplied code to authenticate.
22. Open a Web browser and navigate to the address as directed, and paste or enter the code into the form and select Next to sign in.
23. On the Pick an account page, select your administrator account, and then select Next. Close browser tabs when complete.
24. In your Bash console, you should see an INFO Connected machine to Azure message.
25. Verify your non-Azure machine is connected to Azure Arc in the Azure portal by entering Arc in the Search resources, services, and docs search bar.
26. In Azure Arc, scroll down the left navigation menu to the Azure Arc resources section and select Machines. You should see your machine with an Arc agent Status of Connected.





 Note
Select Refresh if the Linux machine isn't displayed.
27. The next task is to add your newly connected Azure Arc Linux server to your previously created Data Collection Rule for Syslog.
28. In the Azure portal, enter DCR in the Search resources, services, and docs search bar.
29. Select your Syslog Data Collection Rule
30. In your Data Collection Rule, scroll down the left menu to the Configuration section and select Resources.
31. In Resources select + Add
32. In the Select a scope page, expand the Scope column until your Server - Azure Arc Resource type newly connected Linux machine is displayed.
33. Select the Linux Azure Arc machine and select Apply
34. The Linux Azure Arc VM is now included as one of the Data Collection Rule Resources.

In the Azure portal, enter **Arc** in the `Search resources, services, and docs` search bar.

In **Azure Arc**, scroll down the left navigation menu to the **Azure Arc resources** section and select **Machines**.

On the **Machines** page, select **+ Add/Create** and **Add a machine**.

On the **Add servers with Azure Arc** page, locate the **Add a single server box**, and select **Generate script**.

On the **Add servers with Azure Arc** page, **Basics** tab, select your **Subscription** and **Resource group** from the drop-down menus under **Project details**.

Select an Azure region in **Server details** before creating a new Resource groups.

In the **Server details** section, select your **Region** and then select **Linux** from the **Operating system** drop-down menu under.

Select the appropriate **Connectivity method** from the radio buttons under **Connectivity method**, and then select **Next**.


![Screenshot of Add a server Azure Arc page.](https://learn.microsoft.com/training/wwl-sci/connect-syslog-data-sources-to-azure-sentinel/media/03-add-a-server-with-azure-arc.png)

On the **Add servers with Azure Arc** page, **Tags** tab, enter `Physical locations tags` as needed and select **Next**.

On the **Add servers with Azure Arc** page, **Download and run script** tab, either download or copy the script to the clipboard.

If you're using a Microsoft Windows system with Microsoft Azure, it's easy to copy and paste the script into notepad, then ssh into your Linux machine with PowerShell to run the script in a Bash console.

Open a `Bash console` as an administrative (root) user on your non-Azure Linux machine and run the script.

This script does the following:

- Download an installation script from the Microsoft Download Center.
- Configure the package manager to use and trust the packages.microsoft.com repository.
- Download the agent from Microsoft's Linux Software Repository.
- Install the agent on the server.
- Create the Azure Arc-enabled server resource and associate it with the agent.

When the script successfully completes, you should see a message stating `Latest version of azcmagent is installed`.

On the **Add servers with Azure Arc** page, **Download and run script** tab, select **Close**.

The next step is to connect your non-Azure Linux server `azcmagent` to **Azure Arc**.

Copy and edit the following Bash script to include the required parameters in double quotes:


```text
sudo azcmagent connect --resource-group "$resourceGroup" --tenant-id "$tenantID" --location "$location" --subscription-id "$subscriptionID" --cloud "$cloud" --correlation-id "$correlationId";
```

You can use the export (variables) entries from the agent install script you downloaded or copied to fill in the parameters required in the agent connect script.

When the script editing is complete, open a `Bash console` as an administrative (root) user on your non-Azure Linux machine and run the script.

The script tests connectivity to Azure endpoints and then requests you to sign in to `https://microsoft.com/devicelogin` and enter the supplied code to authenticate.


![Screenshot of the azcmagent connection script running.](https://learn.microsoft.com/training/wwl-sci/connect-syslog-data-sources-to-azure-sentinel/media/03-azcmagent-connect-script.png)

Open a Web browser and navigate to the address as directed, and paste or enter the code into the form and select **Next** to sign in.

On the **Pick an account** page, select your `administrator account`, and then select **Next**. Close browser tabs when complete.

In your `Bash console`, you should see an `INFO Connected machine to Azure` message.

Verify your non-Azure machine is connected to **Azure Arc** in the Azure portal by entering **Arc** in the `Search resources, services, and docs` search bar.

In **Azure Arc**, scroll down the left navigation menu to the **Azure Arc resources** section and select **Machines**. You should see your machine with an `Arc agent Status` of **Connected**.


![Screenshot of azure Arc connected Linux servers](https://learn.microsoft.com/training/wwl-sci/connect-syslog-data-sources-to-azure-sentinel/media/03-azure-arc-connected-server.png)

Select Refresh if the Linux machine isn't displayed.

The next task is to add your newly connected Azure Arc Linux server to your previously created Data Collection Rule for Syslog.

In the Azure portal, enter **DCR** in the `Search resources, services, and docs` search bar.

Select your Syslog Data Collection Rule

In your `Data Collection Rule`, scroll down the left menu to the **Configuration** section and select **Resources**.

In **Resources** select **+ Add**

In the **Select a scope** page, expand the **Scope** column until your **Server - Azure Arc** `Resource type` newly connected Linux machine is displayed.

Select the Linux Azure Arc machine and select **Apply**

The Linux Azure Arc VM is now included as one of the `Data Collection Rule` Resources.


![Screenshot of Azure Arc Linux resource in Data Collection Rule](https://learn.microsoft.com/training/wwl-sci/connect-syslog-data-sources-to-azure-sentinel/media/03-azure-arc-dcr-resource.png)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-syslog-data-sources-to-azure-sentinel/3-collect-data-from-linux-based-sources-using-syslog/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-syslog-data-sources-to-azure-sentinel/3-collect-data-from-linux-based-sources-using-syslog/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*