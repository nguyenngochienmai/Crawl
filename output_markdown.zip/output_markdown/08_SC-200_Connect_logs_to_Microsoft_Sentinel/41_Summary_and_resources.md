---
title: Summary and resources
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 41
url: https://learn.microsoft.com/en-us/training/modules/connect-syslog-data-sources-to-azure-sentinel/7-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: summary
crawled_at: 2025-11-25T19:13:12.970008
---

# Summary and resources

> Summary and resources

You should have learned how to send Syslog log data to the Microsoft Sentinel workspace using the provided data connector.

You should now be able to:

- Describe the Azure Monitor Agent Data Collection Rule (DCR) for Syslog
- Run the Azure Arc Linux deployment and connection scripts
- Install and Configure the Azure Monitor Linux Agent extension with the Syslog DCR
- Verify Syslog log data is available in Microsoft Sentinel
- Create a parser using KQL in Microsoft Sentinel


## Learn more

You can learn more by reviewing the following.

[Collect Syslog events with Azure Monitor Agent](/en-us/azure/azure-monitor/agents/data-collection-syslog" data-linktype="absolute-path)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-syslog-data-sources-to-azure-sentinel/7-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-syslog-data-sources-to-azure-sentinel/7-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*