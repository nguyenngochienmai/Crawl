---
title: Summary and resources
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 14
url: https://learn.microsoft.com/en-us/training/modules/connect-microsoft-services-to-azure-sentinel/8-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: summary
crawled_at: 2025-11-25T19:05:26.839564
---

# Summary and resources

> Summary and resources

You should have learned how to connect Microsoft 365 and Azure services to the Microsoft Sentinel workspace using the provided data connectors.

You should now be able to:

- Connect Microsoft services connectors
- Explain how connectors autocreate incidents in Microsoft Sentinel


## Learn more

You can learn more by reviewing the following.

- Microsoft Sentinel data connectors
- Microsoft 365 connector for Microsoft Sentinel
- Connect Microsoft Entra data to Microsoft Sentinel
- Become a Microsoft Sentinel Ninja
- Microsoft Tech Community Security Webinars


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-microsoft-services-to-azure-sentinel/8-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-microsoft-services-to-azure-sentinel/8-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*