---
title: Module assessment
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 28
url: https://learn.microsoft.com/en-us/training/modules/connect-windows-hosts-to-azure-sentinel/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: quiz
crawled_at: 2025-11-25T19:08:57.440716
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "Which connector do you use to collect Windows security events?",
"options": [
"Windows Security Events via AMA",
"Common Event Format",
"Syslog"
],
"correct\_answers": [
"Windows Security Events via AMA"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "To collect Sysmon events with the Security Events connector, what is the log name used to collect it in advanced settings?",
"options": [
"Microsoft-Windows-Sysmon/Operational",
"Microsoft-Windows-Sysmon/Events",
"Microsoft-Windows-Sysmon/Logs"
],
"correct\_answers": [
"Microsoft-Windows-Sysmon/Operational"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "Which table contains the ingested Sysmon events?",
"options": [
"Event",
"CommonSecurityLog",
"SecurityEvents"
],
"correct\_answers": [
"Event"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-windows-hosts-to-azure-sentinel/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-windows-hosts-to-azure-sentinel/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*