---
title: View connected hosts
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 4
url: https://learn.microsoft.com/en-us/training/modules/connect-data-to-azure-sentinel-with-data-connectors/4-view-connected-hosts/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: content
crawled_at: 2025-11-25T19:01:41.878189
---

# View connected hosts

> View connected hosts

To view your Windows and Linux hosts connected with an agent, you can do so in the Log Analytics workspace. To see your connected hosts do the following steps:


## Microsoft Sentinel and Defender XDR

Select the appropriate tab to see the connected hosts depending on which integration method you use.

- Defender portal
- Azure portal

1. In the Microsoft Defender portal navigation menu, expand System, and select Settings.
2. Select Microsoft Sentinel.
3. Select the appropriate Microsoft Sentinel workspace.
4. In the side panel that opens, select Log Analytics settings, and Configure Log Analytics work.
5. In the Log Analytics workspace, select Settings from the navigation menu, and then select Agents.
6. Select either the Windows or Linux tab to view the connected hosts.

In the Microsoft Defender portal navigation menu, expand **System**, and select **Settings**.

Select **Microsoft Sentinel**.

Select the appropriate Microsoft Sentinel workspace.

In the side panel that opens, select **Log Analytics settings**, and **Configure Log Analytics work**.


![Screen shot of Microsoft Defender Microsoft Sentinel workspace configuration page.](https://learn.microsoft.com/training/wwl-sci/connect-data-to-azure-sentinel-with-data-connectors/media/04-view-connected-hosts-defender.png)

In the Log Analytics workspace, select **Settings** from the navigation menu, and then select **Agents**.

Select either the **Windows** or **Linux** tab to view the connected hosts.


![Screen shot of Log Analytics Agents page.](https://learn.microsoft.com/training/wwl-sci/connect-data-to-azure-sentinel-with-data-connectors/media/04-log-analytics-connected-hosts.png)

1. In the Microsoft Sentinel navigation menu, expand Configuration, and select Settings.
2. Select the Workspace settings tab (this selection transfers you to Log Analytics).
3. In the Log Analytics workspace, select Settings from the navigation menu, and then select Agents.
4. Select either the Windows or Linux tab to view the connected hosts.

In the Microsoft Sentinel navigation menu, expand **Configuration**, and select **Settings**.

Select the **Workspace settings** tab (this selection transfers you to Log Analytics).

In the Log Analytics workspace, select **Settings** from the navigation menu, and then select **Agents**.

Select either the **Windows** or **Linux** tab to view the connected hosts.


![Screen shot of Log Analytics Agents page.](https://learn.microsoft.com/training/wwl-sci/connect-data-to-azure-sentinel-with-data-connectors/media/04-log-analytics-connected-hosts.png)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-data-to-azure-sentinel-with-data-connectors/4-view-connected-hosts/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-data-to-azure-sentinel-with-data-connectors/4-view-connected-hosts/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*