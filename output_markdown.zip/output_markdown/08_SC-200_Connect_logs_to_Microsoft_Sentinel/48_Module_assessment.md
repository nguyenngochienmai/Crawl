---
title: Module assessment
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 48
url: https://learn.microsoft.com/en-us/training/modules/connect-threat-indicators-to-azure-sentinel/7-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: quiz
crawled_at: 2025-11-25T19:14:19.697242
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "What table do you query in KQL to view your indicators?",
"options": [
"\"Indicator\"",
"\"TIIndicator\"",
"\"ThreatIntelligenceIndicator\""
],
"correct\_answers": [
"\"ThreatIntelligenceIndicator\""
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "Which version of TAXII is supported?",
"options": [
"1.1",
"1.0",
"2.1"
],
"correct\_answers": [
"2.1"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "Threat Intelligence Upload API uses which technology to authenticate with Microsoft Entra ID?",
"options": [
"Microsoft Azure managed identities",
"Multifactor authentication",
"OAuth 2.0 authentication"
],
"correct\_answers": [
"OAuth 2.0 authentication"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-threat-indicators-to-azure-sentinel/7-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-threat-indicators-to-azure-sentinel/7-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*