---
title: Introduction
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 7
url: https://learn.microsoft.com/en-us/training/modules/connect-microsoft-services-to-azure-sentinel/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: introduction
crawled_at: 2025-11-25T19:03:27.704945
---

# Introduction

> Introduction

You connect Microsoft 365 and Azure services to the Microsoft Sentinel workspace using the provided data connectors. The data connectors are included in out-of-the-box (OOTB), or built-in Content Hub solutions.

You're a Security Operations Analyst working at a company that implemented Microsoft Sentinel.  You'll connect Microsoft 365 and Azure services to Microsoft Sentinel.

Based on your previously documented connector plan, you use the Content Hub to install the solutions that include the specific connectors. As you activate the connectors, you notice the option to have incidents created from the Microsoft Entra ID Protection service.  You don’t follow the recommended option to create incidents as you plan to activate the incident creation rule with custom options later in your implementation process.

After completing this module, you'll be able to:

- Connect Microsoft service connectors
- Explain how connectors autocreate incidents in Microsoft Sentinel


## Prerequisites

Basic experience with Microsoft Azure operations.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-microsoft-services-to-azure-sentinel/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-microsoft-services-to-azure-sentinel/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*