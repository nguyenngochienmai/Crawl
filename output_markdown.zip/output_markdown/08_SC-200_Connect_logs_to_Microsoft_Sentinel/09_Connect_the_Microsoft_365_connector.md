---
title: Connect the Microsoft 365 connector
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 9
url: https://learn.microsoft.com/en-us/training/modules/connect-microsoft-services-to-azure-sentinel/3-connect-office-365-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: content
crawled_at: 2025-11-25T19:03:41.611968
---

# Connect the Microsoft 365 connector

> Connect the Microsoft 365 connector

The Microsoft 365 connector provides insight into ongoing user activities. You'll collect data like file downloads, access requests sent, changes to group events, set-mailbox, and details of the user who performed the actions.​


## Install the solution

Start by installing the Microsoft 365 solution that contains the data connector.

1. For Microsoft Sentinel in the Azure portal, under Content management, select Content hub. For Microsoft Sentinel in the Defender portal, select Microsoft Sentinel > Content management > Content hub.
2. Search for and select Microsoft 365.
3. On the right-hand side pane, select Install.


## Configure the data connector

After the solution is installed, connect the data connector.

1. In the Microsoft Sentinel left navigation menu expand Configuration,  and select Data connectors.
2. Select Microsoft 365.
3. Then select the Open connector page on the preview pane.
4. Review the Description and Data types tabs to understand the data that is ingested.
5. In the Instructions tab, verify that you meet the Prerequisites.
6. In the Instructions tab, under the section labeled Configuration, select the record types to collect and Apply Changes.
7. Wait until validation is complete and the button changes to Disconnect.

In the Microsoft Sentinel left navigation menu expand **Configuration**,  and select **Data connectors**.

Select **Microsoft 365**.

Then select the **Open connector page** on the preview pane.

Review the *Description* and *Data types* tabs to understand the data that is ingested.

In the **Instructions** tab, verify that you meet the *Prerequisites*.

In the **Instructions** tab, under the section labeled **Configuration**, select the record types to collect and **Apply Changes**.

Wait until validation is complete and the button changes to **Disconnect**.


![Screen shot of the Microsoft Defender XDR Connector page.](https://learn.microsoft.com/training/wwl-sci/connect-microsoft-services-to-azure-sentinel/media/microsoft-365.png)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-microsoft-services-to-azure-sentinel/3-connect-office-365-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-microsoft-services-to-azure-sentinel/3-connect-office-365-connector/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*