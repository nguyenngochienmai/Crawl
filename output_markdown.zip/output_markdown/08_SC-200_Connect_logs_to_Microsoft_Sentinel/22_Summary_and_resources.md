---
title: Summary and resources
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 22
url: https://learn.microsoft.com/en-us/training/modules/connect-microsoft-defender-365-to-azure-sentinel/8-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: summary
crawled_at: 2025-11-25T19:08:08.515179
---

# Summary and resources

> Summary and resources

You should have learned how to connect Microsoft Defender XDR security solutions to the Microsoft Sentinel workspace using the provided data connectors.

You should now be able to:

- Activate the Microsoft Defender XDR connector in Microsoft Sentinel
- Activate the Microsoft Defender for Cloud connector in Microsoft Sentinel


## Learn more

You can learn more by reviewing the following.

[Become a Microsoft Sentinel Ninja](https://techcommunity.microsoft.com/t5/azure-sentinel/become-an-azure-sentinel-ninja-the-complete-level-400-training/ba-p/1246310" data-linktype="external" target="az-portal" class="has-external-link-indicator)

[Microsoft Tech Community Security Webinars](https://techcommunity.microsoft.com/t5/microsoft-security-and/security-community-webinars/ba-p/927888" data-linktype="external" target="az-portal" class="has-external-link-indicator)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-microsoft-defender-365-to-azure-sentinel/8-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-microsoft-defender-365-to-azure-sentinel/8-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*