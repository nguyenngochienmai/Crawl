---
title: Introduction
learning_path: SC-200: Connect logs to Microsoft Sentinel
module_number: 23
url: https://learn.microsoft.com/en-us/training/modules/connect-windows-hosts-to-azure-sentinel/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel
type: introduction
crawled_at: 2025-11-25T19:08:16.632521
---

# Introduction

> Introduction

You connect Windows devices to the Microsoft Sentinel workspace using the provided data connectors.  The connector offers options to control which events to collect.

You're a Security Operations Analyst working at a company that implemented Microsoft Sentinel.  You must collect event log data from Windows Hosts.  The hosts could be located on-premise or as a virtual machine in Azure.

Your Security Operations team relies on event data created by the Sysmon tool installed on some of the Windows Hosts.  You'll configure the Windows hosts to send event data to Microsoft Sentinel.  You also need to ensure that the Sysmon events are available to be used in detection rules.

By the end of this module, you'll be able to connect Windows devices to the Microsoft Sentinel workspace using the provided data connector.

After completing this module, you'll be able to:

- Connect Azure Windows Virtual Machines to Microsoft Sentinel
- Connect non-Azure Windows hosts to Microsoft Sentinel
- Configure Log Analytics agent to collect Sysmon events


## Prerequisites

Basic knowledge of operational concepts such as monitoring, logging, and alerting.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-windows-hosts-to-azure-sentinel/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/connect-windows-hosts-to-azure-sentinel/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-connect-logs-to-azure-sentinel)*