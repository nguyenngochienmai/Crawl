---
title: Summary and resources
learning_path: SC-200: Mitigate threats using Microsoft Defender for Cloud
module_number: 13
url: https://learn.microsoft.com/en-us/training/modules/connect-azure-assets-to-azure-defender/6-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender
type: summary
crawled_at: 2025-11-25T18:24:00.438224
---

# Summary and resources

> Summary and resources

You should have learned how resource protection in Microsoft Defender for Cloud can be automatically configured with auto provisioning or manually deployed.

You should now be able to:

- Explore Azure assets
- Configure auto provisioning in Microsoft Defender for Cloud
- Describe manual provisioning in Microsoft Defender for Cloud


## Learn more

You can learn more by reviewing the following.

[Become an Microsoft Defender for Cloud Ninja (microsoft.com)](https://techcommunity.microsoft.com/t5/azure-security-center/become-an-azure-security-center-ninja/ba-p/1608761" data-linktype="external" target="az-portal" class="has-external-link-indicator)

[Microsoft Tech Community Security Webinars](https://techcommunity.microsoft.com/t5/microsoft-security-and/security-community-webinars/ba-p/927888" data-linktype="external" target="az-portal" class="has-external-link-indicator)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-azure-assets-to-azure-defender/6-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender](https://learn.microsoft.com/en-us/training/modules/connect-azure-assets-to-azure-defender/6-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender)*