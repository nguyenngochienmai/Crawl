---
title: Introduction
learning_path: SC-200: Mitigate threats using Microsoft Defender for Cloud
module_number: 28
url: https://learn.microsoft.com/en-us/training/modules/understand-azure-defender-cloud-workload-protection/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender
type: introduction
crawled_at: 2025-11-25T18:29:21.141518
---

# Introduction

> Introduction

Microsoft Defender for Cloud brings advanced intelligent protection for your Azure and hybrid resources and workloads. Enabling Defender for Cloud provides a range of extra security features.

You're the security operations team member working with the application and infrastructure teams designing the resource architecture for the new web application that uses containers and Azure SQL. You're responsible for ensuring the workloads are protected with Microsoft Defender for Cloud and provide options for non-protected workloads.

Learn about the protections and detections provided by Microsoft Defender for Cloud for each cloud workload.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/understand-azure-defender-cloud-workload-protection/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender](https://learn.microsoft.com/en-us/training/modules/understand-azure-defender-cloud-workload-protection/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender)*