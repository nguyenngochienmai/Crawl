---
title: Summary and resources
learning_path: SC-200: Mitigate threats using Microsoft Defender for Cloud
module_number: 20
url: https://learn.microsoft.com/en-us/training/modules/connect-non-azure-machines-to-azure-defender/7-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender
type: summary
crawled_at: 2025-11-25T18:26:23.535911
---

# Summary and resources

> Summary and resources

You learned how Microsoft Defender for Cloud can protect hybrid workloads, including on-premises, Amazon Web Services (AWS), and Google Cloud Platform (GCP).

You're now able to:

- Connect non-Azure machines to Microsoft Defender for Cloud
- Connect AWS accounts to Microsoft Defender for Cloud
- Connect GCP accounts to Microsoft Defender for Cloud


## Learn more

You can learn more by reviewing the following.

[Become an Microsoft Defender for Cloud Ninja (microsoft.com)](https://techcommunity.microsoft.com/t5/azure-security-center/become-an-azure-security-center-ninja/ba-p/1608761" data-linktype="external" target="az-portal" class="has-external-link-indicator)

[Microsoft Tech Community Security Webinars](https://techcommunity.microsoft.com/t5/microsoft-security-and/security-community-webinars/ba-p/927888" data-linktype="external" target="az-portal" class="has-external-link-indicator)

To learn more about connecting non-Azure resources to Microsoft Defender for Cloud, go to the *Get started/Deploy* section of the Microsoft Defender for Cloud documentation:

- Microsoft Defender for Cloud documentation


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-non-azure-machines-to-azure-defender/7-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender](https://learn.microsoft.com/en-us/training/modules/connect-non-azure-machines-to-azure-defender/7-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender)*