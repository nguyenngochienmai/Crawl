---
title: Summary and resources
learning_path: SC-200: Mitigate threats using Microsoft Defender for Cloud
module_number: 48
url: https://learn.microsoft.com/en-us/training/modules/remediate-azure-defender-security-alerts/8-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender
type: summary
crawled_at: 2025-11-25T18:35:04.924758
---

# Summary and resources

> Summary and resources

You should have learned how Microsoft Defender for Cloud provides a purpose-driven user interface to manage and investigate security incidents and alerts across protected resources.  The alert includes actions to take to remediate the threat and steps to prevent future attacks.

You should now be able to:

- Describe alerts in Microsoft Defender for Cloud
- Remediate alerts in Microsoft Defender for Cloud
- Automate responses in Microsoft Defender for Cloud


## Learn more

You can learn more by reviewing the following.

[Become a Microsoft Defender for Cloud Ninja (microsoft.com)](https://techcommunity.microsoft.com/t5/azure-security-center/become-an-azure-security-center-ninja/ba-p/1608761" data-linktype="external" target="az-portal" class="has-external-link-indicator)

[Microsoft Tech Community Security Webinars](https://techcommunity.microsoft.com/t5/microsoft-security-and/security-community-webinars/ba-p/927888" data-linktype="external" target="az-portal" class="has-external-link-indicator)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/remediate-azure-defender-security-alerts/8-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender](https://learn.microsoft.com/en-us/training/modules/remediate-azure-defender-security-alerts/8-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender)*