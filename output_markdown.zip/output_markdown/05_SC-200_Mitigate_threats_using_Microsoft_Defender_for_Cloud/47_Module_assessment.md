---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Defender for Cloud
module_number: 47
url: https://learn.microsoft.com/en-us/training/modules/remediate-azure-defender-security-alerts/7-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender
type: quiz
crawled_at: 2025-11-25T18:32:44.073554
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "Defender for Cloud employs which advanced security analytics?",
"options": [
"Biometric analytics",
"Power BI",
"Behavioral analytics"
],
"correct\_answers": [
"Behavioral analytics"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "Which Azure technology is used to automate remediation?",
"options": [
"Azure Functions",
"Azure Batch",
"Azure Logic Apps"
],
"correct\_answers": [
"Azure Logic Apps"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "If available, which report provides Attackers tactics, tools, and procedures?",
"options": [
"Threat Intelligence",
"Secure Score",
"Incident"
],
"correct\_answers": [
"Threat Intelligence"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/remediate-azure-defender-security-alerts/7-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender](https://learn.microsoft.com/en-us/training/modules/remediate-azure-defender-security-alerts/7-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender)*