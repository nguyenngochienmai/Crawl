---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Defender for Cloud
module_number: 26
url: https://learn.microsoft.com/en-us/training/modules/manage-cloud-security-posture-management/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender
type: quiz
crawled_at: 2025-11-25T18:27:10.548799
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "To automatically remediate a recommendation, select which option?",
"options": [
"Respond",
"Remediate",
"Fix"
],
"correct\_answers": [
"Fix"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "By default, which security policy is assigned to each subscription?",
"options": [
"SOC TSP",
"Azure Security Benchmark",
"ISO 27001:2013"
],
"correct\_answers": [
"Azure Security Benchmark"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "Defender for Cloud initiatives are defined in?",
"options": [
"Azure Policy",
"Secure Score",
"Workbooks"
],
"correct\_answers": [
"Azure Policy"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/manage-cloud-security-posture-management/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender](https://learn.microsoft.com/en-us/training/modules/manage-cloud-security-posture-management/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender)*