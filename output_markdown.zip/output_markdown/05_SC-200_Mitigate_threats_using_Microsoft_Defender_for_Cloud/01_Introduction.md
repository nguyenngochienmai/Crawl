---
title: Introduction
learning_path: SC-200: Mitigate threats using Microsoft Defender for Cloud
module_number: 1
url: https://learn.microsoft.com/en-us/training/modules/what-is-azure-defender/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender
type: introduction
crawled_at: 2025-11-25T18:19:18.843071
---

# Introduction

> Introduction

Microsoft Defender for Cloud provides Azure and hybrid cloud workload protection and security posture management.

You're a Security Operations Analyst working at a company that uses Microsoft Defender for Cloud. You're responsible for implementing cloud workload protections provided by Microsoft Defender for Cloud.

You need an overview of what resources can be protected by Microsoft Defender for Cloud. You also want to have a basic understanding of the features provided by Microsoft Defender for Cloud.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/what-is-azure-defender/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender](https://learn.microsoft.com/en-us/training/modules/what-is-azure-defender/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender)*