---
title: Exercise – Microsoft Defender for Cloud interactive guide
learning_path: SC-200: Mitigate threats using Microsoft Defender for Cloud
module_number: 4
url: https://learn.microsoft.com/en-us/training/modules/what-is-azure-defender/4-exercise-azure-security-center-interactive-guide/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender
type: exercise
crawled_at: 2025-11-25T18:19:43.808002
---

# Exercise – Microsoft Defender for Cloud interactive guide

> Exercise – Microsoft Defender for Cloud interactive guide

Now that you have an understanding of Microsoft Defender for Cloud see it in action.

Select the thumbnail image to start the lab simulation. When you're done, be sure to return to this page so you can continue learning.


![Screenshot of the simulation page.](https://learn.microsoft.com/training/wwl-sci/what-is-azure-defender/media/lab-simulation-enable-microsoft-defender-for-cloud.png)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/what-is-azure-defender/4-exercise-azure-security-center-interactive-guide/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender](https://learn.microsoft.com/en-us/training/modules/what-is-azure-defender/4-exercise-azure-security-center-interactive-guide/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender)*