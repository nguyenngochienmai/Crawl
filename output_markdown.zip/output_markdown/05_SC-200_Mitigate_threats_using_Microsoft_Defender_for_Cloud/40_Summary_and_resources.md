---
title: Summary and resources
learning_path: SC-200: Mitigate threats using Microsoft Defender for Cloud
module_number: 40
url: https://learn.microsoft.com/en-us/training/modules/understand-azure-defender-cloud-workload-protection/14-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender
type: summary
crawled_at: 2025-11-25T18:31:47.090164
---

# Summary and resources

> Summary and resources

You learned how Microsoft Defender for Cloud brings advanced, intelligent protection for your Azure and hybrid resources and workloads. Enabling Microsoft Defender for Cloud brings a range of extra security features.

You should now be able to:

- Explain which workloads are protected by Microsoft Defender for Cloud
- Describe the benefits of the protections offered by Microsoft Defender Cloud
- Explain how Microsoft Defender for Cloud protections function


## Learn more

You can learn more by reviewing the following.

[Become an Microsoft Defender for Cloud Ninja (microsoft.com)](https://techcommunity.microsoft.com/t5/azure-security-center/become-an-azure-security-center-ninja/ba-p/1608761" data-linktype="external" target="az-portal" class="has-external-link-indicator)

[Microsoft Tech Community Security Webinars](https://techcommunity.microsoft.com/t5/microsoft-security-and/security-community-webinars/ba-p/927888" data-linktype="external" target="az-portal" class="has-external-link-indicator)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/understand-azure-defender-cloud-workload-protection/14-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender](https://learn.microsoft.com/en-us/training/modules/understand-azure-defender-cloud-workload-protection/14-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender)*