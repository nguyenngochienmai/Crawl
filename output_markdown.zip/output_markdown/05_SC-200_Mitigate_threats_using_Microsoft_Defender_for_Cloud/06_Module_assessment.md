---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Defender for Cloud
module_number: 6
url: https://learn.microsoft.com/en-us/training/modules/what-is-azure-defender/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender
type: quiz
crawled_at: 2025-11-25T18:20:00.007970
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "Which of the following describe Microsoft Defender for Cloud's primary role?",
"options": [
"Cloud security facilitation",
"Cloud workload protection",
"Cloud configuration management"
],
"correct\_answers": [
"Cloud workload protection"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "Which Microsoft Defender for Cloud feature enables you to see the topology of your workloads?",
"options": [
"Inventory",
"Secure Score",
"Network map"
],
"correct\_answers": [
"Network map"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "To make sure Microsoft Defender for Cloud covers all resources in a Subscription, which option do you enable?",
"options": [
"Automatic provisioning",
"Continuous assessments",
"Coverage type"
],
"correct\_answers": [
"Automatic provisioning"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/what-is-azure-defender/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender](https://learn.microsoft.com/en-us/training/modules/what-is-azure-defender/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender)*