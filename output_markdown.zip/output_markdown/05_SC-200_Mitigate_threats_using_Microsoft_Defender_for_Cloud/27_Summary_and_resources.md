---
title: Summary and resources
learning_path: SC-200: Mitigate threats using Microsoft Defender for Cloud
module_number: 27
url: https://learn.microsoft.com/en-us/training/modules/manage-cloud-security-posture-management/7-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender
type: summary
crawled_at: 2025-11-25T18:29:13.707584
---

# Summary and resources

> Summary and resources

Microsoft Defender for Cloud provides a hybrid cloud security posture management.

Security posture management includes:

- Security recommendations
- Secure Score
- Regulatory Compliance
- Azure Security Benchmark

You should now be able to:

- Review your regulator compliance
- Review your Secure Score
- Implement security recommendations


## Learn more

You can learn more by reviewing the following.

[Become a Microsoft Defender for Cloud Ninja (microsoft.com)](https://techcommunity.microsoft.com/t5/azure-security-center/become-an-azure-security-center-ninja/ba-p/1608761" data-linktype="external" target="az-portal" class="has-external-link-indicator)

[Microsoft Tech Community Security Webinars](https://techcommunity.microsoft.com/t5/microsoft-security-and/security-community-webinars/ba-p/927888" data-linktype="external" target="az-portal" class="has-external-link-indicator)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/manage-cloud-security-posture-management/7-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender](https://learn.microsoft.com/en-us/training/modules/manage-cloud-security-posture-management/7-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender)*