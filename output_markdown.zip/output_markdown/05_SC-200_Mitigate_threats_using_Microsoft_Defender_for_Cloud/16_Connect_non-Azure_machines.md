---
title: Connect non-Azure machines
learning_path: SC-200: Mitigate threats using Microsoft Defender for Cloud
module_number: 16
url: https://learn.microsoft.com/en-us/training/modules/connect-non-azure-machines-to-azure-defender/3-connect-non-azure-machines/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender
type: content
crawled_at: 2025-11-25T18:24:30.514760
---

# Connect non-Azure machines

> Connect non-Azure machines

Microsoft Defender for Cloud can monitor the security posture of your non-Azure computers, but first, you need to connect them to Azure.

There are several different ways you can connect your existing Windows and Linux machines to Azure Arc:

- Using Azure Arc enabled servers (recommended)
- Azure Arc-enabled VMware vSphere
- Azure Arc-enabled System Center Virtual Machine Manager (SCVMM)
- Azure Local


## Add non-Azure machines with Azure Arc

Azure Arc enabled servers is the preferred way of adding your non-Azure machines to Defender for Cloud. A machine with Azure Arc enabled servers becomes an Azure resource and appears in Defender for Cloud with recommendations like your other Azure resources. In addition, Azure Arc enabled servers provides enhanced capabilities such as the option to enable guest configuration policies on the machine, deploy the Azure Monitor agent as an extension, simplify deployment with other Azure services, and more.


### What is Azure Arc enabled servers?

Azure Arc enabled servers allows you to manage your Windows and Linux machines hosted outside of Azure, on your corporate network, or other cloud providers, just like you manage native Azure virtual machines. When a hybrid machine is connected to Azure, it becomes a connected machine and is treated as a resource in Azure. Each connected machine has a Resource ID, is included in a resource group, and benefits from standard Azure constructs such as Azure Policy and applying tags. Service providers who manage a customer's on-premises infrastructure can manage their hybrid machines just like they do today with native Azure resources, across multiple customer environments, using Azure Lighthouse with Azure Arc.

To deliver this experience with your hybrid machines hosted outside of Azure, the *Azure Connected Machine agent* needs to be installed on each machine that you plan on connecting to Azure. **This agent doesn't replace the Azure Monitor Agent**. The Azure Monitor Agent for Windows and Linux is required when you want to proactively monitor the OS and workloads running on the machine. You can then manage the machines using Automation runbooks, solutions like Update Management, or use other Azure services like Defender for Cloud.


## Onboard non-Azure machines with the Azure Connected Machine agent

Connecting machines in your hybrid environment directly with Azure can be accomplished using different methods, depending on your requirements and the tools you prefer to use.


### Onboarding methods

The following table highlights each method so you can determine which works best for your deployment. For detailed information, follow the links to view the steps for each article.

| Method | Description |
| --- | --- |
| Interactively | Manually install the agent on a single or small number of machines by connecting machines using a deployment script. From the Azure portal, you can generate a script and execute it on the machine to automate the install and configuration steps of the agent. |
| Interactively | Connect machines from Windows Admin Center |
| Interactively | Connect Windows Servers machines to Azure through Azure Arc Setup |
| Interactively or at scale | Connect machines using PowerShell |
| At scale | Connect machines using a service principal to install the agent at scale non-interactively. |
| At scale | Connect machines by running PowerShell scripts with Configuration Manager |
| At scale | Connect machines with a Configuration Manager custom task sequence |
| At scale | Connect Windows machines using Group Policy |
| At scale | Connect machines from Automation Update Management to create a service principal that installs and configures the agent for multiple machines managed with Azure Automation Update Management to connect machines non-interactively. |
| At scale | Install the Arc agent on VMware VMs at scale using Arc enabled VMware vSphere. Arc enabled VMware vSphere allows you to connect your VMware vCenter server to Azure, automatically discover your VMware VMs, and install the Arc agent on them. Requires VMware tools on VMs. |
| At scale | Install the Arc agent on SCVMM VMs at scale using Arc-enabled System Center Virtual Machine Manager. Arc-enabled System Center Virtual Machine Manager allows you to connect your SCVMM management server to Azure, automatically discover your SCVMM VMs, and install the Arc agent on them. |
| At scale | Connect your AWS cloud through the multicloud connector enabled by Azure Arc and enable the Arc onboarding solution to autodiscover and onboard EC2 VMs. |

The Azure Arc Setup feature only applies to Windows Server 2022 and later. It was released in the [Cumulative Update of 10/10/2023](https://support.microsoft.com/topic/october-10-2023-kb5031364-os-build-20348-2031-7f1d69e7-c468-4566-887a-1902af791bbc" data-linktype="external).


## Supported cloud operations

With Azure Arc-enabled servers, you can perform many operational functions, just as you would with native Azure virtual machines. Below are some of the key supported actions for connected machines.

- Govern:

Assign Azure machine configurations to audit settings inside the machine. To understand the cost of using Azure Machine Configuration policies with Arc-enabled servers, see Azure Policy pricing guide.
- Assign Azure machine configurations to audit settings inside the machine. To understand the cost of using Azure Machine Configuration policies with Arc-enabled servers, see Azure Policy pricing guide.
- Protect:

Protect non-Azure servers with Microsoft Defender for Endpoint, included through Microsoft Defender for Cloud, for threat detection, for vulnerability management, and to proactively monitor for potential security threats. Microsoft Defender for Cloud presents the alerts and remediation suggestions from the threats detected.
Use Microsoft Sentinel to collect security-related events and correlate them with other data sources.
- Protect non-Azure servers with Microsoft Defender for Endpoint, included through Microsoft Defender for Cloud, for threat detection, for vulnerability management, and to proactively monitor for potential security threats. Microsoft Defender for Cloud presents the alerts and remediation suggestions from the threats detected.
- Use Microsoft Sentinel to collect security-related events and correlate them with other data sources.
- Configure:

Use Azure Automation for frequent and time-consuming management tasks using PowerShell and Python runbooks. Assess configuration changes for installed software, Microsoft services, Windows registry and files, and Linux daemons using the Azure Monitor agent for change tracking and inventory.
Use Azure Update Manager to manage operating system updates for your Windows and Linux servers. Automate onboarding and configuration of a set of Azure services when you use Azure Automanage.
Perform post-deployment configuration and automation tasks using supported Arc-enabled servers VM extensions for your non-Azure Windows or Linux machine.
- Use Azure Automation for frequent and time-consuming management tasks using PowerShell and Python runbooks. Assess configuration changes for installed software, Microsoft services, Windows registry and files, and Linux daemons using the Azure Monitor agent for change tracking and inventory.
- Use Azure Update Manager to manage operating system updates for your Windows and Linux servers. Automate onboarding and configuration of a set of Azure services when you use Azure Automanage.
- Perform post-deployment configuration and automation tasks using supported Arc-enabled servers VM extensions for your non-Azure Windows or Linux machine.
- Monitor:

Monitor operating system performance and discover application components to monitor processes and dependencies with other resources using VM insights.
Collect other log data, such as performance data and events, from the operating system or workloads running on the machine with the Azure Monitor Agent. This data is stored in a Log Analytics workspace.
- Monitor operating system performance and discover application components to monitor processes and dependencies with other resources using VM insights.
- Collect other log data, such as performance data and events, from the operating system or workloads running on the machine with the Azure Monitor Agent. This data is stored in a Log Analytics workspace.

- Assign Azure machine configurations to audit settings inside the machine. To understand the cost of using Azure Machine Configuration policies with Arc-enabled servers, see Azure Policy pricing guide.

- Protect non-Azure servers with Microsoft Defender for Endpoint, included through Microsoft Defender for Cloud, for threat detection, for vulnerability management, and to proactively monitor for potential security threats. Microsoft Defender for Cloud presents the alerts and remediation suggestions from the threats detected.
- Use Microsoft Sentinel to collect security-related events and correlate them with other data sources.

- Use Azure Automation for frequent and time-consuming management tasks using PowerShell and Python runbooks. Assess configuration changes for installed software, Microsoft services, Windows registry and files, and Linux daemons using the Azure Monitor agent for change tracking and inventory.
- Use Azure Update Manager to manage operating system updates for your Windows and Linux servers. Automate onboarding and configuration of a set of Azure services when you use Azure Automanage.
- Perform post-deployment configuration and automation tasks using supported Arc-enabled servers VM extensions for your non-Azure Windows or Linux machine.

- Monitor operating system performance and discover application components to monitor processes and dependencies with other resources using VM insights.
- Collect other log data, such as performance data and events, from the operating system or workloads running on the machine with the Azure Monitor Agent. This data is stored in a Log Analytics workspace.

Log data collected and stored in a Log Analytics workspace from the hybrid machine contains properties specific to the machine, such as a Resource ID, to support [resource-context](/en-us/azure/azure-monitor/logs/manage-access#access-mode" data-linktype="absolute-path) log access.

Watch this video to learn more about Azure monitoring, security, and update services across hybrid and multicloud environments.


🎥 **Video**: [https://www.youtube-nocookie.com/embed/mJnmXBrU1ao](https://www.youtube-nocookie.com/embed/mJnmXBrU1ao)

To connect your non-Azure machines with Azure Arc enabled servers [Follow this Quickstart](/en-us/azure/azure-arc/servers/learn/quick-enable-hybrid-vm" data-linktype="absolute-path).


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-non-azure-machines-to-azure-defender/3-connect-non-azure-machines/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender](https://learn.microsoft.com/en-us/training/modules/connect-non-azure-machines-to-azure-defender/3-connect-non-azure-machines/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender)*