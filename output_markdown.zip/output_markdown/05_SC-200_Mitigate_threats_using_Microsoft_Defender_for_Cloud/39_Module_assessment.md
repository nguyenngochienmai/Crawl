---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Defender for Cloud
module_number: 39
url: https://learn.microsoft.com/en-us/training/modules/understand-azure-defender-cloud-workload-protection/13-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender
type: quiz
crawled_at: 2025-11-25T18:30:51.534029
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "What is a protection provided by Microsoft Defender for DNS?",
"options": [
"Malware communicating with C&C server",
"Malware encrypting data on a Device",
"Malware enumerating user on a Device"
],
"correct\_answers": [
"Malware communicating with C&C server"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "Microsoft Defender for Containers does which of the following?",
"options": [
"Environmental hardening, Vulnerability assessment, and endpoint management",
"Environmental hardening, User risk management, and Run-time threat protection",
"Environmental hardening, Vulnerability assessment, and Run-time threat protection"
],
"correct\_answers": [
"Environmental hardening, Vulnerability assessment, and Run-time threat protection"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "Which feature of Microsoft Defender for Servers examines files and registries of the operating system, application software, and others for changes that might indicate an attack?",
"options": [
"Adaptive application controls",
"Adaptive network hardening",
"File integrity monitoring"
],
"correct\_answers": [
"File integrity monitoring"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/understand-azure-defender-cloud-workload-protection/13-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender](https://learn.microsoft.com/en-us/training/modules/understand-azure-defender-cloud-workload-protection/13-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender)*