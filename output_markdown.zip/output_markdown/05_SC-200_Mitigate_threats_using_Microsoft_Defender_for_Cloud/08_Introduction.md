---
title: Introduction
learning_path: SC-200: Mitigate threats using Microsoft Defender for Cloud
module_number: 8
url: https://learn.microsoft.com/en-us/training/modules/connect-azure-assets-to-azure-defender/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender
type: introduction
crawled_at: 2025-11-25T18:21:39.880514
---

# Introduction

> Introduction

Resource protection in Microsoft Defender for Cloud can be automatically configured with autoprovisioning or may be manually deployed.

You're a Security Operations Analyst working at a company that is implementing cloud workload protection with Microsoft Defender for Cloud. Your job is to ensure Defender for Cloud automatically protects the Azure resources.

Your organization has a few Azure virtual machines that aren't part of the autoprovisioning scheme. You must manually configure protection for these Azure resources.

Learn how to connect your various Azure assets to Microsoft Defender for Cloud to detect threats.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-azure-assets-to-azure-defender/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender](https://learn.microsoft.com/en-us/training/modules/connect-azure-assets-to-azure-defender/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender)*