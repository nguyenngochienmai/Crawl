---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Defender for Cloud
module_number: 19
url: https://learn.microsoft.com/en-us/training/modules/connect-non-azure-machines-to-azure-defender/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender
type: quiz
crawled_at: 2025-11-25T18:24:57.499116
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "Which is an option to connect your non-Azure computers?",
"options": [
"Windows Store",
"Using Azure Arc enabled servers",
"From an Excel spreadsheet"
],
"correct\_answers": [
"Using Azure Arc enabled servers"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "Which resource can Microsoft Defender for Cloud protect in a hybrid environment?",
"options": [
"Word Documents",
"SQL Databases",
"Cosmos DB"
],
"correct\_answers": [
"SQL Databases"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "Which Cloud provider has a Cloud connector in Security Center?",
"options": [
"IBM Cloud",
"GCP",
"Oracle"
],
"correct\_answers": [
"GCP"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-non-azure-machines-to-azure-defender/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender](https://learn.microsoft.com/en-us/training/modules/connect-non-azure-machines-to-azure-defender/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender)*