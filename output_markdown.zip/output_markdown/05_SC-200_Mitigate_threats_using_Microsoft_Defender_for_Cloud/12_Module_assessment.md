---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Defender for Cloud
module_number: 12
url: https://learn.microsoft.com/en-us/training/modules/connect-azure-assets-to-azure-defender/5-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender
type: quiz
crawled_at: 2025-11-25T18:22:12.863793
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "Which is a Windows security events configuration?",
"options": [
"Reasonable",
"Maximum",
"Minimal"
],
"correct\_answers": [
"Minimal"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "What should you install on a new Azure Windows VM if you aren't using auto provisioning?",
"options": [
"Log Analytics Agent",
"Sysmon",
"Windows Firewall"
],
"correct\_answers": [
"Log Analytics Agent"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "Which of these selections is an auto provisioning extension?",
"options": [
"Policy Add-on for Kubernetes",
"Windows Events",
"Policy for Azure Policy"
],
"correct\_answers": [
"Policy Add-on for Kubernetes"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/connect-azure-assets-to-azure-defender/5-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender](https://learn.microsoft.com/en-us/training/modules/connect-azure-assets-to-azure-defender/5-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender)*