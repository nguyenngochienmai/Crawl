---
title: Understand Microsoft Defender for DNS
learning_path: SC-200: Mitigate threats using Microsoft Defender for Cloud
module_number: 36
url: https://learn.microsoft.com/en-us/training/modules/understand-azure-defender-cloud-workload-protection/9-understand-azure-defender-for-dns/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender
type: content
crawled_at: 2025-11-25T18:30:26.594886
---

# Understand Microsoft Defender for DNS

> Understand Microsoft Defender for DNS

Azure DNS is a hosting service for DNS domains that provides name resolution by using Microsoft Azure infrastructure. By hosting your domains in Azure, you can manage your DNS records by using the same credentials, APIs, tools, and billing as your other Azure services.

Microsoft Defender for DNS provides an extra layer of protection for your cloud resources by:

- Continuously monitoring all DNS queries from your Azure resources
- Running advanced security analytics to alert you about suspicious activity

Continuously monitoring all DNS queries from your Azure resources

Running advanced security analytics to alert you about suspicious activity


## What are the benefits of Microsoft Defender for DNS?

Defender for DNS protects against issues including:

- Data exfiltration from your Azure resources using DNS tunneling
- Malware communicating with C&C server
- Communication with malicious domains as phishing and crypto mining
- DNS attacks - communication with malicious DNS resolvers

Data exfiltration from your Azure resources using DNS tunneling

Malware communicating with C&amp;C server

Communication with malicious domains as phishing and crypto mining

DNS attacks - communication with malicious DNS resolvers


---

*Source: [https://learn.microsoft.com/en-us/training/modules/understand-azure-defender-cloud-workload-protection/9-understand-azure-defender-for-dns/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender](https://learn.microsoft.com/en-us/training/modules/understand-azure-defender-cloud-workload-protection/9-understand-azure-defender-for-dns/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-azure-defender)*