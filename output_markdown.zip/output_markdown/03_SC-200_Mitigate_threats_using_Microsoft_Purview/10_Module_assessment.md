---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Purview
module_number: 10
url: https://learn.microsoft.com/en-us/training/modules/purview-data-loss-prevention-alerts/knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview
type: quiz
crawled_at: 2025-11-25T17:16:07.238319
---

# Module assessment

> Knowledge check

Your organization uses Microsoft Purview and Microsoft Defender XDR to analyze sensitive data activity. A data loss prevention (DLP) policy is configured to detect when employees upload financial records to personal cloud storage.

You're a security analyst reviewing the following situation:

- A user triggered an alert after uploading a file named "Budget_2025.xlsx" to a personal Dropbox account.
- The alert appears in both Microsoft Purview and Defender XDR.
- In Microsoft Defender XDR, the alert is grouped with others showing the same user downloaded multiple files from SharePoint earlier that day.
- The Sensitive info types tab confirms the file contained financial account numbers.

Insider Risk Management is enabled. The user's user activity summary shows a pattern of exfiltration attempts over the last 60 days.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/purview-data-loss-prevention-alerts/knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview](https://learn.microsoft.com/en-us/training/modules/purview-data-loss-prevention-alerts/knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview)*