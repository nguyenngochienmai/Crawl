---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Purview
module_number: 41
url: https://learn.microsoft.com/en-us/training/modules/purview-ediscovery-search/knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview
type: quiz
crawled_at: 2025-11-25T17:46:27.043285
---

# Module assessment

> Check your knowledge.



---

*Source: [https://learn.microsoft.com/en-us/training/modules/purview-ediscovery-search/knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview](https://learn.microsoft.com/en-us/training/modules/purview-ediscovery-search/knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview)*