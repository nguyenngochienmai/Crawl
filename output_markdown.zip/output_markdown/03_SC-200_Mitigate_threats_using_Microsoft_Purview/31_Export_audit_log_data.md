---
title: Export audit log data
learning_path: SC-200: Mitigate threats using Microsoft Purview
module_number: 31
url: https://learn.microsoft.com/en-us/training/modules/purview-audit-search-investigate/audit-export/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview
type: content
crawled_at: 2025-11-25T17:40:22.131011
---

# Export audit log data

> Export audit log data.

Both the Standard and Premium versions of Microsoft Purview Audit let you export audit logs to CSV. This capability supports detailed analysis and compliance reporting by allowing you to work with audit data outside the portal.


## Export audit log search results

After running an audit log search in the Microsoft Purview portal, you can export the results for offline analysis.

1. Run your audit search with the desired filters.
2. On the search results page, select Export to download the audit records to a CSV file.
3. Once the export finishes, save the file locally.

You can export up to 50,000 entries from a single search. If your results exceed this, narrow the date range or apply more filters.
4. You can export up to 50,000 entries from a single search. If your results exceed this, narrow the date range or apply more filters.

Run your audit search with the desired filters.

On the search results page, select **Export** to download the audit records to a CSV file.


![Screenshot showing where to select Export to export data.](https://learn.microsoft.com/training/wwl-sci/purview-audit-search-investigate/media/audit-export-audit-search-results.png)

Once the export finishes, save the file locally.

- You can export up to 50,000 entries from a single search. If your results exceed this, narrow the date range or apply more filters.


## Transform audit log data using Power Query Editor

You can make the exported CSV data easier to work with by transforming it in Excel's Power Query Editor.

1. Open a blank Excel workbook, go to the Data tab, and select From Text/CSV to open your exported file.
2. When the CSV opens, select Transform Data to start editing in Power Query.
3. Right-click AuditData, select Transform, then choose JSON. This parses the data into a readable format.
4. Select the expand icon in the AuditData column to view JSON properties.
5. If only some properties are visible, select Load more.
6. Deselect unneeded properties to simplify your view.
7. Choose whether to include the original column name as a prefix.
8. Select OK to apply the transformation.
9. On the Home tab, select Close & Load to return the transformed data to Excel.

Open a blank Excel workbook, go to the **Data** tab, and select **From Text/CSV** to open your exported file.


![Screenshot showing the From Text/CSV button in Excel.](https://learn.microsoft.com/training/wwl-sci/purview-audit-search-investigate/media/json-transform-open-csv-file.png)

When the CSV opens, select **Transform Data** to start editing in Power Query.


![Screenshot showing the Transform Data button in Excel.](https://learn.microsoft.com/training/wwl-sci/purview-audit-search-investigate/media/json-open-power-query.png)

Right-click **AuditData**, select **Transform**, then choose **JSON**. This parses the data into a readable format.


![Screenshot showing where to select Transform then JSON to parse data.](https://learn.microsoft.com/training/wwl-sci/purview-audit-search-investigate/media/json-transform.png)

Select the expand icon in the **AuditData** column to view JSON properties.


![Screenshot showing the expand icon.](https://learn.microsoft.com/training/wwl-sci/purview-audit-search-investigate/media/json-transform-expand-icon.png)

If only some properties are visible, select **Load more**.


![Screenshot showing where to select Load more to display the full list of properties.](https://learn.microsoft.com/training/wwl-sci/purview-audit-search-investigate/media/json-transform-load-json-properties.png)

Deselect unneeded properties to simplify your view.

Choose whether to include the original column name as a prefix.

Select **OK** to apply the transformation.

On the **Home** tab, select **Close &amp; Load** to return the transformed data to Excel.


## Use PowerShell to search and export audit log records

For more control over your audit searches and exports, use the `Search-UnifiedAuditLog` cmdlet in Exchange Online PowerShell.


### Example: Export SharePoint sharing operations


```text
$auditlog = Search-UnifiedAuditLog -StartDate 06/01/2019 -EndDate 06/30/2019 -RecordType SharePointSharingOperation
$auditlog | Select-Object CreationDate, UserIds, RecordType, AuditData | Export-Csv -Path C:AuditLogsSharePointAudit.csv -NoTypeInformation
```

To append more data:


```text
$auditlog = Search-UnifiedAuditLog -StartDate 06/01/2019 -EndDate 06/30/2019 -RecordType SharePointFileOperation
$auditlog | Select-Object CreationDate, UserIds, RecordType, AuditData | Export-Csv -Append -Path C:AuditLogsSharePointAudit.csv -NoTypeInformation
```


## Tips for exporting and reviewing audit data

- Filter by RecordType to focus on specific workloads.
- Filter by Operations to narrow results to key actions, such as file sharing or deletion.
- Use Power Query transformations to make JSON data in the AuditData column easier to read.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/purview-audit-search-investigate/audit-export/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview](https://learn.microsoft.com/en-us/training/modules/purview-audit-search-investigate/audit-export/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview)*