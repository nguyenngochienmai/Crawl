---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Purview
module_number: 33
url: https://learn.microsoft.com/en-us/training/modules/purview-audit-search-investigate/knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview
type: quiz
crawled_at: 2025-11-25T17:40:39.249768
---

# Module assessment

> Knowledge check

Choose the best response for each question.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "What is the main difference between Audit (Standard) and Audit (Premium) regarding audit log retention periods?",
"options": [
"Audit (Standard) offers a maximum retention period of 180 days.",
"Audit (Standard) supports 10-year retention policies.",
"Both versions offer indefinite retention."
],
"correct\_answers": [
"Audit (Standard) offers a maximum retention period of 180 days."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "What step should be taken first before searching the audit log in Microsoft Purview?",
"options": [
"Install the latest updates for Microsoft 365.",
"Confirm audit log search is enabled.",
"Export the existing audit logs to a CSV file for backup."
],
"correct\_answers": [
"Confirm audit log search is enabled."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "What feature of Microsoft Purview Audit (Premium) is essential for managing sensitive communications securely?",
"options": [
"Standard data retention.",
"Basic audit logs.",
"MailItemsAccessed."
],
"correct\_answers": [
"MailItemsAccessed."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 4,
"question": "What is the primary purpose of exporting audit logs to CSV in Microsoft Purview Audit?",
"options": [
"To perform detailed data analysis and meet compliance reporting requirements.",
"To reduce the storage space used on servers.",
"To enhance the visual presentation of data."
],
"correct\_answers": [
"To perform detailed data analysis and meet compliance reporting requirements."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 5,
"question": "How are audit log retention policies prioritized in Microsoft Purview Audit (Premium) when conflicts occur?",
"options": [
"Based on the date the policy was created.",
"Alphabetically by policy name.",
"By a priority level set by the administrator."
],
"correct\_answers": [
"By a priority level set by the administrator."
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/purview-audit-search-investigate/knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview](https://learn.microsoft.com/en-us/training/modules/purview-audit-search-investigate/knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview)*