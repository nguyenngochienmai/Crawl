---
title: Summary and resources
learning_path: SC-200: Mitigate threats using Microsoft Purview
module_number: 42
url: https://learn.microsoft.com/en-us/training/modules/purview-ediscovery-search/summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview
type: summary
crawled_at: 2025-11-25T18:00:55.672088
---

# Summary and resources

> Summary and resources

Searching across Microsoft 365 is a key step in any investigation involving sensitive content. Whether you're reviewing potential data leaks, responding to legal requests, or analyzing internal communications, Microsoft Purview eDiscovery provides a structured way to find the content that matters.

In this module, you learned how to:

- Assign the appropriate roles to access eDiscovery and view case data
- Create an eDiscovery case and run content searches across mail, files, and messages
- Use filters, conditions, and Copilot to narrow your search and improve accuracy
- Evaluate results using statistical summaries or random samples

Once you've validated your search results, you can choose to export the data or add it to a review set, depending on the needs of your case.

By using Microsoft Purview eDiscovery, you're able to investigate user activity across Microsoft 365 in a secure, auditable, and repeatable way—supporting your organization's security, compliance, and incident response efforts.


## Resources

- Create a search query for a case in eDiscovery
- Use the condition builder to create search queries in eDiscovery
- Evaluate and refine search results in eDiscovery
- Export search results in eDiscovery


---

*Source: [https://learn.microsoft.com/en-us/training/modules/purview-ediscovery-search/summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview](https://learn.microsoft.com/en-us/training/modules/purview-ediscovery-search/summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview)*