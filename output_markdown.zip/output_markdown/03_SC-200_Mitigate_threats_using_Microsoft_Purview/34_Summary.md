---
title: Summary
learning_path: SC-200: Mitigate threats using Microsoft Purview
module_number: 34
url: https://learn.microsoft.com/en-us/training/modules/purview-audit-search-investigate/summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview
type: summary
crawled_at: 2025-11-25T17:45:30.701849
---

# Summary

> Summary

Securing sensitive data and meeting compliance requirements demands clear visibility into user and admin activity. In this module, you learned how Microsoft Purview Audit can help identify unusual access patterns and maintain regulatory compliance.

Here's what you learned:

- Identified the differences between Microsoft Purview Audit (Standard) and Audit (Premium) to meet compliance needs.
- Configured and managed Microsoft Purview Audit to create detailed logs for in-depth analysis of data access.
- Conducted audits to uphold compliance and security standards.
- Investigated unusual access patterns using advanced tools in Purview Audit (Premium) and PowerShell, enhancing your understanding of potential security risks.
- Ensured regulatory compliance with proactive data management strategies, safeguarding sensitive information.

Without Microsoft Purview Audit, managing audit data at this scale would be time-consuming and prone to gaps, increasing the risk of missed incidents. Implementing it streamlines investigations, strengthens data protection, and supports compliance across your organization.


## Resources

- Learn about auditing solutions in Microsoft Purview
- Get started with auditing solutions
- Search the audit log
- Manage audit log retention policies
- Export, configure, and view audit log records
- Turn auditing on or off


## Use cases and scenarios

Explore how Microsoft Purview Audit can enhance security, manage compliance, and investigate threats through use cases and scenarios:

- Search the audit log to investigate common support issues
- Search the audit log for events in Microsoft Teams
- Use sharing auditing in the audit log
- Use Microsoft Purview Audit (Premium) to investigate compromised accounts
- Use a PowerShell script to search the audit log


---

*Source: [https://learn.microsoft.com/en-us/training/modules/purview-audit-search-investigate/summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview](https://learn.microsoft.com/en-us/training/modules/purview-audit-search-investigate/summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview)*