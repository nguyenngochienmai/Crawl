---
title: Prerequisites for using eDiscovery in Microsoft Purview
learning_path: SC-200: Mitigate threats using Microsoft Purview
module_number: 37
url: https://learn.microsoft.com/en-us/training/modules/purview-ediscovery-search/ediscovery-prerequisites/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview
type: content
crawled_at: 2025-11-25T17:45:52.356373
---

# Prerequisites for using eDiscovery in Microsoft Purview

> Prerequisites for using eDiscovery in Microsoft Purview.

Before using eDiscovery to search for content, certain roles and access must be assigned to ensure users can view cases, create searches, and export results. These prerequisites help maintain a secure and auditable investigation process.


## Required roles

**Global** and **Compliance Administrators** can't access eDiscovery cases or search user content unless they're explicitly assigned to the **eDiscovery Manager** or **eDiscovery Administrator** role group. This permission model ensures that access to sensitive data is intentional and auditable.

To access eDiscovery, users need to be assigned one of the following roles:

- eDiscovery Manager: Allows users to create and manage eDiscovery cases, run content searches, and export results.
- eDiscovery Administrator: Includes all eDiscovery Manager permissions, plus the ability to manage role assignments and settings across all cases.

These roles can be assigned in the Microsoft Purview portal under **Permissions &gt; Roles**.


## Assign users to eDiscovery roles

Administrators can assign users to eDiscovery roles by doing the following:

1. In the Microsoft Purview portal, select Settings > Roles and Scopes > Role groups.
2. Search for and select the appropriate eDiscovery role group.
3. Add users or groups to the role group.

Once assigned, users might need to sign out and sign back in to see the eDiscovery interface.


## Confirm access to eDiscovery

To verify that the role assignment was successful:

1. Open the Microsoft Purview portal.
2. In the left-hand navigation, select eDiscovery.
3. The Cases page should load. If not, confirm the user has been assigned the appropriate role and that the Microsoft 365 license includes eDiscovery access.

With the right roles and access in place, users can begin creating cases and searching for content across Microsoft 365 workloads.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/purview-ediscovery-search/ediscovery-prerequisites/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview](https://learn.microsoft.com/en-us/training/modules/purview-ediscovery-search/ediscovery-prerequisites/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview)*