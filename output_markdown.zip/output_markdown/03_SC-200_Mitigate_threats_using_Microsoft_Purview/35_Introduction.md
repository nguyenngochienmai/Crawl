---
title: Introduction
learning_path: SC-200: Mitigate threats using Microsoft Purview
module_number: 35
url: https://learn.microsoft.com/en-us/training/modules/purview-ediscovery-search/introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview
type: introduction
crawled_at: 2025-11-25T17:45:38.053458
---

# Introduction

> Introduction.

Information security administrators often need to investigate incidents involving sensitive or improperly shared content. Whether responding to a data leak, regulatory inquiry, or internal policy violation, the ability to locate and analyze content quickly is essential.

In this module, you take on the role of an information security administrator using Microsoft Purview eDiscovery to search for content across Microsoft 365 services. You'll work within an eDiscovery case to define data sources, build targeted queries, and validate search results before taking further action.

In this module, you:

- Assign roles and permissions needed to access eDiscovery
- Create a case and configure search criteria
- Search across Microsoft 365 workloads using keywords, conditions, and Copilot-assisted query generation
- Review and validate search results using samples or statistics

By the end of this module, you'll be able to locate content across Microsoft 365, evaluate the results, and prepare for next steps like exporting or adding data to a review set.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/purview-ediscovery-search/introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview](https://learn.microsoft.com/en-us/training/modules/purview-ediscovery-search/introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview)*