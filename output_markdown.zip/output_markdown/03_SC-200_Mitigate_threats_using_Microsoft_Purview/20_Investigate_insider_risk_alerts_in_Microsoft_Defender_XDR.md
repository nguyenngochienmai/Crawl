---
title: Investigate insider risk alerts in Microsoft Defender XDR
learning_path: SC-200: Mitigate threats using Microsoft Purview
module_number: 20
url: https://learn.microsoft.com/en-us/training/modules/purview-insider-risk-investigate-alerts/investigate-alerts-defender/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview
type: content
crawled_at: 2025-11-25T17:18:30.884908
---

# Investigate insider risk alerts in Microsoft Defender XDR

> Investigate insider risk alerts in Microsoft Defender XDR.

**Microsoft Defender Extended Detection and Response (XDR)** helps expand investigation capabilities for insider risk by integrating alerts from Microsoft Purview Insider Risk Management with other Microsoft security data. This combined view gives security operations center (SOC) analysts the context they need to assess user behavior, correlate risk signals, and take action across Microsoft 365 workloads.

Use this view to correlate insider risk alerts with data from other services like Microsoft Defender for Endpoint, Microsoft Entra ID, and Microsoft Purview Data Loss Prevention.


## Access insider risk alerts in Defender XDR

To review alerts in the [Microsoft Defender portal](https://security.microsoft.com/" data-linktype="external" target="az-portal" class="has-external-link-indicator):

1. Go to Investigation & response > Incidents & alerts > Incidents.
2. Use the Service source filter to select Microsoft Purview Insider Risk Management

Go to **Investigation &amp; response** &gt; **Incidents &amp; alerts** &gt; **Incidents**.

Use the **Service source** filter to select **Microsoft Purview Insider Risk Management**


![Screenshot showing the Incidents page being filtered to show Microsoft Purview Insider Risk Management incidents.](https://learn.microsoft.com/training/wwl-sci/purview-insider-risk-investigate-alerts/media/defender-insider-risk-incidents.png)

This filter shows alerts from Insider Risk Management and highlights when those alerts are grouped into incidents with alerts from other Microsoft tools.


## Understand the investigation view

When insider risk alerts appear in the Defender portal, they might be:

- Part of a unified incident that includes multiple alert types
- Listed individually in the alert queue for review
- Linked to other activity such as endpoint behavior or identity signals

Selecting an alert or incident provides details such as severity, classification, and alert mappings. You can also view the user entity page for a risk summary and associated activity.


## Review alert status and classification sync

Alert status and classification automatically sync between Microsoft Purview and Microsoft Defender:

| Microsoft Defender status | Insider Risk Management status |
| --- | --- |
| New, In progress | Needs review |
| Resolved | Dismissed or Confirmed (based on classification) |

How classification types align:

| Microsoft Defender classification | Insider Risk Management classification |
| --- | --- |
| True positive | Confirmed |
| Information, expected activity | Dismissed |
| False positive | Dismissed |

Updates to status, classification, and alert details reflect across both portals within about 30 minutes.


## Investigate insider risk activity with advanced hunting

Defender's **Advanced hunting** feature allows deeper investigation of insider risk activity using Kusto Query Language (KQL). Insider risk alerts and behavior logs are available in the following tables:

- AlertInfo: Alert metadata from multiple sources
- AlertEvidence: Linked entities such as files or users
- DataSecurityBehaviors: Policy-triggering behavioral patterns
- DataSecurityEvents: Detailed events from policy violations

These tables support cross-tool investigation. For example, you might query:


```text
DataSecurityEvents
| where FileName endswith ".zip"
| where ActionType == "FileUploaded"
```

You must be assigned the **Insider Risk Management Analyst** or **Investigator** role in Microsoft Purview to access this data.


## Requirements and setup

Before alerts appear in the Microsoft Defender portal:

The setting **Share user risk details with other security solutions** must be enabled in the Microsoft Purview portal. To enable this setting:

1. Go to the Microsoft Purview portal.
2. Select Settings > Insider Risk Management > Data sharing.
3. Enable Share user risk details with other security solutions.

Go to the [Microsoft Purview portal](https://purview.microsoft.com/" data-linktype="external" target="az-portal" class="has-external-link-indicator).

Select **Settings** &gt; **Insider Risk Management** &gt; **Data sharing**.

Enable **Share user risk details with other security solutions**.


![Screenshot showing where to enable data sharing in Microsoft Purview Insider Risk Management.](https://learn.microsoft.com/training/wwl-sci/purview-insider-risk-investigate-alerts/media/enable-data-sharing-insider-risk-settings.png)

Users must have roles in both Microsoft Purview and Microsoft Defender:

- Defender: Security Operator or Security Reader
- Purview: Insider Risk Management, Analyst, or Investigator

Licensing for both solutions is also required. See Microsoft documentation for details.


## Limitations

Not all insider risk data is available in Defender:

- Alerts created from custom detections
- Risky AI usage events
- Non-Microsoft app events
- Exfiltration via email
- Events that occurred before an alert was generated
- Excluded events based on policy settings

Viewing insider risk alerts in Microsoft Defender XDR helps bring together security signals across Microsoft 365. This integration supports broader investigations, faster triage, and more comprehensive incident response.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/purview-insider-risk-investigate-alerts/investigate-alerts-defender/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview](https://learn.microsoft.com/en-us/training/modules/purview-insider-risk-investigate-alerts/investigate-alerts-defender/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview)*