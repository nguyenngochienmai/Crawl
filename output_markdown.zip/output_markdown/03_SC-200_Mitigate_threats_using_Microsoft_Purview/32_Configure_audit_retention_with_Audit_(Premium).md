---
title: Configure audit retention with Audit (Premium)
learning_path: SC-200: Mitigate threats using Microsoft Purview
module_number: 32
url: https://learn.microsoft.com/en-us/training/modules/purview-audit-search-investigate/audit-premium-retention/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview
type: content
crawled_at: 2025-11-25T17:40:29.634422
---

# Configure audit retention with Audit (Premium)

> Configure audit retention with Audit (Premium).

Microsoft Purview Audit (Premium) enhances your ability to manage audit logs by extending how long they're retained. This capability is especially important for organizations that need to meet strict regulatory or internal compliance requirements.


## Audit log retention policy overview

In Microsoft Purview Audit (Premium), you can create and manage audit log retention policies that define how long audit records are kept. These policies can retain data for up to 10 years with the appropriate licensing.

Retention policies can be scoped by:

- All activities across one or more Microsoft 365 services
- Specific activities within a service, for all or selected users
- Priority level to control which policy applies when more than one could apply


## Default retention policy

Audit (Premium) provides a default retention policy that retains audit records from Microsoft Entra ID, Exchange, OneDrive, and SharePoint for one year. This default can't be modified, but you can create custom policies for other workloads or to set different durations for specific record types.


## Considerations for retention policies

Before creating a policy, keep in mind:

- Required role: You need the Organization Configuration role in the Microsoft Purview portal to create or edit policies.
- Policy limit: Each organization can have up to 50 retention policies.
- Licensing: Retention beyond 180 days requires Microsoft 365 E5, Office 365 E5, or an equivalent add-on license. Ten-year retention also requires a 10-year audit log retention add-on license.
- Policy priority: Custom policies override the default for covered records.
- Data retention timing: Retention is determined when the record is created. Policy or license changes affect only new records.


## Create an audit log retention policy

You can create retention policies in the Microsoft Purview portal.

1. Sign in to the Microsoft Purview portal with an account that has the Organization Configuration role.
2. Go to Solutions > Audit > Audit retention policies.
3. Select Create audit retention policy, then complete the fields:

Policy name: Unique name for the policy
Description: Optional short description
Users: Apply to all users or specific ones
Record type: Choose the type of audit record; multiple types can't have activity-specific selections
Duration: Choose the retention period (7 days to 10 years; over 1 year requires specific licensing)
Priority: Set the priority, where lower numbers have higher priority
4. Policy name: Unique name for the policy
5. Description: Optional short description
6. Users: Apply to all users or specific ones
7. Record type: Choose the type of audit record; multiple types can't have activity-specific selections
8. Duration: Choose the retention period (7 days to 10 years; over 1 year requires specific licensing)
9. Priority: Set the priority, where lower numbers have higher priority
10. Select Save.

Sign in to the [Microsoft Purview](https://purview.microsoft.com/" data-linktype="external) portal with an account that has the **Organization Configuration** role.

Go to **Solutions** &gt; **Audit** &gt; **Audit retention policies**.

Select **Create audit retention policy**, then complete the fields:

- Policy name: Unique name for the policy
- Description: Optional short description
- Users: Apply to all users or specific ones
- Record type: Choose the type of audit record; multiple types can't have activity-specific selections
- Duration: Choose the retention period (7 days to 10 years; over 1 year requires specific licensing)
- Priority: Set the priority, where lower numbers have higher priority


![Screenshot showing the new audit retention policy flyout page.](https://learn.microsoft.com/training/wwl-sci/purview-audit-search-investigate/media/audit-create-new-audit-retention-policy.png)

Select **Save**.


## Manage policies in the Microsoft Purview Portal

Once created, policies appear in the **Audit retention policies** dashboard. You can view, edit, or delete them, and adjust priority as needed.


![Screenshot showing the priority column in the Audit retention policies dashboard.](https://learn.microsoft.com/training/wwl-sci/purview-audit-search-investigate/media/audit-log-retention-dashboard-priority.png)


## Manage retention policies using PowerShell

For more advanced management, use **[Security &amp; Compliance PowerShell](https://learn.microsoft.com/en-us/powershell/exchange/connect-to-scc-powershell" data-linktype="absolute-path" target="az-portal" class="has-external-link-indicator)**.

- Create policies in PowerShell using the New-UnifiedAuditLogRetentionPolicy cmdlet. This example creates a policy named "Microsoft Teams Audit Policy" to retain all activities for 10 years with a priority of 100:

		PowerShell
		
		
			
				
				
			
			Copy
		
	
		
	New-UnifiedAuditLogRetentionPolicy -Name "Microsoft Teams Audit Policy" -Description "10-year retention policy for Teams activities" -RecordTypes MicrosoftTeams -RetentionDuration TenYears -Priority 100
- View policies in PowerShell using the Get-UnifiedAuditLogRetentionPolicy cmdlet. This example displays the settings for all audit log retention policies in your organization and sorts policies from highest to lowest priority:

		PowerShell
		
		
			
				
				
			
			Copy
		
	
		
	Get-UnifiedAuditLogRetentionPolicy | Sort-Object -Property Priority -Descending | FL Priority,Name,Description,RecordTypes,Operations,UserIds,RetentionDuration
- Edit policies in PowerShell using the Set-UnifiedAuditLogRetentionPolicy cmdlet:

		PowerShell
		
		
			
				
				
			
			Copy
		
	
		
	Set-UnifiedAuditLogRetentionPolicy -Identity "Microsoft Teams Audit Policy" -RetentionDuration FiveYears
- Delete policies in PowerShell using the Remove-UnifiedAuditLogRetentionPolicy cmdlet. It might take up to 30 minutes for the policy to be removed from your organization:

		PowerShell
		
		
			
				
				
			
			Copy
		
	
		
	Remove-UnifiedAuditLogRetentionPolicy -Identity "Microsoft Teams Audit Policy"

**Create policies in PowerShell** using the `New-UnifiedAuditLogRetentionPolicy` cmdlet. This example creates a policy named "Microsoft Teams Audit Policy" to retain all activities for 10 years with a priority of 100:


```text
New-UnifiedAuditLogRetentionPolicy -Name "Microsoft Teams Audit Policy" -Description "10-year retention policy for Teams activities" -RecordTypes MicrosoftTeams -RetentionDuration TenYears -Priority 100
```

**View policies in PowerShell** using the `Get-UnifiedAuditLogRetentionPolicy` cmdlet. This example displays the settings for all audit log retention policies in your organization and sorts policies from highest to lowest priority:


```text
Get-UnifiedAuditLogRetentionPolicy | Sort-Object -Property Priority -Descending | FL Priority,Name,Description,RecordTypes,Operations,UserIds,RetentionDuration
```

**Edit policies in PowerShell** using the `Set-UnifiedAuditLogRetentionPolicy` cmdlet:


```text
Set-UnifiedAuditLogRetentionPolicy -Identity "Microsoft Teams Audit Policy" -RetentionDuration FiveYears
```

**Delete policies in PowerShell** using the `Remove-UnifiedAuditLogRetentionPolicy` cmdlet. It might take up to 30 minutes for the policy to be removed from your organization:


```text
Remove-UnifiedAuditLogRetentionPolicy -Identity "Microsoft Teams Audit Policy"
```


---

*Source: [https://learn.microsoft.com/en-us/training/modules/purview-audit-search-investigate/audit-premium-retention/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview](https://learn.microsoft.com/en-us/training/modules/purview-audit-search-investigate/audit-premium-retention/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-purview)*