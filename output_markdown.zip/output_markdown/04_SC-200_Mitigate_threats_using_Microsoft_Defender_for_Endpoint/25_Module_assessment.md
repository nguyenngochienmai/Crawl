---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Defender for Endpoint
module_number: 25
url: https://learn.microsoft.com/en-us/training/modules/perform-device-investigations-microsoft-defender-for-endpoints/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint
type: quiz
crawled_at: 2025-11-25T18:07:44.548424
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "The security operations analyst discovered an interesting event, what should be done to mark it for further review?",
"options": [
"Tag",
"Highlight",
"Flag"
],
"correct\_answers": [
"Flag"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "Which Behavioral blocking can be used with third-party antivirus?",
"options": [
"Client behavior blocking.",
"EDR in block mode",
"Feedback-loop blocking"
],
"correct\_answers": [
"EDR in block mode"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "A Windows 10 Device doesn't appear in the device list, what could be the problem?",
"options": [
"The Device was renamed.",
"The Device is missing the latest KBs",
"The Device had no alerts in the past 30 days."
],
"correct\_answers": [
"The Device had no alerts in the past 30 days."
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/perform-device-investigations-microsoft-defender-for-endpoints/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint](https://learn.microsoft.com/en-us/training/modules/perform-device-investigations-microsoft-defender-for-endpoints/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint)*