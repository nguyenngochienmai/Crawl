---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Defender for Endpoint
module_number: 32
url: https://learn.microsoft.com/en-us/training/modules/perform-actions-device-microsoft-defender-for-endpoint/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint
type: quiz
crawled_at: 2025-11-25T18:10:57.398669
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "Which type of information is collected in an Investigation package?",
"options": [
"Command History",
"Prefetch Files",
"Network transactions"
],
"correct\_answers": [
"Prefetch Files"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "Which of the actions below is a Device action?",
"options": [
"Reboot",
"Reformat device",
"Isolate device"
],
"correct\_answers": [
"Isolate device"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/perform-actions-device-microsoft-defender-for-endpoint/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint](https://learn.microsoft.com/en-us/training/modules/perform-actions-device-microsoft-defender-for-endpoint/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint)*