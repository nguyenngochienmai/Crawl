---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Defender for Endpoint
module_number: 46
url: https://learn.microsoft.com/en-us/training/modules/configure-manage-automation-microsoft-defender-for-endpoint/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint
type: quiz
crawled_at: 2025-11-25T18:13:52.928160
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "Which is a valid remediation level?",
"options": [
"Semi - require approval for any remediation",
"Semi - user accounts only",
"Semi - files only"
],
"correct\_answers": [
"Semi - require approval for any remediation"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "A security operations analyst needs to exclude a custom executable file c:\\myapp\\myapp.exe, which exclusion type should they use?",
"options": [
"File",
"Extension",
"Folder"
],
"correct\_answers": [
"File"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "In advanced features, which setting should be turned on to block files even if a third-party antivirus is used?",
"options": [
"Enable EDR in block mode",
"Allow or block file",
"Automated Investigation"
],
"correct\_answers": [
"Enable EDR in block mode"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/configure-manage-automation-microsoft-defender-for-endpoint/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint](https://learn.microsoft.com/en-us/training/modules/configure-manage-automation-microsoft-defender-for-endpoint/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint)*