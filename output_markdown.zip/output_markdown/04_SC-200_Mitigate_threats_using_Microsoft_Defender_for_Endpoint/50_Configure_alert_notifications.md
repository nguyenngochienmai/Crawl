---
title: Configure alert notifications
learning_path: SC-200: Mitigate threats using Microsoft Defender for Endpoint
module_number: 50
url: https://learn.microsoft.com/en-us/training/modules/configure-settings-for-alerts-detections-microsoft-defender-for-endpoint/3-configure-alert-notifications/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint
type: content
crawled_at: 2025-11-25T18:14:27.912540
---

# Configure alert notifications

> Configure alert notifications

You can configure Defender for Endpoint to send email notifications to specified recipients for new alerts. This feature enables you to identify a group of individuals who will immediately be informed and can act on alerts based on their severity.

Only users with 'Manage security settings' permissions can configure email notifications. If you've chosen to use basic permissions management, users with Security Administrator or Global Administrator roles can configure email notifications.

You can set the alert severity levels that trigger notifications. You can also add or remove recipients of the email notification. New recipients get notified about alerts encountered after they're added. For more information about alerts, see View and organize the Alerts queue.

If you're using role-based access control (RBAC), recipients will only receive notifications based on the device groups that were configured in the notification rule. Users with the proper permission can only create, edit, or delete notifications limited to their device group management scope. Only users assigned to the Global administrator role can manage notification rules that were configured for all device groups.

The email notification includes basic information about the alert and a link to the portal where you can do further investigation.


## Create rules for alert notifications

You can create rules that determine the devices and alert severities to send email notifications to notification recipients.

1. In the Microsoft Defender portal, select Settings then select Endpoints and then select Email notifications.
2. Select + Add item.
3. Specify the General information:

Rule name - Specify a name for the notification rule.

Include organization name - Specify the customer name that appears on the email notification.

Include tenant-specific portal link - Adds a link with the tenant ID to allow access to a specific tenant.

Include device information - Includes the device name in the email alert body.

Devices - Choose whether to notify recipients for alerts on all devices (Global administrator role only) or selected device groups. For more information, see Create and manage device groups.

Alert severity - Choose the alert severity level.
4. Rule name - Specify a name for the notification rule.
5. Include organization name - Specify the customer name that appears on the email notification.
6. Include tenant-specific portal link - Adds a link with the tenant ID to allow access to a specific tenant.
7. Include device information - Includes the device name in the email alert body.
8. Devices - Choose whether to notify recipients for alerts on all devices (Global administrator role only) or selected device groups. For more information, see Create and manage device groups.
9. Alert severity - Choose the alert severity level.
10. Select Next.
11. Enter the recipient's email address, then select Add recipient. You can add multiple email addresses.
12. Check that email recipients are able to receive the email notifications by selecting Send test email.
13. Select Save notification rule.

In the Microsoft Defender portal, select **Settings** then select **Endpoints** and then select **Email notifications**.

Select **+ Add item**.

Specify the General information:

- Rule name - Specify a name for the notification rule.
- Include organization name - Specify the customer name that appears on the email notification.
- Include tenant-specific portal link - Adds a link with the tenant ID to allow access to a specific tenant.
- Include device information - Includes the device name in the email alert body.
- Devices - Choose whether to notify recipients for alerts on all devices (Global administrator role only) or selected device groups. For more information, see Create and manage device groups.
- Alert severity - Choose the alert severity level.

Rule name - Specify a name for the notification rule.

Include organization name - Specify the customer name that appears on the email notification.

Include tenant-specific portal link - Adds a link with the tenant ID to allow access to a specific tenant.

Include device information - Includes the device name in the email alert body.

Devices - Choose whether to notify recipients for alerts on all devices (Global administrator role only) or selected device groups. For more information, see Create and manage device groups.

Alert severity - Choose the alert severity level.

Select **Next**.

Enter the recipient's email address, then select **Add recipient**. You can add multiple email addresses.

Check that email recipients are able to receive the email notifications by selecting Send test email.

Select **Save notification rule**.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/configure-settings-for-alerts-detections-microsoft-defender-for-endpoint/3-configure-alert-notifications/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint](https://learn.microsoft.com/en-us/training/modules/configure-settings-for-alerts-detections-microsoft-defender-for-endpoint/3-configure-alert-notifications/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint)*