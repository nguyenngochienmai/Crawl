---
title: Explore vulnerabilities on your devices
learning_path: SC-200: Mitigate threats using Microsoft Defender for Endpoint
module_number: 57
url: https://learn.microsoft.com/en-us/training/modules/use-threat-vulnerability-management-microsoft-defender-for-endpoint/3-explore-vulnerabilities-devices/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint
type: content
crawled_at: 2025-11-25T18:17:22.919554
---

# Explore vulnerabilities on your devices

> Explore vulnerabilities on your devices

Microsoft Defender Vulnerability Management provides the following features based on licensing:

| Defender Vulnerability Management Core capabilities part of Defender for Endpoint Plan 2 | Defender Vulnerability Management add-on capabilities for Defender for Endpoint Plan 2 | Defender Vulnerability Management Standalone Full vulnerability Management capabilities |
| --- | --- | --- |
| Device discovery | Security baselines assessment | Device discovery |
| Device inventory | Block vulnerable applications | Device inventory |
| Vulnerability assessment | Browser extensions | Vulnerability assessment |
| Configuration assessment | Digital certificate assessment | Configuration assessment |
| Risk based prioritization | Network share analysis | Risk based prioritization |
| Remediation tracking |  | Remediation tracking |
| Continuous monitoring |  | Continuous monitoring |
| Software assessment |  | Software assessment |
|  |  | Security baselines assessment |
|  |  | Block vulnerable applications |
|  |  | Browser extensions |
|  |  | Digital certificate assessment |
|  |  | Network share analysis |


## Vulnerability Management area

The following areas are visible in the Vulnerability Management area of the Microsoft Defender portal:


### Dashboard

The Dashboard provides multiple tiles showing your overall exposure and remediation information.


### Recommendations

The Recommendations page provides a list of security recommendations.


### Remediation


### Inventories

The Inventories page opens with a list of software installed in your network, including the vendor name, weaknesses found, threats associated with them, exposed devices, impact to exposure score, and tags.  You can filter the list view based on weaknesses found in the software, threats associated with them, and tags like whether the software has reached end-of-support.


### Weaknesses

The Weaknesses page lists the software vulnerabilities your devices are exposed to by listing the Common Vulnerabilities and Exposures (CVE) ID. You can also view the severity, Common Vulnerability Scoring System (CVSS) rating, prevalence in your organization, corresponding breach, threat insights, and more.


### Event timeline

The Event timeline is a risk news feed that helps you interpret how risk is introduced into the organization through new vulnerabilities or exploits. You can view events that may impact your organization's risk. For example, you can find new vulnerabilities that were introduced, vulnerabilities that became exploitable, exploits that were added to an exploit kit, and more.  Event timeline also tells the story of your exposure score and Microsoft Secure Score for Devices so you can determine the cause of large changes. Events can impact your devices or your score for devices. Reduce your exposure by addressing what needs to be remediated based on the prioritized security recommendations.


### Baseline Assessments

Instead of running never-ending compliance scans, security baselines assessment helps you to continuously and effortlessly monitor your organization's security baselines compliance and identify changes in real time.

A security baseline profile is a customized profile that you can create to assess and monitor endpoints in your organization against industry security benchmarks. When you create a security baseline profile, you're creating a template that consists of multiple device configuration settings and a base benchmark to compare against.


## Vulnerable devices report

The Reports area in the Microsoft Defender portal has a Vulnerable devices report.  The report shows graphs and bar charts with vulnerable device trends and current statistics. The goal is for you to understand the breadth and scope of your device exposure.

The graphs and charts include:

- Severity level graphs - Each device is counted only once according to the most severe vulnerability found on that device.
- Exploit availability graphs - Each device is counted only once based on the highest level of known exploit.
- Vulnerability age graphs - Each device is counted only once under the oldest vulnerability publication date. Older vulnerabilities have a higher chance of being exploited.
- Vulnerable devices by operating system platform graphs - The number of devices on each operating system that are exposed due to software vulnerabilities.
- Vulnerable devices by Windows version graphs - The number of devices on each Windows version that are exposed due to vulnerable applications or OS.

**Severity level graphs** - Each device is counted only once according to the most severe vulnerability found on that device.

**Exploit availability graphs** - Each device is counted only once based on the highest level of known exploit.

**Vulnerability age graphs** - Each device is counted only once under the oldest vulnerability publication date. Older vulnerabilities have a higher chance of being exploited.

**Vulnerable devices by operating system platform graphs** - The number of devices on each operating system that are exposed due to software vulnerabilities.

**Vulnerable devices by Windows version graphs** - The number of devices on each Windows version that are exposed due to vulnerable applications or OS.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/use-threat-vulnerability-management-microsoft-defender-for-endpoint/3-explore-vulnerabilities-devices/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint](https://learn.microsoft.com/en-us/training/modules/use-threat-vulnerability-management-microsoft-defender-for-endpoint/3-explore-vulnerabilities-devices/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint)*