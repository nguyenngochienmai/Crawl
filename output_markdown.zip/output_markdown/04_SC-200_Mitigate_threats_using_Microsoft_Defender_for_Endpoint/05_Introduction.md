---
title: Introduction
learning_path: SC-200: Mitigate threats using Microsoft Defender for Endpoint
module_number: 5
url: https://learn.microsoft.com/en-us/training/modules/deploy-microsoft-defender-for-endpoints-environment/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint
type: introduction
crawled_at: 2025-11-25T18:01:52.220543
---

# Introduction

> Introduction

Deploying the Microsoft Defender for Endpoint environment involves configuring your tenant, onboarding your devices, and configuring security team access.

You're a Security Operations Analyst working at a company that is implementing Microsoft Defender for Endpoint. Your manager plans to onboard a few devices to provide insight into required changes to the SecOps team response procedures.

You start by initializing the Defender for Endpoint environment—next, you onboard the initial devices for your deployment by running the onboarding script on the devices.  You configure security for the environment.  Next, you create Device groups and assign the appropriate devices.

After completing this module, you'll be able to:

- Create a Microsoft Defender for Endpoint environment
- Onboard devices to be monitored by Microsoft Defender for Endpoint
- Configure Microsoft Defender for Endpoint environment settings


## Prerequisites

Basic understanding of Microsoft 365.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/deploy-microsoft-defender-for-endpoints-environment/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint](https://learn.microsoft.com/en-us/training/modules/deploy-microsoft-defender-for-endpoints-environment/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint)*