---
title: Manage remediation
learning_path: SC-200: Mitigate threats using Microsoft Defender for Endpoint
module_number: 58
url: https://learn.microsoft.com/en-us/training/modules/use-threat-vulnerability-management-microsoft-defender-for-endpoint/4-manage-remediation/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint
type: content
crawled_at: 2025-11-25T18:17:31.463624
---

# Manage remediation

> Manage remediation

Vulnerability management capabilities bridges the gap between Security and IT administrators through the remediation request workflow. Security admins like you can request for the IT Administrator to remediate a vulnerability from the Recommendation pages to Intune.


## Remediation request steps

- Go to the Vulnerability management navigation menu in the Microsoft Defender portal, and select Recommendations.
- Select a security recommendation you would like to request remediation for, and then select Remediation options.
- Fill out the form, including what you are requesting remediation for, applicable device groups, priority, due date, and optional notes.
If you choose the "attention required" remediation option, selecting a due date won't be available since there's no specific action.
- Select Submit request. Submitting a remediation request creates a remediation activity item within vulnerability management, which can be used for monitoring the remediation progress for this recommendation. This won't trigger a remediation or apply any changes to devices.
- Notify your IT Administrator about the new request and have them log into Intune to approve or reject the request and start a package deployment.
- Go to the Remediation page to view the status of your remediation request.

Go to the Vulnerability management navigation menu in the Microsoft Defender portal, and select Recommendations.

Select a security recommendation you would like to request remediation for, and then select Remediation options.

Fill out the form, including what you are requesting remediation for, applicable device groups, priority, due date, and optional notes.
If you choose the "attention required" remediation option, selecting a due date won't be available since there's no specific action.

Select Submit request. Submitting a remediation request creates a remediation activity item within vulnerability management, which can be used for monitoring the remediation progress for this recommendation. This won't trigger a remediation or apply any changes to devices.

Notify your IT Administrator about the new request and have them log into Intune to approve or reject the request and start a package deployment.

Go to the Remediation page to view the status of your remediation request.


## View your remediation activities

When you submit a remediation request from the Security recommendations page, it kicks-off a remediation activity. A security task is created that can be tracked on a Remediation page, and a remediation ticket is created in Microsoft Intune.

If you chose the "attention required" remediation option, there will be no progress bar, ticket status, or due date since there's no actual action we can monitor.

Once you are in the Remediation page, select the remediation activity that you want to view. You can follow the remediation steps, track progress, view the related recommendation, export to CSV, or mark as complete.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/use-threat-vulnerability-management-microsoft-defender-for-endpoint/4-manage-remediation/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint](https://learn.microsoft.com/en-us/training/modules/use-threat-vulnerability-management-microsoft-defender-for-endpoint/4-manage-remediation/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint)*