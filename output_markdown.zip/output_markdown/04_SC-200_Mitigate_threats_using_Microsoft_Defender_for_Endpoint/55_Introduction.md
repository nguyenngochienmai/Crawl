---
title: Introduction
learning_path: SC-200: Mitigate threats using Microsoft Defender for Endpoint
module_number: 55
url: https://learn.microsoft.com/en-us/training/modules/use-threat-vulnerability-management-microsoft-defender-for-endpoint/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint
type: introduction
crawled_at: 2025-11-25T18:16:59.738069
---

# Introduction

> Introduction

Microsoft Defender Vulnerability Management discovers vulnerable and misconfigured devices based on known attack vectors and software vulnerabilities.

You're a Security Operations Analyst working at a company that implemented Microsoft Defender for Endpoint. You're responsible for working with the endpoint management team to remediate weaknesses reported by Vulnerability Management.

A new threat is listed in the Threat Analytics dashboard. You can quickly see that none of your devices are vulnerable to this new threat because Vulnerability Management already provided the analysis required on your devices.

After completing this module, you'll be able to:

- Describe Microsoft Defender Vulnerability Management
- Identify vulnerabilities on your devices
- Track emerging threats


## Prerequisites

Intermediate understanding of Windows 10.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/use-threat-vulnerability-management-microsoft-defender-for-endpoint/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint](https://learn.microsoft.com/en-us/training/modules/use-threat-vulnerability-management-microsoft-defender-for-endpoint/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint)*