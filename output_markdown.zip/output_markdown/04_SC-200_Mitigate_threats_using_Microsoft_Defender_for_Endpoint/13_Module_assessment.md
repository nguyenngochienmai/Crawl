---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Defender for Endpoint
module_number: 13
url: https://learn.microsoft.com/en-us/training/modules/deploy-microsoft-defender-for-endpoints-environment/9-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint
type: quiz
crawled_at: 2025-11-25T18:03:04.412790
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "The default data retention period in Microsoft Defender XDR for Endpoint is?",
"options": [
"One month",
"Six months",
"Three months"
],
"correct\_answers": [
"Six months"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "Which of the following options is a valid Microsoft Defender XDR for Endpoint onboarding option for Windows 10 devices?",
"options": [
"Group policy",
"Microsoft Store",
"General install package"
],
"correct\_answers": [
"Group policy"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "Which security permission allows the configuration of storage settings?",
"options": [
"Manage security settings in Security Center",
"Manage portal system settings",
"Advanced commands"
],
"correct\_answers": [
"Manage portal system settings"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/deploy-microsoft-defender-for-endpoints-environment/9-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint](https://learn.microsoft.com/en-us/training/modules/deploy-microsoft-defender-for-endpoints-environment/9-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint)*