---
title: Manage automation upload and folder settings
learning_path: SC-200: Mitigate threats using Microsoft Defender for Endpoint
module_number: 43
url: https://learn.microsoft.com/en-us/training/modules/configure-manage-automation-microsoft-defender-for-endpoint/3-manage-automation-upload-folder-settings/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint
type: content
crawled_at: 2025-11-25T18:13:22.184078
---

# Manage automation upload and folder settings

> Manage automation upload and folder settings


## Manage automation uploads

Enable the **File Content Analysis** capability so that certain files and email attachments can automatically be uploaded to the cloud for more inspection in Automated investigation.  Identify the files and email attachments by specifying the file extension names and email attachment extension names.  For example, if you add exe and bat as file or attachment extension names, then all files or attachments with those extensions will automatically be sent to the cloud for more inspection during Automated investigation.

Enable the Memory Content Analysis capability if you would like Microsoft Defender for Endpoint to automatically investigate memory content of processes. When enabled, memory content might be uploaded to Microsoft Defender for Endpoint during an Automated investigation.


![Screenshot of Automation File upload settings.](https://learn.microsoft.com/training/wwl-sci/configure-manage-automation-microsoft-defender-for-endpoint/media/automation-uploads.png)


### Add file extension names and attachment extension names

To configure file settings:

- In the navigation pane for Microsoft Defender XDR, select Settings > Endpoints.  Under the Rules section, select Automation uploads.
- Toggle the content analysis setting between On and Off.
- Configure the following extension names and separate extension names with a comma:

File extension names - Suspicious files except email attachments will be submitted for more inspection
- File extension names - Suspicious files except email attachments will be submitted for more inspection

In the navigation pane for Microsoft Defender XDR, select **Settings &gt; Endpoints**.  Under the Rules section, select **Automation uploads**.

Toggle the content analysis setting between On and Off.

Configure the following extension names and separate extension names with a comma:

- File extension names - Suspicious files except email attachments will be submitted for more inspection


## Manage automation folder exclusions

Automation folder exclusions allow you to specify folders that the Automated investigation will skip.  You can control the following attributes about the folder that you'd like to be skipped:

- Folders
- Extensions of the files
- File names

Extensions of the files


### Folders

You can specify a folder and its subfolders to be skipped.


### Extensions

You can specify the extensions to exclude in a specific directory. The extensions are a way to prevent an attacker from using an excluded folder to hide an exploit. The extensions explicitly define which files to ignore.


### File names

You can specify the file names that you want to be excluded in a specific directory. The names are a way to prevent an attacker from using an excluded folder to hide an exploit. The names explicitly define which files to ignore.


### Add an automation folder exclusion

To manage folder exclusions:

- In the navigation pane for Microsoft Defender XDR, select Settings > Endpoints.  Under the Rules section, select Automation folder exclusions.
- Select New folder exclusion.
- Enter the folder details:

Folder

Extensions

File names

Description
- Folder
- Extensions
- File names
- Description
- Select Save.

In the navigation pane for Microsoft Defender XDR, select **Settings &gt; Endpoints**.  Under the Rules section, select **Automation folder exclusions**.

Select New folder exclusion.

Enter the folder details:

- Folder
- Extensions
- File names
- Description

Description

Select **Save**.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/configure-manage-automation-microsoft-defender-for-endpoint/3-manage-automation-upload-folder-settings/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint](https://learn.microsoft.com/en-us/training/modules/configure-manage-automation-microsoft-defender-for-endpoint/3-manage-automation-upload-folder-settings/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint)*