---
title: Summary and resources
learning_path: SC-200: Mitigate threats using Microsoft Defender for Endpoint
module_number: 14
url: https://learn.microsoft.com/en-us/training/modules/deploy-microsoft-defender-for-endpoints-environment/10-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint
type: summary
crawled_at: 2025-11-25T18:04:12.776456
---

# Summary and resources

> Summary and resources

You learned how deploying the Microsoft Defender for Endpoint environment involves configuring your tenant, onboarding your devices, and configuring security.

You should now be able to:

- Create your Microsoft Defender for Endpoint environment
- Onboard devices to be monitored by Microsoft Defender for Endpoint
- Configure Microsoft Defender for Endpoint environment settings

Create your Microsoft Defender for Endpoint environment

Onboard devices to be monitored by Microsoft Defender for Endpoint

Configure Microsoft Defender for Endpoint environment settings


## Learn more

You can learn more by reviewing the following.

[Set up Microsoft Defender for Endpoint deployment](https://learn.microsoft.com/en-us/windows/security/threat-protection/microsoft-defender-atp/production-deployment" data-linktype="absolute-path" target="az-portal" class="has-external-link-indicator)

[Onboard devices to the Microsoft Defender for Endpoint service](https://learn.microsoft.com/en-us/windows/security/threat-protection/microsoft-defender-atp/onboard-configure" data-linktype="absolute-path" target="az-portal" class="has-external-link-indicator)

[Become a Microsoft Defender for Endpoint Ninja (formerly MDATP)](https://nam06.safelinks.protection.outlook.com/?url=https%3A%2F%2Ftechcommunity.microsoft.com%2Ft5%2Fmicrosoft-defender-for-endpoint%2Fbecome-a-microsoft-defender-atp-ninja%2Fba-p%2F1515647&amp;data=04%7C01%7Cbneeb%40microsoft.com%7C70ade848411b4dbb43bd08d8b1e6e51e%7C72f988bf86f141af91ab2d7cd011db47%7C1%7C0%7C637454952552234995%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C1000&amp;sdata=%2FfCCxsoJg5FwJwrgGstqLGYHuABKDTOlvmPbT3zVQ6w%3D&amp;reserved=0%3Fazure-portal%3Dtrue" data-linktype="external" target="az-portal" class="has-external-link-indicator)

[Microsoft Tech Community Security Webinars](https://techcommunity.microsoft.com/t5/microsoft-security-and/security-community-webinars/ba-p/927888" data-linktype="external" target="az-portal" class="has-external-link-indicator)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/deploy-microsoft-defender-for-endpoints-environment/10-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint](https://learn.microsoft.com/en-us/training/modules/deploy-microsoft-defender-for-endpoints-environment/10-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint)*