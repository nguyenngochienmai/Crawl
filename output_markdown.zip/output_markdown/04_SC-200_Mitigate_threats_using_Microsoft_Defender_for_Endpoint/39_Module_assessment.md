---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Defender for Endpoint
module_number: 39
url: https://learn.microsoft.com/en-us/training/modules/perform-evidence-entities-investigations-microsoft-defender-for-endpoint/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint
type: quiz
crawled_at: 2025-11-25T18:12:25.800134
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "Which of the following artifact types has an investigation page?",
"options": [
"Domain",
"Hunter",
"Threat Actor"
],
"correct\_answers": [
"Domain"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "What information is provided by a deep file analysis?",
"options": [
"Command history",
"Registry Modifications",
"Code change history"
],
"correct\_answers": [
"Registry Modifications"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "Which information is provided on the user account page?",
"options": [
"Associated alerts",
"Security groups",
"Threat hunt ID"
],
"correct\_answers": [
"Associated alerts"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/perform-evidence-entities-investigations-microsoft-defender-for-endpoint/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint](https://learn.microsoft.com/en-us/training/modules/perform-evidence-entities-investigations-microsoft-defender-for-endpoint/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint)*