---
title: Onboard devices
learning_path: SC-200: Mitigate threats using Microsoft Defender for Endpoint
module_number: 8
url: https://learn.microsoft.com/en-us/training/modules/deploy-microsoft-defender-for-endpoints-environment/4-onboard-devices/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint
type: content
crawled_at: 2025-11-25T18:02:18.649984
---

# Onboard devices

> Onboard devices


## Configure Device discovery

When accessing your Microsoft Defender portal settings for Endpoints for the first time, the first step is to configure Device discovery. You must be a Security Administrator for the tenant.

1. On the Microsoft Defender XDR portal, from the navigation menu, select Settings from the left.
2. In the Settings menu page, select Device discovery.

 Note
If you do not see the Device discovery option under Settings, logout by selecting the top-right circle with your account initials and select Sign out. Other options that you might want to try is to refresh the page with Ctrl+F5 or open the page InPrivate. Log in again with the Tenant Email credentials.
3. In Discovery setup, make sure Standard discovery (recommended) is selected.

 Tip
If you do not see the option, refresh the page.

On the **Microsoft Defender XDR** portal, from the navigation menu, select **Settings** from the left.

In the Settings menu page, select Device discovery.

If you do not see the **Device discovery** option under **Settings**, logout by selecting the top-right circle with your account initials and select **Sign out**. Other options that you might want to try is to refresh the page with Ctrl+F5 or open the page InPrivate. Log in again with the **Tenant Email** credentials.

In Discovery setup, make sure **Standard discovery (recommended)** is selected.

If you do not see the option, refresh the page.


![Screenshot of the Settings Device discovery options.](https://learn.microsoft.com/training/wwl-sci/deploy-microsoft-defender-for-endpoints-environment/media/settings-device-discovery.png)


## Onboard devices

You need to go to the onboarding section of the Microsoft Defender portal to onboard any of the supported devices.  Depending on the device, you are guided with appropriate steps and provided management and deployment tool options suitable for the device.

In general, to onboard devices to the service:

- Verify that the device fulfills the minimum requirements
- Depending on the device, follow the configuration steps provided in the onboarding section of the Microsoft Defender portal
- Use the appropriate management tool and deployment method for your devices
- Run a detection test to verify that the devices are properly onboarded and reporting to the service

Verify that the device fulfills the minimum requirements

Depending on the device, follow the configuration steps provided in the onboarding section of the Microsoft Defender portal

Use the appropriate management tool and deployment method for your devices

Run a detection test to verify that the devices are properly onboarded and reporting to the service


## Interactive Lab Simulation

Select the thumbnail image to start the lab simulation. When you're done, be sure to return to this page so you can continue learning.


![Screenshot of the lab simulation page.](https://learn.microsoft.com/training/wwl-sci/deploy-microsoft-defender-for-endpoints-environment/media/lab-simulation-deploy-microsoft-defender-for-endpoint.png)

In Settings, Endpoints, Device management, Onboarding select operating system dropdown to see the supported options.


![Screenshot of the Supported Operating Systems dropdown.](https://learn.microsoft.com/training/wwl-sci/deploy-microsoft-defender-for-endpoints-environment/media/onboarding.png)

After you select the appropriate operating system option, the supported deployment options are outlined.   Here's a list of the Windows 10 supported deployment options:

- Group Policy
- Microsoft Endpoint Configuration Manager current branch and later
- Mobile Device Management (including Microsoft Intune)
- Local script (for up to 10 devices)
- VDI onboarding script for non-persistent devices
- System Center Configuration Manager 2012 / 2012 R2 / 1511 /1602

Group Policy

Microsoft Endpoint Configuration Manager current branch and later

Mobile Device Management (including Microsoft Intune)

Local script (for up to 10 devices)

VDI onboarding script for non-persistent devices

System Center Configuration Manager 2012 / 2012 R2 / 1511 /1602


![Screenshot of the Windows 10 Deployment options.](https://learn.microsoft.com/training/wwl-sci/deploy-microsoft-defender-for-endpoints-environment/media/onboard-deployment.png)

As you can see, there are many configuration options.


## Offboarding devices

In Settings, Endpoints, Device Management, Offboarding, select operating system dropdown to see the direction to offboard devices.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/deploy-microsoft-defender-for-endpoints-environment/4-onboard-devices/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint](https://learn.microsoft.com/en-us/training/modules/deploy-microsoft-defender-for-endpoints-environment/4-onboard-devices/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint)*