---
title: Summary and resources
learning_path: SC-200: Mitigate threats using Microsoft Defender for Endpoint
module_number: 19
url: https://learn.microsoft.com/en-us/training/modules/implement-windows-10-security-enhancements-with-microsoft-defender-for-endpoint/5-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint
type: summary
crawled_at: 2025-11-25T18:06:50.048233
---

# Summary and resources

> Summary and resources

You learned that Microsoft Defender for Endpoint gives you various tools to eliminate risks by reducing the surface area for attacks without blocking user productivity.

You should now be able to:

- Explain Attack Surface Reduction in Windows
- Enable Attack Surface Reduction rules on Windows 10 devices
- Configure Attack Surface Reduction rules on Windows 10 devices

Explain Attack Surface Reduction in Windows

Enable Attack Surface Reduction rules on Windows 10 devices

Configure Attack Surface Reduction rules on Windows 10 devices


## Learn more

You can learn more by reviewing the following.

[Attack surface reduction](https://learn.microsoft.com/en-us/windows/security/threat-protection/microsoft-defender-atp/attack-surface-reduction" data-linktype="absolute-path" target="az-portal" class="has-external-link-indicator)

[Application control](https://learn.microsoft.com/en-us/windows/security/threat-protection/windows-defender-application-control/windows-defender-application-control" data-linktype="absolute-path" target="az-portal" class="has-external-link-indicator)

[Hardware-based isolation](https://learn.microsoft.com/en-us/windows/security/threat-protection/microsoft-defender-application-guard/md-app-guard-overview" data-linktype="absolute-path" target="az-portal" class="has-external-link-indicator)

[Exploit protection](https://learn.microsoft.com/en-us/windows/security/threat-protection/microsoft-defender-atp/exploit-protection" data-linktype="absolute-path" target="az-portal" class="has-external-link-indicator)

[Network protection](https://learn.microsoft.com/en-us/windows/security/threat-protection/microsoft-defender-atp/network-protection" data-linktype="absolute-path" target="az-portal" class="has-external-link-indicator)

[Web protection](https://learn.microsoft.com/en-us/windows/security/threat-protection/microsoft-defender-atp/web-protection-overview" data-linktype="absolute-path" target="az-portal" class="has-external-link-indicator)

[Controlled folder access](https://learn.microsoft.com/en-us/windows/security/threat-protection/microsoft-defender-atp/controlled-folders" data-linktype="absolute-path" target="az-portal" class="has-external-link-indicator)

[Network firewall](https://learn.microsoft.com/en-us/windows/security/threat-protection/windows-firewall/windows-firewall-with-advanced-security" data-linktype="absolute-path" target="az-portal" class="has-external-link-indicator)

[Become a Microsoft Defender for Endpoint Ninja (formerly MDATP)](https://nam06.safelinks.protection.outlook.com/?url=https%3A%2F%2Ftechcommunity.microsoft.com%2Ft5%2Fmicrosoft-defender-for-endpoint%2Fbecome-a-microsoft-defender-atp-ninja%2Fba-p%2F1515647&amp;data=04%7C01%7Cbneeb%40microsoft.com%7C70ade848411b4dbb43bd08d8b1e6e51e%7C72f988bf86f141af91ab2d7cd011db47%7C1%7C0%7C637454952552234995%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C1000&amp;sdata=%2FfCCxsoJg5FwJwrgGstqLGYHuABKDTOlvmPbT3zVQ6w%3D&amp;reserved=0%3Fazure-portal%3Dtrue" data-linktype="external" target="az-portal" class="has-external-link-indicator)

[Microsoft Tech Community Security Webinars](https://techcommunity.microsoft.com/t5/microsoft-security-and/security-community-webinars/ba-p/927888" data-linktype="external" target="az-portal" class="has-external-link-indicator)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/implement-windows-10-security-enhancements-with-microsoft-defender-for-endpoint/5-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint](https://learn.microsoft.com/en-us/training/modules/implement-windows-10-security-enhancements-with-microsoft-defender-for-endpoint/5-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint)*