---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Defender for Endpoint
module_number: 18
url: https://learn.microsoft.com/en-us/training/modules/implement-windows-10-security-enhancements-with-microsoft-defender-for-endpoint/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint
type: quiz
crawled_at: 2025-11-25T18:04:45.094649
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "Which solution is used to control the applications that must earn trust to be run?",
"options": [
"Exploit protection",
"Controlled folder access",
"Application control"
],
"correct\_answers": [
"Application control"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "Which option below is an attack surface reduction rule that can be configured?",
"options": [
"Block PowerShell from executing",
"Block process creations originating from PSExec and WMI commands",
"Block content from mobile devices"
],
"correct\_answers": [
"Block process creations originating from PSExec and WMI commands"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "Which of the following items is a deployment option?",
"options": [
"PowerShell",
"ASRConfig.exe",
"Microsoft Deployment System"
],
"correct\_answers": [
"PowerShell"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/implement-windows-10-security-enhancements-with-microsoft-defender-for-endpoint/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint](https://learn.microsoft.com/en-us/training/modules/implement-windows-10-security-enhancements-with-microsoft-defender-for-endpoint/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint)*