---
title: Introduction
learning_path: SC-200: Mitigate threats using Microsoft Defender for Endpoint
module_number: 48
url: https://learn.microsoft.com/en-us/training/modules/configure-settings-for-alerts-detections-microsoft-defender-for-endpoint/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint
type: introduction
crawled_at: 2025-11-25T18:14:12.762692
---

# Introduction

> Introduction

Microsoft Defender for Endpoint provides configuration options for alerts and detections.  The configurations include notifications, custom indicators, and detection rules.

You're a Security Operations Analyst working at a company that has implemented Microsoft Defender for Endpoint.  You're responsible for managing alert related settings in the environment.  You manage Live Response settings, alert notification settings, indicators, and custom detections.

Your threat hunting team has provided you with a CSV file with indicators they would like Defender for Endpoint to alert on.  In the Settings page, Rules area, you select indicators and then import.  After the file is imported, the indicators will be used in detections.

Your manager asks for alert notifications for a specific device group and with the severity of high.  In the Settings page, General area, you select Alert notifications.  You then create an alert notification rule to meet the manager’s request.

After completing this module, you'll be able to:

- Configure alert settings in Microsoft Defender for Endpoint
- Manage indicators in Microsoft Defender for Endpoint


## Prerequisites

Intermediate understanding of Windows 10.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/configure-settings-for-alerts-detections-microsoft-defender-for-endpoint/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint](https://learn.microsoft.com/en-us/training/modules/configure-settings-for-alerts-detections-microsoft-defender-for-endpoint/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-defender-for-endpoint)*