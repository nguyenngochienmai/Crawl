---
title: Create a notebook
learning_path: SC-200: Perform threat hunting in Microsoft Sentinel
module_number: 22
url: https://learn.microsoft.com/en-us/training/modules/perform-threat-hunting-sentinel-with-notebooks/4-create-notebook/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel
type: content
crawled_at: 2025-11-25T19:33:21.685897
---

# Create a notebook

> Create a notebook

To get started with Notebooks, use the *Getting Started Guide For Microsoft Sentinel ML Notebooks* notebook.

1. In the Microsoft Sentinel navigation menu, expand the Threat Management section, and select Notebooks
2. You need to create an Azure Machine Learning (ML) Workspace. From the menu, select Configure Azure Machine Learning, then Create new Azure ML workspace.
3. In the Subscription box, select your subscription.
4. Select Create a new Resource group and choose a name for your new resource group.
5. In the Workspace details section:

Give your workspace a unique name.

Choose your Region

Keep the default Storage account, Key vault, and Application insights information.

The Container registry option can remain as None.
6. Give your workspace a unique name.
7. Choose your Region
8. Keep the default Storage account, Key vault, and Application insights information.
9. The Container registry option can remain as None.
10. At the bottom of the page, select Review + create. Then on the next page, select create. It takes a moment to deploy the workspace.

 Note
It takes a few minutes to deploy the Machine Learning workspace.
11. After Your deployment is complete message appears, return to Microsoft Sentinel.
12. Navigate to the Threat Management section, and select Notebooks.
13. Select the Templates tab.
14. Select the A Getting Started Guide For Microsoft Sentinel ML Notebooks from the list.
15. Select Create from template button on the bottom of the detail pane.
16. Review the default options and then select Save.
17. Select the Launch notebook button.
18. Select Close if an informational window appears in the Microsoft Azure Machine Learning studio.
19. In the command bar, to the right of the Compute:  selector, select the + symbol to Create Azure ML compute instance. Hint: It might be hidden inside the ellipsis icon (...).


 Note
You can have more screen space by hiding the Azure ML Studio left menu selections. Select the Hamburger menu (3 horizontal lines on the top left), and by collapsing the Notebooks Files by selecting the << icon.
20. In the command bar, to the right of the Compute:  selector, select the + symbol to Create Azure ML compute instance. Hint: It might be hidden inside the ellipsis icon (...).
21. Type a unique name in the Compute name field. This identifies your compute instance.
22. Scroll down and select the first option available.

 Tip
Workload type: Development on Notebooks (or other IDE) and lightweight testing.
23. Select the Review + Create button at the bottom of the screen, then scroll down and select Create. Close any feedback window that appears. This takes a few minutes. You see a notification (bell icon) when it completes and the Compute instance left icon turns from blue to green.
24. Once the Compute is created and running, verify that the kernel to use is Python 3.10 - Pytorch and Tensorflow.

 Tip
This is shown in the right of the menu bar. If that kernel isn't selected, select the Python 3.10 - Pytorch and Tensorflow option from the drop-down list. You can select the Refresh icon on the far right to see the kernel options.
25. Select the Authenticate button and wait for the authentication to complete.
26. Clear all the results from the notebook by selecting the Clear all outputs (Eraser icon) from the menu bar and follow the Getting Started tutorial.

 Tip
This can be found by selecting the ellipsis (...) from the menu bar.
27. Review section 1 Introduction in the notebook and proceed to section 2 Initializing the notebook and MSTICPy.

 Tip
Section 1.2 Running code in notebooks lets you practice running small lines of Python code.
28. In section 2 Initializing the notebook and MSTICPy, review the content on Initializing the notebook and installing the MSTICPy package.
29. Run the Python code to initialize the cell by selecting the Run cell button (Play icon) to the left of the code.
30. It should take >30 seconds to run. Once it completes, review the output messages and disregard any warnings about the Python kernel version or other error messages.
31. The code ran successfully if msticpyconfig.yaml was created in the utils folder in the file explorer pane on the left. It can take another 30 seconds for the file to appear. If it doesn't appear, select the Refresh icon in the file explorer pane.

 Tip
You can clear the output messages by selecting the ellipsis (...) on the left of the code window for the Output menu and selecting the Clear output (square with an x*) icon.
32. Select the msticpyconfig.yaml file in the file explorer pane on the left to review the contents of the file and then close it.
33. Proceed to section 3 Querying data with MSTICPy and review the contents. Don't run the Multiple Microsoft Sentinel workspaces code cell as it fails, but the other code cells can be run successfully.

In the Microsoft Sentinel navigation menu, expand the *Threat Management* section, and select **Notebooks**

You need to create an Azure Machine Learning (ML) Workspace. From the menu, select **Configure Azure Machine Learning**, then **Create new Azure ML workspace**.

In the Subscription box, select your subscription.

Select **Create a new Resource group** and choose a name for your new resource group.

In the Workspace details section:

- Give your workspace a unique name.
- Choose your Region
- Keep the default Storage account, Key vault, and Application insights information.
- The Container registry option can remain as None.

Give your workspace a unique name.

Choose your Region

Keep the default Storage account, Key vault, and Application insights information.

The Container registry option can remain as None.

At the bottom of the page, select **Review + create**. Then on the next page, select **create**. It takes a moment to deploy the workspace.

It takes a few minutes to deploy the Machine Learning workspace.

After *Your deployment is complete* message appears, return to Microsoft Sentinel.

Navigate to the Threat Management section, and select **Notebooks**.

Select the **Templates** tab.

Select the **A Getting Started Guide For Microsoft Sentinel ML Notebooks** from the list.

Select **Create from template** button on the bottom of the detail pane.

Review the default options and then select **Save**.

Select the **Launch notebook** button.

Select **Close** if an informational window appears in the Microsoft Azure Machine Learning studio.

1. In the command bar, to the right of the Compute:  selector, select the + symbol to Create Azure ML compute instance. Hint: It might be hidden inside the ellipsis icon (...).

You can have more screen space by hiding the Azure ML Studio left menu selections. Select the *Hamburger menu* (3 horizontal lines on the top left), and by collapsing the Notebooks Files by selecting the **&lt;&lt;** icon.

Type a unique name in the *Compute name* field. This identifies your compute instance.

Scroll down and select the first option available.

Workload type: Development on Notebooks (or other IDE) and lightweight testing.

Select the **Review + Create** button at the bottom of the screen, then scroll down and select **Create**. Close any feedback window that appears. This takes a few minutes. You see a notification (bell icon) when it completes and the *Compute instance* left icon turns from blue to green.

Once the Compute is created and running, verify that the kernel to use is *Python 3.10 - Pytorch and Tensorflow*.

This is shown in the right of the menu bar. If that kernel isn't selected, select the *Python 3.10 - Pytorch and Tensorflow* option from the drop-down list. You can select the **Refresh** icon on the far right to see the kernel options.

Select the **Authenticate** button and wait for the authentication to complete.

Clear all the results from the notebook by selecting the **Clear all outputs** (Eraser icon) from the menu bar and follow the *Getting Started* tutorial.

This can be found by selecting the ellipsis (...) from the menu bar.

Review section *1 Introduction* in the notebook and proceed to section *2 Initializing the notebook and MSTICPy*.

Section 1.2 *Running code in notebooks* lets you practice running small lines of Python code.

In section *2 Initializing the notebook and MSTICPy*, review the content on Initializing the notebook and installing the MSTICPy package.

Run the *Python code* to initialize the cell by selecting the **Run cell** button (Play icon) to the left of the code.

It should take &gt;30 seconds to run. Once it completes, review the output messages and *disregard any warnings about the Python kernel version* or other error messages.

The code ran successfully if *msticpyconfig.yaml* was created in the *utils* folder in the *file explorer* pane on the left. It can take another 30 seconds for the file to appear. If it doesn't appear, select the **Refresh** icon in the *file explorer* pane.

You can clear the output messages by selecting the ellipsis (...) on the left of the code window for the *Output menu* and selecting the *Clear output* (square with an x*) icon.

Select the **msticpyconfig.yaml** file in the *file explorer* pane on the left to review the contents of the file and then close it.

Proceed to section *3 Querying data with MSTICPy* and review the contents. Don't run the *Multiple Microsoft Sentinel workspaces* code cell as it fails, but the other code cells can be run successfully.

If you can't complete the steps above to access the Notebook, you can follow it on its GitHub viewer page instead. [Getting Started with Azure ML Notebooks and Microsoft Sentinel](https://nbviewer.org/github/Azure/Azure-Sentinel-Notebooks/blob/master/A%20Getting%20Started%20Guide%20For%20Azure%20Sentinel%20ML%20Notebooks.ipynb" data-linktype="external)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/perform-threat-hunting-sentinel-with-notebooks/4-create-notebook/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/perform-threat-hunting-sentinel-with-notebooks/4-create-notebook/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel)*