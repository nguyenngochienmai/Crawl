---
title: Module assessment
learning_path: SC-200: Perform threat hunting in Microsoft Sentinel
module_number: 17
url: https://learn.microsoft.com/en-us/training/modules/use-search-jobs-microsoft-sentinel/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel
type: quiz
crawled_at: 2025-11-25T19:32:11.246597
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "When you're restoring an archive log, what will the table suffix be?",
"options": [
"\_RST",
"\_Restore",
"\_RSTR"
],
"correct\_answers": [
"\_RST"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "What is the suffix for the search result tables?",
"options": [
"\_SR",
"\_SRCH",
"\_SCH"
],
"correct\_answers": [
"\_SRCH"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "Which log types are supported by Search jobs?",
"options": [
"Analytics logs only.",
"Basic logs only.",
"Analytics logs and Basic logs."
],
"correct\_answers": [
"Analytics logs and Basic logs."
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/use-search-jobs-microsoft-sentinel/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/use-search-jobs-microsoft-sentinel/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel)*