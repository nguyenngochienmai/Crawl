---
title: Module assessment
learning_path: SC-200: Perform threat hunting in Microsoft Sentinel
module_number: 24
url: https://learn.microsoft.com/en-us/training/modules/perform-threat-hunting-sentinel-with-notebooks/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel
type: quiz
crawled_at: 2025-11-25T19:33:40.192989
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "The msticpy package provides which of the following functionality?",
"options": [
"Data wrangling",
"Analyzing data",
"Creating data"
],
"correct\_answers": [
"Analyzing data"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "Which is a component of notebooks in Microsoft Sentinel?",
"options": [
"Telemetry analyzer",
"Kernel",
"Workbook"
],
"correct\_answers": [
"Kernel"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "What coding language is most commonly used in the sample Notebooks?",
"options": [
"Python",
"C#",
"Java"
],
"correct\_answers": [
"Python"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/perform-threat-hunting-sentinel-with-notebooks/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/perform-threat-hunting-sentinel-with-notebooks/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel)*