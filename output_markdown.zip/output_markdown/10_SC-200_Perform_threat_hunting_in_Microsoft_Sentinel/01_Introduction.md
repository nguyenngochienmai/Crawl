---
title: Introduction
learning_path: SC-200: Perform threat hunting in Microsoft Sentinel
module_number: 1
url: https://learn.microsoft.com/en-us/training/modules/what-is-threat-hunting-azure-sentinel/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel
type: introduction
crawled_at: 2025-11-25T19:29:04.606454
---

# Introduction

> Introduction

Microsoft Sentinel provides the tools to perform Threat Hunting. Before starting the hunt, it's crucial to understand the Threat Hunting process.

You're a Security Operations Analyst working at a company that implemented Microsoft Sentinel.  You want to mature your Security Operations team to proactively hunt for malicious activity in your environment.

You suggest to management to create a threat hunting team. You must explain to management the benefit, processes, and tasks of a threat hunting team. You'll demonstrate how to develop a quality hypothesis for hunting.

After completing this module, you'll be able to:

- Describe threat hunting concepts for use with Microsoft Sentinel
- Define a threat hunting hypothesis for use in Microsoft Sentinel


## Prerequisites

Basic knowledge of operational concepts such as monitoring, logging, and alerting


---

*Source: [https://learn.microsoft.com/en-us/training/modules/what-is-threat-hunting-azure-sentinel/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/what-is-threat-hunting-azure-sentinel/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel)*