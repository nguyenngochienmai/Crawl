---
title: Summary and resources
learning_path: SC-200: Perform threat hunting in Microsoft Sentinel
module_number: 6
url: https://learn.microsoft.com/en-us/training/modules/what-is-threat-hunting-azure-sentinel/5-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel
type: summary
crawled_at: 2025-11-25T19:30:33.155829
---

# Summary and resources

> Summary and resources

You should have learned how to use a threat hunting process to proactively hunt for threats in Microsoft Sentinel.

You should now be able to:

- Describe threat hunting concepts for use with Microsoft Sentinel
- Define a threat hunting hypothesis for use in Microsoft Sentinel


## Learn more

You can learn more by reviewing the following.

[Become a Microsoft Sentinel Ninja](https://techcommunity.microsoft.com/t5/azure-sentinel/become-an-azure-sentinel-ninja-the-complete-level-400-training/ba-p/1246310" data-linktype="external" target="az-portal" class="has-external-link-indicator)

[Microsoft Tech Community Security Webinars](https://techcommunity.microsoft.com/t5/microsoft-security-and/security-community-webinars/ba-p/927888" data-linktype="external" target="az-portal" class="has-external-link-indicator)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/what-is-threat-hunting-azure-sentinel/5-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/what-is-threat-hunting-azure-sentinel/5-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel)*