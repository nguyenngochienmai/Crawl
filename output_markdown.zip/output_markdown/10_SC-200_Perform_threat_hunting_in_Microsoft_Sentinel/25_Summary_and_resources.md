---
title: Summary and resources
learning_path: SC-200: Perform threat hunting in Microsoft Sentinel
module_number: 25
url: https://learn.microsoft.com/en-us/training/modules/perform-threat-hunting-sentinel-with-notebooks/7-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel
type: summary
crawled_at: 2025-11-25T19:35:02.531207
---

# Summary and resources

> Summary and resources

You should have learned how to perform advanced hunting in Microsoft Sentinel.

You should now be able to:

- Explore API libraries for advanced threat hunting in Microsoft Sentinel
- Describe notebooks in Microsoft Sentinel
- Create and use notebooks in Microsoft Sentinel


## Learn more

You can learn more by reviewing the following.

[Become a Microsoft Sentinel Ninja](https://techcommunity.microsoft.com/t5/azure-sentinel/become-an-azure-sentinel-ninja-the-complete-level-400-training/ba-p/1246310" data-linktype="external" target="az-portal" class="has-external-link-indicator)

[Microsoft Tech Community Security Webinars](https://techcommunity.microsoft.com/t5/microsoft-security-and/security-community-webinars/ba-p/927888" data-linktype="external" target="az-portal" class="has-external-link-indicator)

[KQL quick reference](https://learn.microsoft.com/en-us/azure/data-explorer/kql-quick-reference" data-linktype="absolute-path" target="az-portal" class="has-external-link-indicator)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/perform-threat-hunting-sentinel-with-notebooks/7-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/perform-threat-hunting-sentinel-with-notebooks/7-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel)*