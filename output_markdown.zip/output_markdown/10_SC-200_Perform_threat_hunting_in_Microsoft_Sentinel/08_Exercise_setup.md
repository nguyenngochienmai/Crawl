---
title: Exercise setup
learning_path: SC-200: Perform threat hunting in Microsoft Sentinel
module_number: 8
url: https://learn.microsoft.com/en-us/training/modules/hunt-threats-sentinel/2-exercise-setup/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel
type: exercise
crawled_at: 2025-11-25T19:30:49.177576
---

# Exercise setup

> Learn how to set up your Azure resources to hunt threats using Microsoft Sentinel.

To complete this optional exercise, you need access to an Azure subscription to create Azure resources. If you don't have an Azure subscription, create a [free account](https://azure.microsoft.com/pricing/purchase-options/azure-account?cid=msft_learn" data-linktype="external) before you begin.

If you perform the exercises in this module, you might incur costs in your Azure subscription. To estimate the costs, see [Microsoft Sentinel pricing](https://azure.microsoft.com/pricing/details/microsoft-sentinel" data-linktype="external).

To deploy the prerequisites for the exercise, perform the following tasks.


## Deploy the Azure Resource Manager template for the exercise environment

1. Select the following link:

You're prompted to sign in to Azure.
2. On the Custom deployment page, provide the following information:
 
		
			
		
		Expand table
	


Name
Description




Subscription
Select your Azure subscription.


Resource Group
Select Create new and provide a name for the resource group, such as azure-sentinel-rg.


Region
Select an Azure region.


Workspace name
Provide a unique name for the Microsoft Sentinel workspace, such as <yourName>-sentinel, where <yourName> represents the workspace name that you chose in the previous task.


Location
Accept the default value [resourceGroup().location].


Simplevm Name
Accept the default value simple-vm.


Simplevm Windows OS Version
Accept the default value 2022-Datacenter.
3. Select Review + create, and then select Create.





 Note
Wait for the deployment to finish. The deployment should take less than five minutes.

Select the following link:


![Deploy To Azure.](https://aka.ms/deploytoazurebutton)

You're prompted to sign in to Azure.

On the **Custom deployment** page, provide the following information:

| Name | Description |
| --- | --- |
| Subscription | Select your Azure subscription. |
| Resource Group | Select Create new and provide a name for the resource group, such as azure-sentinel-rg. |
| Region | Select an Azure region. |
| Workspace name | Provide a unique name for the Microsoft Sentinel workspace, such as <yourName>-sentinel, where <yourName> represents the workspace name that you chose in the previous task. |
| Location | Accept the default value [resourceGroup().location]. |
| Simplevm Name | Accept the default value simple-vm. |
| Simplevm Windows OS Version | Accept the default value 2022-Datacenter. |

Select **Review + create**, and then select **Create**.


![Screenshot of the Custom Deployment page.](https://learn.microsoft.com/training/wwl-sci/hunt-threats-sentinel/media/02-custom-deployment.png)

Wait for the deployment to finish. The deployment should take less than five minutes.


## Check created resources

1. In the Azure portal, search for Resource groups.
2. Select your resource group.
3. Sort the list of resources by Type.
4. The resource group should contain the resources displayed in this table:
 
		
			
		
		Expand table
	


Name
Type
Description




<yourName>-sentinel
Log Analytics workspace
Log Analytics workspace used by Microsoft Sentinel, where <yourName> represents the workspace name that you chose in the previous task.


simple-vmNetworkInterface
Network interface
Network interface for the virtual machine (VM).


SecurityInsights(<yourName>-sentinel)
Solution
Security insights for Microsoft Sentinel.


simple-vm
Virtual machine
VM used in the demonstration.


st1<xxxxx>
Storage account
Storage account used by the VM, where <xxxxx> represents a random string generated to create a unique storage account name.


vnet1
Virtual network
Virtual network for the VM.

In the Azure portal, search for **Resource groups**.

Select your resource group.

Sort the list of resources by **Type**.

The resource group should contain the resources displayed in this table:

| Name | Type | Description |
| --- | --- | --- |
| <yourName>-sentinel | Log Analytics workspace | Log Analytics workspace used by Microsoft Sentinel, where <yourName> represents the workspace name that you chose in the previous task. |
| simple-vmNetworkInterface | Network interface | Network interface for the virtual machine (VM). |
| SecurityInsights(<yourName>-sentinel) | Solution | Security insights for Microsoft Sentinel. |
| simple-vm | Virtual machine | VM used in the demonstration. |
| st1<xxxxx> | Storage account | Storage account used by the VM, where <xxxxx> represents a random string generated to create a unique storage account name. |
| vnet1 | Virtual network | Virtual network for the VM. |


## Configure Microsoft Sentinel connectors

In this task, you deploy a Microsoft Sentinel connector to Azure Activity.

1. In the Azure portal, search for and select Microsoft Sentinel, and then select the previously created Microsoft Sentinel workspace.
2. On the Microsoft Sentinel page, on the menu bar, in the Configuration section, select Data connectors.
3. On the Data connectors pane, search for and select Azure Activity. On the details pane, select Open connector page.
4. Review the Prerequisites. You need to have the owner role assigned for Azure Policy assignment scopes.
5. If you have a subscription connected with the legacy method, you're directed to disconnect it using the Configuration instructions for "1. Disconnect your subscriptions from the legacy method".
6. If you didn't have the connector configured with the legacy method, proceed to "2. Connect your subscriptions..." in the Configuration area.
7. Select Launch Azure Policy Assignment Wizard>.
8. In the Basics tab, select the ellipsis button (...) under Scope and choose your subscription from the drop-down list. Then choose Select.
9. Select the Parameters tab, choose your uniquename-sentinel workspace from the Primary Log Analytics workspace drop-down list.
10. Select the Remediation tab and check the Create a remediation task box.
11. Select the Review + Create button to review the configuration.
12. Select Create to finish.

The connector for Azure Activity uses policy assignments, so it might take 15 to 30 minutes to display a status of **Connected**.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/hunt-threats-sentinel/2-exercise-setup/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/hunt-threats-sentinel/2-exercise-setup/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel)*