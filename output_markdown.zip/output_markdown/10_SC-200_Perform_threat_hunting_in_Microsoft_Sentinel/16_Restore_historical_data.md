---
title: Restore historical data
learning_path: SC-200: Perform threat hunting in Microsoft Sentinel
module_number: 16
url: https://learn.microsoft.com/en-us/training/modules/use-search-jobs-microsoft-sentinel/3-restore-historical-data/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel
type: content
crawled_at: 2025-11-25T19:32:02.571338
---

# Restore historical data

> Restore historical data

When you need to do a full investigation on data stored in archived logs, restore a table from the Search page in Microsoft Sentinel. Specify a target table and time range for the data you want to restore. Within a few minutes, the log data is restored and available within the Log Analytics workspace. Then you can use the data in high-performance queries that support full KQL.

A restored log table is available in a new table that has a ***_RST** suffix. The restored data is available as long as the underlying source data is available. But you can delete restored tables at any time without deleting the underlying source data. To save costs, we recommend you delete the restored table when you no longer need it.


## Limitations of log restore

Before you start to restore an archived log table, be aware of the following limitations:

- Restore data for a minimum of two days.
- Restore up to 60 TB.
- Restore is limited to one active restore per table.
- Restore up to four archived tables per workspace per week.
- Limited to two concurrent restore jobs per workspace.

Tables with the Auxiliary table plan don't support data restore. Use a search job to retrieve data that's in long-term retention from an Auxiliary table.


## Restore archived log data

To restore archived log data in Microsoft Sentinel, specify the table and time range for the data you want to restore. Within a few minutes, the log data is available within the Log Analytics workspace. Then you can use the data in high-performance queries that support full Kusto Query Language (KQL).

Restore archived data directly from search or from a saved search.

1. In the Defender portal, select Microsoft Sentinel > Data lake exploration > Search & restore. In the Azure portal, the Search page is listed under General.

- Defender portal
- Azure portal

1. Restore log data using one of the following methods:

Select 
 Restore at the top of the page. In the Restoration pane on the side, select the table and time range you want to restore, and then select Restore at the bottom of the pane.





Select Saved searches, locate the search results you want to restore, and then select Restore. If you have multiple tables, select the one you want to restore and then select Actions > Restore in the side pane. For example:
2. Select 
 Restore at the top of the page. In the Restoration pane on the side, select the table and time range you want to restore, and then select Restore at the bottom of the pane.
3. Select Saved searches, locate the search results you want to restore, and then select Restore. If you have multiple tables, select the one you want to restore and then select Actions > Restore in the side pane. For example:
4. Wait for the log data to be restored. View the status of your restoration job by selecting on the Restoration tab.

Restore log data using one of the following methods:

- Select 
 Restore at the top of the page. In the Restoration pane on the side, select the table and time range you want to restore, and then select Restore at the bottom of the pane.
- Select Saved searches, locate the search results you want to restore, and then select Restore. If you have multiple tables, select the one you want to restore and then select Actions > Restore in the side pane. For example:

Select 
 **Restore** at the top of the page. In the **Restoration** pane on the side, select the table and time range you want to restore, and then select **Restore at the bottom of the pane**.


![image](https://learn.microsoft.com/training/wwl-sci/use-search-jobs-microsoft-sentinel/media/restore-button.png)


![Screenshot of restoring a specific site search.](https://learn.microsoft.com/training/wwl-sci/use-search-jobs-microsoft-sentinel/media/restore-defender.png)

Select **Saved searches**, locate the search results you want to restore, and then select **Restore**. If you have multiple tables, select the one you want to restore and then select **Actions &gt; Restore** in the side pane. For example:


![Screenshot of restoring a saved search in the Defender portal.](https://learn.microsoft.com/training/wwl-sci/use-search-jobs-microsoft-sentinel/media/restore-defender-saved.png)

Wait for the log data to be restored. View the status of your restoration job by selecting on the **Restoration** tab.

1. Restore log data using one of the following methods:

Select 
 Restore at the top of the page. In the Restoration pane on the side, select the table and time range you want to restore, and then select Restore at the bottom of the pane.

Select Saved searches, locate the search results you want to restore, and then select Restore. If you have multiple tables, select the one you want to restore and then select Actions > Restore in the side pane. For example:
2. Select 
 Restore at the top of the page. In the Restoration pane on the side, select the table and time range you want to restore, and then select Restore at the bottom of the pane.
3. Select Saved searches, locate the search results you want to restore, and then select Restore. If you have multiple tables, select the one you want to restore and then select Actions > Restore in the side pane. For example:
4. Wait for the log data to be restored. View the status of your restoration job by selecting on the Restoration tab.

Restore log data using one of the following methods:

- Select 
 Restore at the top of the page. In the Restoration pane on the side, select the table and time range you want to restore, and then select Restore at the bottom of the pane.
- Select Saved searches, locate the search results you want to restore, and then select Restore. If you have multiple tables, select the one you want to restore and then select Actions > Restore in the side pane. For example:

Select 
 **Restore** at the top of the page. In the **Restoration** pane on the side, select the table and time range you want to restore, and then select **Restore at the bottom of the pane**.


![image](https://learn.microsoft.com/training/wwl-sci/use-search-jobs-microsoft-sentinel/media/restore-button.png)

Select **Saved searches**, locate the search results you want to restore, and then select **Restore**. If you have multiple tables, select the one you want to restore and then select **Actions &gt; Restore** in the side pane. For example:


![Screenshot of restoring a specific site search.](https://learn.microsoft.com/training/wwl-sci/use-search-jobs-microsoft-sentinel/media/restore-azure.png)

Wait for the log data to be restored. View the status of your restoration job by selecting on the **Restoration** tab.


## View restored log data

View the status and results of the log data restore by going to the **Restoration** tab. You can view the restored data when the status of the restore job shows **Data Available**.

1. In Microsoft Sentinel, select Search > Restoration.
2. When your restore job is complete and the status is updated, select the table name and review the results.
In the Azure portal, results are shown in the Logs query page. In the Defender portal, after you select the table name on the Microsoft Sentinel > Data lake exploration > Search & restore > Restoration tab, results are shown in the Advanced hunting page.
For example:




The Time range is set to a custom time range that uses the start and end times of the restored data.

In Microsoft Sentinel, select **Search** &gt; **Restoration**.

When your restore job is complete and the status is updated, select the table name and review the results.

In the [Azure portal](https://portal.azure.com" data-linktype="external), results are shown in the **Logs** query page. In the [Defender portal](https://security.microsoft.com/" data-linktype="external), after you select the table name on the **Microsoft Sentinel** &gt; **Data lake exploration** &gt; **Search &amp; restore** &gt; **Restoration** tab, results are shown in the **Advanced hunting** page.

For example:


![Screenshot that shows the logs query pane with the restored table results.](https://learn.microsoft.com/training/wwl-sci/use-search-jobs-microsoft-sentinel/media/restored-data-logs-view-defender.png)

The **Time range** is set to a custom time range that uses the start and end times of the restored data.


## Delete restored data tables

To save costs, we recommend you delete the restored table when you no longer need it. When you delete a restored table, the underlying source data isn't deleted.

1. In the Defender portal, go to Microsoft Sentinel > Data lake exploration > Search & restore > Restoration and identify the table you want to delete.
2. Select Delete for that table row to delete the restored table.

In the [Defender portal](https://security.microsoft.com/" data-linktype="external), go to **Microsoft Sentinel** &gt; **Data lake exploration** &gt; **Search &amp; restore** &gt; **Restoration** and identify the table you want to delete.

Select **Delete** for that table row to delete the restored table.

For example:


![Screenshot that shows the delete restored table page in the Defender portal.](https://learn.microsoft.com/training/wwl-sci/use-search-jobs-microsoft-sentinel/media/delete-restore.png)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/use-search-jobs-microsoft-sentinel/3-restore-historical-data/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/use-search-jobs-microsoft-sentinel/3-restore-historical-data/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel)*