---
title: Summary
learning_path: SC-200: Perform threat hunting in Microsoft Sentinel
module_number: 13
url: https://learn.microsoft.com/en-us/training/modules/hunt-threats-sentinel/7-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel
type: summary
crawled_at: 2025-11-25T19:31:39.042806
---

# Summary

> Summary of threat hunting using Microsoft Sentinel.

As part of the Security Operations Center team, you need to protect Contoso's environment. To accomplish this goal, you first need to detect any threats to the environment.

In this module, you learned how to hunt for threats by using the tools available in Microsoft Sentinel. That activity included proactively identifying threat behaviors by using Microsoft Sentinel queries. You also learned to continue the hunt by using bookmarks and livestream to identify specific account-usage patterns for Contoso's Azure environment.

Now, you can lead your team in using Microsoft Sentinel to help protect Contoso's environment through threat detection.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/hunt-threats-sentinel/7-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/hunt-threats-sentinel/7-summary/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel)*