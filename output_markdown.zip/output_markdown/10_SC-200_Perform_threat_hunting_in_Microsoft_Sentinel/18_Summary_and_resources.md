---
title: Summary and resources
learning_path: SC-200: Perform threat hunting in Microsoft Sentinel
module_number: 18
url: https://learn.microsoft.com/en-us/training/modules/use-search-jobs-microsoft-sentinel/5-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel
type: summary
crawled_at: 2025-11-25T19:32:51.480200
---

# Summary and resources

> Summary and resources

You should have learned how to perform search on large datasets in Microsoft Sentinel.

You should now be able to:

- Create and view a Search Job in Microsoft Sentinel
- Restore archived logs in Microsoft Sentinel


## Learn more

You can learn more by reviewing the following.

[Start an investigation by searching for events in large datasets](/en-us/azure/sentinel/investigate-large-datasets" data-linktype="absolute-path)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/use-search-jobs-microsoft-sentinel/5-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/use-search-jobs-microsoft-sentinel/5-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel)*