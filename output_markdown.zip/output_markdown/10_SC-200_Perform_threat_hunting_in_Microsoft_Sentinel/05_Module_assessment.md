---
title: Module assessment
learning_path: SC-200: Perform threat hunting in Microsoft Sentinel
module_number: 5
url: https://learn.microsoft.com/en-us/training/modules/what-is-threat-hunting-azure-sentinel/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel
type: quiz
crawled_at: 2025-11-25T19:29:35.850901
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "Which of the following best describes a good Hypothesis?",
"options": [
"is Time-bound",
"focuses on known Indicators",
"focuses on all current threats"
],
"correct\_answers": [
"is Time-bound"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "Threat Hunting is considered which of the following?",
"options": [
"Retroactive.",
"Reactive.",
"Proactive."
],
"correct\_answers": [
"Proactive."
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "\"We want to check which accounts have run cmd.exe.\" Why is this hypothesis poor?",
"options": [
"Cmd.exe isn't a program.",
"Accounts aren't associated with the running of cmd.exe",
"The scope is too broad."
],
"correct\_answers": [
"The scope is too broad."
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/what-is-threat-hunting-azure-sentinel/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel](https://learn.microsoft.com/en-us/training/modules/what-is-threat-hunting-azure-sentinel/4-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-perform-threat-hunting-azure-sentinel)*