---
title: Summary and resources
learning_path: SC-200: Mitigate threats using Microsoft Defender XDR
module_number: 37
url: https://learn.microsoft.com/en-us/training/modules/manage-azure-active-directory-identity-protection/10-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender
type: summary
crawled_at: 2025-11-25T16:13:54.456907
---

# Summary and resources

> Summary and resources

Now that you have reviewed this module, you should be able to:

- Review Identity Protection basics.
- Implement and manage a user risk policy.
- Implement and manage sign-in risk policies.
- Implement and manage multifactor authentication (MFA) registration policy.
- Monitor, investigate, and remediate elevated risky users.
- Explore Microsoft Defender for Identity


## Resources

Use these resources to discover more.

- Enabling combined security information registration in Microsoft Entra ID
- Manage emergency access accounts in Microsoft Entra ID
- How To: Configure and enable risk policies
- What are managed identities for Azure resources?
- Remediate risks and unblock users
- Microsoft Entra Identity Protection notifications
- Identity Protection policies
- What is Microsoft Defender for Identity


---

*Source: [https://learn.microsoft.com/en-us/training/modules/manage-azure-active-directory-identity-protection/10-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender](https://learn.microsoft.com/en-us/training/modules/manage-azure-active-directory-identity-protection/10-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender)*