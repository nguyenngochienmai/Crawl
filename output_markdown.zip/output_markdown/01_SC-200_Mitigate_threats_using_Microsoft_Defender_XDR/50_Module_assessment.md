---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Defender XDR
module_number: 50
url: https://learn.microsoft.com/en-us/training/modules/microsoft-cloud-app-security/knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender
type: quiz
crawled_at: 2025-11-25T16:15:50.692668
---

# Module assessment

> Review what you've learned about Microsoft Defender for Cloud Apps.



---

## Knowledge Check


[
{
"question\_number": 1,
"question": "How can you get an at-a-glance overview of the kinds of apps are being used within your organization?",
"options": [
"Use Azure Information Protection",
"Use Conditional Access",
"Use the Cloud Discovery Dashboard"
],
"correct\_answers": [
"Use the Cloud Discovery Dashboard"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "The Defender for Cloud Apps framework includes which of the following?",
"options": [
"Discover and control the use of Shadow IT",
"Block external traffic",
"Protect Active Directory"
],
"correct\_answers": [
"Discover and control the use of Shadow IT"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "Which of these is a feature of Conditional Access App Control policies?",
"options": [
"Remote access",
"Require multi-factor authentication",
"Protect on download"
],
"correct\_answers": [
"Protect on download"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 4,
"question": "How can you ensure that a file is sent into quarantine for review by an administrator?",
"options": [
"When creating a file policy, select Quarantine for admin",
"When creating a file policy, select Put in admin quarantine",
"When creating a file policy, select Put in review for admin"
],
"correct\_answers": [
"When creating a file policy, select Put in admin quarantine"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 5,
"question": "Which anomaly detection policy triggers an alert if the same user credentials originate from two geographically distant locations within a short time?",
"options": [
"Impossible travel",
"Impossible distance",
"Impossible twins"
],
"correct\_answers": [
"Impossible travel"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/microsoft-cloud-app-security/knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender](https://learn.microsoft.com/en-us/training/modules/microsoft-cloud-app-security/knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender)*