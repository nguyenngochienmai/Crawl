---
title: Exercise enable sign-in risk policy
learning_path: SC-200: Mitigate threats using Microsoft Defender XDR
module_number: 31
url: https://learn.microsoft.com/en-us/training/modules/manage-azure-active-directory-identity-protection/4-exercise-enable-sign-risk-policy/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender
type: exercise
crawled_at: 2025-11-25T16:11:58.782472
---

# Exercise enable sign-in risk policy

> Exercise enable sign-in risk policy


## Enable user risk policy

1. Sign in to the Microsoft Entra admin center using a Global administrator account.
2. Open the portal menu and then select Identity.
3. On the Identity menu, select Protection.
4. On the Security blade, in the left navigation, select Identity protection.
5. In the Identity protection blade, in the left navigation, select User risk policy.
6. Under Assignments, select All users and review the available options. You can select from All users or Select individuals and groups if limiting your rollout. Additionally, you can choose to exclude users from the policy.
7. Under User risk, select Low and above.
8. In the User risk pane, select High and then select Done.
9. Under Controls, then Access, and then select Block access.
10. In the Access pane, review the available options.

Sign in to the [Microsoft Entra admin center](https://entra.microsoft.com/" data-linktype="external) using a Global administrator account.

Open the portal menu and then select **Identity**.

On the Identity menu, select **Protection**.

On the Security blade, in the left navigation, select **Identity protection**.

In the Identity protection blade, in the left navigation, select User risk policy.


![Screenshot of the User risk policy page and highlighted browsing path.](https://learn.microsoft.com/training/wwl-sci/manage-azure-active-directory-identity-protection/media/browse-identity-protection.png)

Under **Assignments**, select **All users** and review the available options. You can select from **All users** or **Select individuals and groups** if limiting your rollout. Additionally, you can choose to exclude users from the policy.

Under **User risk**, select **Low and above**.

In the User risk pane, select **High** and then select **Done**.

Under **Controls**, then **Access**, and then select **Block access**.

In the Access pane, review the available options.

Microsoft's recommendation is to Allow access and Require password change.

1. Select the Require password change check box and then select Done.
2. Under Enforce Policy, select On and then select Save.


## Enable sign-in risk policy

1. On the Identity protection blade, in the left navigation, select Sign-in risk policy.
2. As with the User risk policy, the Sign-in risk policy can be assigned to users and groups and allows you to exclude users from the policy.
3. Under Sign-in risk, select Medium and above.
4. In the Sign-in risk pane, select High and then select Done.
5. Under Controls, then Access, and then select Block access.
6. Select the Require multifactor authentication check box and then select Done.
7. Under Enforce Policy, select On and then select Save.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/manage-azure-active-directory-identity-protection/4-exercise-enable-sign-risk-policy/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender](https://learn.microsoft.com/en-us/training/modules/manage-azure-active-directory-identity-protection/4-exercise-enable-sign-risk-policy/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender)*