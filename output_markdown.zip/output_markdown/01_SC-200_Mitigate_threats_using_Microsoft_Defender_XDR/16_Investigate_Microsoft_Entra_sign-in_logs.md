---
title: Investigate Microsoft Entra sign-in logs
learning_path: SC-200: Mitigate threats using Microsoft Defender XDR
module_number: 16
url: https://learn.microsoft.com/en-us/training/modules/mitigate-incidents-microsoft-365-defender/9-investigate-azure-ad-sign-in-logs/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender
type: content
crawled_at: 2025-11-25T16:07:04.036843
---

# Investigate Microsoft Entra sign-in logs

> Investigate Microsoft Entra sign-in logs

To perform a sign-in investigation including conditional access policies evaluated, you can query the following tables with KQL:

| Location | Table |
| --- | --- |
| Microsoft Defender XDR Threat Hunting | AADSignInEventsBeta |
| Microsoft Entra ID Log Analytics | SigninLogs |

The Microsoft Entra monitoring Sign-in Logs provide access to the same information available in the SigninLogs table. To access the Sign-in Logs blade, select Microsoft Entra ID in the Azure portal, then Sign-in Logs in the Monitoring Group.  The query output will provide default columns including the Date, User, Application, Status, and Conditional Access (policy applied).


---

*Source: [https://learn.microsoft.com/en-us/training/modules/mitigate-incidents-microsoft-365-defender/9-investigate-azure-ad-sign-in-logs/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender](https://learn.microsoft.com/en-us/training/modules/mitigate-incidents-microsoft-365-defender/9-investigate-azure-ad-sign-in-logs/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender)*