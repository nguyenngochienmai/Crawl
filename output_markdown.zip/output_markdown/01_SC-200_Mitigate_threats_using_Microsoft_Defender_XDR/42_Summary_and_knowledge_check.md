---
title: Summary and knowledge check
learning_path: SC-200: Mitigate threats using Microsoft Defender XDR
module_number: 42
url: https://learn.microsoft.com/en-us/training/modules/m365-threat-safeguard/summary-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender
type: quiz
crawled_at: 2025-11-25T16:14:34.060802
---

# Summary and knowledge check

> Learn about the Microsoft Defender for Identity component of Microsoft Defender XDR.

In this module, you learned about the Microsoft Defender for Identity component of Microsoft Defender XDR.

Now that you have completed this module, you should be able to:

- Define the capabilities of Microsoft Defender for Identity.
- Understand how to configure Microsoft Defender for Identity sensors.
- Explain how Microsoft Defender for Identity can remediate risks in your environment.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "Microsoft Defender for Identity requires an on-premises Active Directory environment.",
"options": [
"True",
"False"
],
"correct\_answers": [
"True"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "Which of the following describes advanced threats detected by Microsoft Defender for Identity?",
"options": [
"Reconnaissance",
"Vertical movements",
"Bitcoin mining"
],
"correct\_answers": [
"Reconnaissance"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "Which of the following is not a supported integration for Microsoft Defender for Identity?",
"options": [
"Microsoft Defender for Endpoint",
"Microsoft Defender for Cloud Apps",
"Intune"
],
"correct\_answers": [
"Intune"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/m365-threat-safeguard/summary-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender](https://learn.microsoft.com/en-us/training/modules/m365-threat-safeguard/summary-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender)*