---
title: Configure the Microsoft Defender portal
learning_path: SC-200: Mitigate threats using Microsoft Defender XDR
module_number: 20
url: https://learn.microsoft.com/en-us/training/modules/mitigate-incidents-microsoft-365-defender/13-configure-microsoft-365-defender-portal/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender
type: content
crawled_at: 2025-11-25T16:07:40.207272
---

# Configure the Microsoft Defender portal

> Configure the Microsoft Defender portal

The Settings page lets you configure related Microsoft Defender products. The specific settings for the Defender products will be discussed in the related learning content. The primary setting for Microsoft Defender XDR is the notifications email configuration.


## Types of Microsoft Defender portal email notifications

When you set up email notifications, you can choose from two types, as described in the following table:

| Notification type | Description |
| --- | --- |
| Incidents | When new Incidents are created |
| Threat Analytics | When new Threat Analytic reports are created |


### Manage Incident email notifications

To view, add or edit Incident email notification settings for your organization, follow these steps:

In the navigation pane, select Settings, and then select Microsoft Defender XDR. Then,  select Email notifications.

Next, select Incidents

To add a new notification:

- Select Add incident email notification.
- Enter a name and description, then next.
- Select device and alert criteria, then next.
- Enter the recipients email address, then next.
- Select the Create rule button.


### Manage Threat Analytics email notifications

To view, add or edit Threat Analytics email notification settings for your organization, follow these steps:

In the navigation pane, select Settings, and then select Microsoft Defender XDR. Then,  select Email notifications.

Next, select Threat Analytics

To add a new notification:

- Select Create a notification rule.
- Enter a name and description, then next.
- Select threat analytics criteria, then next.
- Enter the recipients email address, then next.
- Select the Create rule button.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/mitigate-incidents-microsoft-365-defender/13-configure-microsoft-365-defender-portal/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender](https://learn.microsoft.com/en-us/training/modules/mitigate-incidents-microsoft-365-defender/13-configure-microsoft-365-defender-portal/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender)*