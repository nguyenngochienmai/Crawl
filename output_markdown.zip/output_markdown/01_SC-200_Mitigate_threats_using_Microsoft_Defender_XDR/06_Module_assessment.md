---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Defender XDR
module_number: 6
url: https://learn.microsoft.com/en-us/training/modules/introduction-microsoft-365-threat-protection/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender
type: quiz
crawled_at: 2025-11-25T16:04:43.325218
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "Which Microsoft Defender XDR solution can detect an Active Directory Domain compromise?",
"options": [
"Microsoft Defender for Identity",
"Microsoft Defender for Endpoint",
"Microsoft Defender for Office 365"
],
"correct\_answers": [
"Microsoft Defender for Identity"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "Which Microsoft Defender XDR solution can detect a phishing email?",
"options": [
"Microsoft Defender for Identity",
"Microsoft Defender for Endpoint",
"Microsoft Defender for Office 365"
],
"correct\_answers": [
"Microsoft Defender for Office 365"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "Which Microsoft Defender XDR solution can detect a malware installation?",
"options": [
"Microsoft Defender for Identity",
"Microsoft Defender for Endpoint",
"Microsoft Defender for Office 365"
],
"correct\_answers": [
"Microsoft Defender for Endpoint"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/introduction-microsoft-365-threat-protection/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender](https://learn.microsoft.com/en-us/training/modules/introduction-microsoft-365-threat-protection/6-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender)*