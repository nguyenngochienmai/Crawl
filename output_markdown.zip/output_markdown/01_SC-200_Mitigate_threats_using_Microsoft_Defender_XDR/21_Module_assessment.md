---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Defender XDR
module_number: 21
url: https://learn.microsoft.com/en-us/training/modules/mitigate-incidents-microsoft-365-defender/14-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender
type: quiz
crawled_at: 2025-11-25T16:07:47.701833
---

# Module assessment

> Knowledge check

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "When you're reviewing a specific incident, which tab is contained on the incident page?",
"options": [
"Networks",
"Non-Azure Machines",
"Assets"
],
"correct\_answers": [
"Assets"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "You can classify an Incident as which of the following?",
"options": [
"True positive",
"High alert",
"Test alert"
],
"correct\_answers": [
"True positive"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "The Devices page shows information from which Defender product?",
"options": [
"Microsoft Cloud App Security",
"Microsoft Defender for Identity",
"Microsoft Defender for Endpoint"
],
"correct\_answers": [
"Microsoft Defender for Endpoint"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/mitigate-incidents-microsoft-365-defender/14-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender](https://learn.microsoft.com/en-us/training/modules/mitigate-incidents-microsoft-365-defender/14-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender)*