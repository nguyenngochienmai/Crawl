---
title: Walk through discovery and access control with Microsoft Defender for Cloud Apps
learning_path: SC-200: Mitigate threats using Microsoft Defender XDR
module_number: 47
url: https://learn.microsoft.com/en-us/training/modules/microsoft-cloud-app-security/walkthrough/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender
type: content
crawled_at: 2025-11-25T16:15:27.300333
---

# Walk through discovery and access control with Microsoft Defender for Cloud Apps

> See how Cloud Discovery and Conditional Access App Control work in the Defender for Cloud Apps portal.

Now that you've learned how Cloud Discovery and Conditional Access App Control work, it's time to see how to implement them in Defender XDR.

This video walks you through how to protect your cloud apps in Microsoft Defender XDR:


📺 **Embedded Content**: [https://learn-video.azurefd.net/vod/player?id=a722f8cd-806b-40dd-ad93-139fa2b487b9&locale=en-us&embedUrl=%2Ftraining%2Fmodules%2Fmicrosoft-cloud-app-security%2Fwalkthrough](https://learn-video.azurefd.net/vod/player?id=a722f8cd-806b-40dd-ad93-139fa2b487b9&locale=en-us&embedUrl=%2Ftraining%2Fmodules%2Fmicrosoft-cloud-app-security%2Fwalkthrough)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/microsoft-cloud-app-security/walkthrough/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender](https://learn.microsoft.com/en-us/training/modules/microsoft-cloud-app-security/walkthrough/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender)*