---
title: Simulate attacks
learning_path: SC-200: Mitigate threats using Microsoft Defender XDR
module_number: 26
url: https://learn.microsoft.com/en-us/training/modules/m365-threat-remediate/simulate-attacks/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender
type: content
crawled_at: 2025-11-25T16:10:15.548220
---

# Simulate attacks

> Learn how Microsoft Defender for Office 365 can help train your defenders with threat simulations.


![Illustration of Technological shifts for Defenders.](https://learn.microsoft.com/training/wwl/m365-threat-remediate/media/defender-shift.png)

Microsoft Defender for Office 365  includes best-of-class threat investigation and response tools that enable your organization's security team to anticipate, understand, and prevent malicious attacks.

The following capabilities are now found in Microsoft Defender XDR (Extended Detection and Response) which includes Microsoft Defender for Office 365, Microsoft Defender for Endpoint, and Microsoft Defender for Identity. Microsoft Defender XDR provides a unified view of threats across your organization, and enables you to investigate and respond to threats across your Microsoft 365 environment.

- Threat trackers provide the latest intelligence on prevailing cybersecurity issues. For example, you can view information about the latest malware, and take countermeasures before it becomes an actual threat to your organization. Available trackers include Noteworthy trackers, Trending trackers, Tracked queries, and Saved queries.
- Threat Explorer (or real-time detections) (also referred to as Explorer) is a real-time report that allows you to identify and analyze recent threats. You can configure Explorer to show data for custom periods.
- Attack Simulator allows you to run realistic attack scenarios in your organization to identify vulnerabilities. Simulations of current types of attacks are available, including spear phishing, credential harvest and attachment attacks, and password spray and brute force password attacks.

Threat Explorer enables you to begin delving into granular data for your organization.  Inside Threat Explorer, you're first shown the variety of threat families impacting our organization over time. Additionally, you're shown the top threats and top targeted users inside the organization.

You can also change the category for the graph. In this case, All email is shown, and you can filter the Threat Explorer graph on many options including the Sender address, Recipients, and even the detection technology used to stop a threat. The Detection technology identifies if an email is blocked by Microsoft Defender for Cloud's sandboxing or through an Exchange Online Protection (EOP) filter. The graph adjusts to reflect the category being examined.


![Screenshot of Threat Explorer graph.](https://learn.microsoft.com/training/wwl/m365-threat-remediate/media/threat-explorer-graph.png)

Threat Explorer allows a deeper look into a threat, beginning with a thorough description of this malware family's behavior. Threat Explorer provides a definition of the threat, the message traces of emails delivering the threat, technical details of the threat, global details of the threat, and advanced analysis.

On the **Top targeted users** tab, you could see each instance that a user in the organization was sent an attachment containing a malware threat. You can not only see the specific recipients and subject, but the sender domain and the sender IP as well. The **Delivery action** column tells you if the email was caught and blocked before it ever reached the user, or if it was delivered as spam.


![Screenshot of Malware family description.](https://learn.microsoft.com/training/wwl/m365-threat-remediate/media/malware-family-description.png)

If a user received and opened the email that would also appear under Status enabling you to reach out to the user and take the appropriate remediation steps, such as scanning their device.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/m365-threat-remediate/simulate-attacks/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender](https://learn.microsoft.com/en-us/training/modules/m365-threat-remediate/simulate-attacks/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender)*