---
title: Investigate security incidents in Microsoft Defender XDR
learning_path: SC-200: Mitigate threats using Microsoft Defender XDR
module_number: 5
url: https://learn.microsoft.com/en-us/training/modules/introduction-microsoft-365-threat-protection/5-investigate-security-incident-defender/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender
type: content
crawled_at: 2025-11-25T16:04:36.577480
---

# Investigate security incidents in Microsoft Defender XDR

> Investigate security incidents in Microsoft Defender XDR

The following cloud guide demonstrates Microsoft Defender XDR and Microsoft Sentinel working together to investigate a security incident in a hybrid environment.

[Launch Investigate Security Incident](https://mslearn.cloudguides.com/guides/Investigate%20security%20incidents%20in%20a%20hybrid%20environment%20with%20Azure%20Sentinel" data-linktype="external)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/introduction-microsoft-365-threat-protection/5-investigate-security-incident-defender/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender](https://learn.microsoft.com/en-us/training/modules/introduction-microsoft-365-threat-protection/5-investigate-security-incident-defender/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender)*