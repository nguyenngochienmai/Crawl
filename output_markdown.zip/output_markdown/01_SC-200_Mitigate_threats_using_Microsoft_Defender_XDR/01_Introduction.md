---
title: Introduction
learning_path: SC-200: Mitigate threats using Microsoft Defender XDR
module_number: 1
url: https://learn.microsoft.com/en-us/training/modules/introduction-microsoft-365-threat-protection/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender
type: introduction
crawled_at: 2025-11-25T16:04:07.326160
---

# Introduction

> Introduction.

Microsoft Defender XDR is an integrated threat protection suite with solutions that detect malicious activity across email, endpoints, applications, and identity. These solutions provide a complete attack chain compromise story that enables a complete understanding of the threat. And, enables you to remediate and protect your organization from future attacks.

In the sample attack chain graphic example, see the attacker activity visible to each Microsoft Defender XDR product.


![Diagram of Microsoft Defender XDR tools to defend across attack chains.](https://learn.microsoft.com/training/wwl-sci/introduction-microsoft-365-threat-protection/media/defend-attack-chains.png)

You're a Security Operations Analyst working at a company that is implementing Microsoft Defender XDR solutions.  You need to understand how Extended Detection and Response (XDR) combines signals from:

- endpoints
- identity
- email
- applications

to detect and mitigate threats.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/introduction-microsoft-365-threat-protection/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender](https://learn.microsoft.com/en-us/training/modules/introduction-microsoft-365-threat-protection/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender)*