---
title: Introduction
learning_path: SC-200: Mitigate threats using Microsoft Defender XDR
module_number: 28
url: https://learn.microsoft.com/en-us/training/modules/manage-azure-active-directory-identity-protection/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender
type: introduction
crawled_at: 2025-11-25T16:11:33.318313
---

# Introduction

> Introduction

Protecting users' identity by monitoring their usage and sign-in patters ensures a secure cloud solution. Explore how to design and implement Microsoft Entra Identity Protection.


### Watch this video

In this video, get a high-level overview of Identity Protection, a feature of Microsoft Entra ID. You’ll learn about different types of detections, risks, and risk policies that exist in Identity Protection. The video explains the benefits of the risk policies, recent UX enhancements, powerful APIs, improved risk assessment, and overall alignment along risky users and risky sign-ins.


📺 **Embedded Content**: [https://learn-video.azurefd.net/vod/player?id=0266c208-6909-4ac4-8c70-219f866d5390&locale=en-us&embedUrl=%2Ftraining%2Fmodules%2Fmanage-azure-active-directory-identity-protection%2F1-introduction](https://learn-video.azurefd.net/vod/player?id=0266c208-6909-4ac4-8c70-219f866d5390&locale=en-us&embedUrl=%2Ftraining%2Fmodules%2Fmanage-azure-active-directory-identity-protection%2F1-introduction)


## Learning objectives

In this module, you will:

- Review Identity Protection basics.
- Implement and manage a user risk policy.
- Implement and manage sign-in risk policies.
- Implement and manage multifactor authentication (MFA) registration policy.
- Monitor, investigate, and remediate elevated risky users.
- Explore Microsoft Defender for Identity


---

*Source: [https://learn.microsoft.com/en-us/training/modules/manage-azure-active-directory-identity-protection/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender](https://learn.microsoft.com/en-us/training/modules/manage-azure-active-directory-identity-protection/1-introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender)*