---
title: Summary and resources
learning_path: SC-200: Mitigate threats using Microsoft Defender XDR
module_number: 22
url: https://learn.microsoft.com/en-us/training/modules/mitigate-incidents-microsoft-365-defender/15-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender
type: summary
crawled_at: 2025-11-25T16:09:45.200227
---

# Summary and resources

> Summary and resources

You should have learned how Microsoft Defender XDR provides a purpose-driven user interface to manage and investigate security incidents and alerts across Microsoft 365 services.

You should now be able to:

- Manage incidents for Microsoft Defender XDR
- Investigate incidents for Microsoft Defender XDR
- Conduct advanced hunting for Microsoft Defender XDR


## Learn more

You can learn more by reviewing the following.

[MITRE ATT&amp;CK Matrix for Enterprise](https://attack.mitre.org/" data-linktype="external)

[Become a Microsoft Defender XDR Ninja](https://techcommunity.microsoft.com/t5/microsoft-365-defender/become-a-microsoft-365-defender-ninja/ba-p/1789376" data-linktype="external" target="az-portal" class="has-external-link-indicator)

[Microsoft Tech Community Security Webinars](https://techcommunity.microsoft.com/t5/microsoft-security-and/security-community-webinars/ba-p/927888" data-linktype="external" target="az-portal" class="has-external-link-indicator)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/mitigate-incidents-microsoft-365-defender/15-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender](https://learn.microsoft.com/en-us/training/modules/mitigate-incidents-microsoft-365-defender/15-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender)*