---
title: Introduction
learning_path: SC-200: Mitigate threats using Microsoft Defender XDR
module_number: 43
url: https://learn.microsoft.com/en-us/training/modules/microsoft-cloud-app-security/introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender
type: introduction
crawled_at: 2025-11-25T16:14:56.170752
---

# Introduction

> Learn about Microsoft Defender for Cloud Apps and what you'll learn in this module.

When you move from an on-premises to a cloud-based organization, you increase flexibility, both for employees and the IT team. However, this move also introduces new challenges for keeping your organization secure. To get the full benefit of cloud apps and services, you have to balance supporting access with protecting critical data. Microsoft Defender for Cloud Apps helps you achieve that balance. It provides rich visibility, control over data travel, and sophisticated analytics to identify and combat cyberthreats across all your cloud services.

Suppose you're an administrator for an organization that's moved into the cloud. This module will show you how to use Microsoft Defender for Cloud Apps.


## Learn objectives

When you finish this module, you'll be able to:

- Define the Defender for Cloud Apps framework.
- Understand how to use Cloud Discovery for visibility in your organization.
- Explain how to use Conditional Access App Control policies to monitor and control access to your applications.
- Understand how to classify and protect your information.
- Understand how to use anomaly detection policies to detect threats in your cloud environment.


---

*Source: [https://learn.microsoft.com/en-us/training/modules/microsoft-cloud-app-security/introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender](https://learn.microsoft.com/en-us/training/modules/microsoft-cloud-app-security/introduction/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender)*