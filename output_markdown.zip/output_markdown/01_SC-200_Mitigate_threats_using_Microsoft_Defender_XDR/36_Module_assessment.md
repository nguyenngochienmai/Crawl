---
title: Module assessment
learning_path: SC-200: Mitigate threats using Microsoft Defender XDR
module_number: 36
url: https://learn.microsoft.com/en-us/training/modules/manage-azure-active-directory-identity-protection/9-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender
type: quiz
crawled_at: 2025-11-25T16:12:37.963338
---

# Module assessment

> Module assessment

Choose the best response for each of the questions below.


---

## Knowledge Check


[
{
"question\_number": 1,
"question": "Which task can a user with the Security Operator role perform?",
"options": [
"Configure alerts",
"Confirm safe sign-in",
"Reset a password for a user"
],
"correct\_answers": [
"Confirm safe sign-in"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 2,
"question": "There are two risk policies that can be enabled in the directory. One is user risk policy. Which is the other risk policy?",
"options": [
"Mobile device access risk policy",
"Sign-in risk policy",
"Hybrid identity sign-in risk policy"
],
"correct\_answers": [
"Sign-in risk policy"
],
"type": "multiple\_choice",
"explanation": ""
},
{
"question\_number": 3,
"question": "In Microsoft Graph, which three APIs expose information about risky users and sign-ins",
"options": [
"riskDetection, riskyUsers, signIns",
"riskDetection, itemActivity, signIns",
"riskyUsers, signIns, IdentitySet"
],
"correct\_answers": [
"riskDetection, riskyUsers, signIns"
],
"type": "multiple\_choice",
"explanation": ""
}
]

---

*Source: [https://learn.microsoft.com/en-us/training/modules/manage-azure-active-directory-identity-protection/9-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender](https://learn.microsoft.com/en-us/training/modules/manage-azure-active-directory-identity-protection/9-knowledge-check/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender)*