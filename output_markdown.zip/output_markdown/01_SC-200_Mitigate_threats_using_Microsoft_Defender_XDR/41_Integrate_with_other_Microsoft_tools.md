---
title: Integrate with other Microsoft tools
learning_path: SC-200: Mitigate threats using Microsoft Defender XDR
module_number: 41
url: https://learn.microsoft.com/en-us/training/modules/m365-threat-safeguard/integrate-microsoft-tools/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender
type: content
crawled_at: 2025-11-25T16:14:26.982682
---

# Integrate with other Microsoft tools

> Learn about the Microsoft Defender for Identity component of Microsoft Defender XDR.


![Integration architecture.](https://learn.microsoft.com/training/m365/m365-threat-safeguard/media/integration-architecture.png)

The Microsoft Defender for Identity cloud service runs on Azure infrastructure and is currently deployed in the US, Europe, and Asia. Microsoft Defender for Identity cloud service is connected to Microsoft's intelligent security graph. This enables Microsoft Defender for Identity to integrate with Microsoft Defender for Cloud Apps, as part of a Microsoft Defender XDR monitoring strategy.

Once integrated into Microsoft Defender for Cloud Apps, you're able to see on-premises activities for all the users in your organization. You'll also get advanced insights on your users that combine alerts and suspicious activities across your cloud and on-premises environments. Additionally, policies from Microsoft Defender for Identity appear on the Defender for Cloud Apps policies page. The following screenshot shows Microsoft Defender for Identity reporting within Defender for Cloud Apps.


![Microsoft Defender for Identity reporting within Microsoft Defender for Cloud Apps.](https://learn.microsoft.com/training/m365/m365-threat-safeguard/media/azure-reporting-cloud-app-security.png)

Microsoft Defender for Identity also enables you to integrate Microsoft Defender for Identity with Microsoft Defender for Endpoint, for an even more complete threat protection solution. While Microsoft Defender for Identity monitors the traffic on your domain controllers, Microsoft Defender for Endpoint monitors your endpoints, together providing a single interface from which you can protect your environment.
Once Microsoft Defender for Endpoint and Microsoft Defender for Identity are integrated, you can select on an endpoint to view Microsoft Defender for Identity alerts in the Microsoft Defender for Endpoint portal.


![Windows Defender Security Center.](https://learn.microsoft.com/training/m365/m365-threat-safeguard/media/windows-defender-security-center.png)

Having this level of insight into system running processes allows an analyst to locate event sequences leading to a compromise of the network. In the screenshot below, there are high severity alerts pointing to malware being installed on the system.


![High severity malware alert.](https://learn.microsoft.com/training/m365/m365-threat-safeguard/media/high-severity-malware-alert.png)

Clicking into the alert verifies that a Pass-The-Hash (PtH) attack occurred using the tool Mimikatz. Under actions for the alert, we can also review a timeline of events surrounding the credential theft.


![Review a timeline of events surrounding the credential theft.](https://learn.microsoft.com/training/m365/m365-threat-safeguard/media/event-timeline.png)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/m365-threat-safeguard/integrate-microsoft-tools/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender](https://learn.microsoft.com/en-us/training/modules/m365-threat-safeguard/integrate-microsoft-tools/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender)*