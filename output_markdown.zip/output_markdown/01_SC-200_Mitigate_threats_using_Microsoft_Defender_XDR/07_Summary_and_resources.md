---
title: Summary and resources
learning_path: SC-200: Mitigate threats using Microsoft Defender XDR
module_number: 7
url: https://learn.microsoft.com/en-us/training/modules/introduction-microsoft-365-threat-protection/7-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender
type: summary
crawled_at: 2025-11-25T16:05:33.064112
---

# Summary and resources

> Summary and resources

You should have learned the role that Microsoft Defender XDR plays in a modern SOC.

You should now be able to:

- Understand Microsoft Defender XDR solution by domain
- Understand Microsoft Defender XDR role in a Modern SOC


## Learn more

You can learn more by reviewing the following.

[Microsoft Cybersecurity Reference Architectures](/en-us/security/cybersecurity-reference-architecture/mcra" data-linktype="absolute-path)


---

*Source: [https://learn.microsoft.com/en-us/training/modules/introduction-microsoft-365-threat-protection/7-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender](https://learn.microsoft.com/en-us/training/modules/introduction-microsoft-365-threat-protection/7-summary-resources/?ns-enrollment-type=learningpath&ns-enrollment-id=learn.wwl.sc-200-mitigate-threats-using-microsoft-365-defender)*